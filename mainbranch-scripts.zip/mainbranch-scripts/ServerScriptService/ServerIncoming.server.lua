--[[
    ServerIncoming (Script)
    Path: ServerScriptService
    Parent: ServerScriptService
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Incoming = Modules:WaitForChild("Incoming")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

ReceiveIncoming.OnServerEvent:Connect(function(Player, Action, ...)
	local ActionModule = Incoming:FindFirstChild(Action)
	if ActionModule then
		require(ActionModule)(Player, ...)
	end
end)