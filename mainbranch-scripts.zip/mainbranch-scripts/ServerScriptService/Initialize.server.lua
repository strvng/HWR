--[[
    Initialize (Script)
    Path: ServerScriptService
    Parent: ServerScriptService
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local Names = {
	--"Regen",
	--"Flags",
	"DataHandler",
	--"ChatCommands",
	--"LeakHandler",
	"Events",
	--"Givers",
	"Gamepass",
	--"Anticheat",
	"PrivateServer",
	"Round",
}

for i, v in pairs(Names) do
	local Folder = Modules:FindFirstChild(v)
	if Folder then
		local Main = Folder:FindFirstChild("Main")
		if Main then
			require(Main)
		end
	end
end