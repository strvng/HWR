--[[
    quick fix for sort inventory (Script)
    Path: ServerScriptService
    Parent: ServerScriptService
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local map = require(game.ServerStorage.Modules.Round.Maps.MapController)

local function RemoveTool(Backpack, Name)
	local t = Backpack:FindFirstChild(Name)
	if t then
		t:Destroy()
	end
end

game.Players.PlayerAdded:Connect(function(Player)
	Player.CharacterAdded:Connect(function(Character)
		local Backpack = Player:WaitForChild("Backpack")
		if Backpack then
			local active = map.ActiveMap
			if active and active.Name == "Winter" then
				RemoveTool(Backpack, "MultiRocket")
			end
		end
	end)
end)