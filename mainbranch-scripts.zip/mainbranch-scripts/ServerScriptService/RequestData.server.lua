--[[
    RequestData (Script)
    Path: ServerScriptService
    Parent: ServerScriptService
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local IncomingRequests = Modules:WaitForChild("IncomingRequests")

local RequestData = Remotes:WaitForChild("RequestData")

RequestData.OnServerInvoke = function(Player, Request, ...)
	local ActionModule = IncomingRequests:FindFirstChild(Request)
	if ActionModule then
		return require(ActionModule)(Player, Request, ...)
	end
end