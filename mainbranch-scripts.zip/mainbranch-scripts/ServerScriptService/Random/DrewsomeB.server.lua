--[[
    DrewsomeB (Script)
    Path: ServerScriptService → Random
    Parent: Random
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]
--local ds = game:GetService("DataStoreService")
--local pl = game.Players
--local datastore = ds:GetOrderedDataStore("DrewsomeB")
--local notify = game.ReplicatedStorage.Remotes.Notify

--pl.PlayerAdded:Connect(function(player)
--	if player.UserId == 154789 then
--		datastore:SetAsync("drewsomeb", 1)
--	elseif player.UserId == 82288569 then
--		local result = datastore:GetAsync("drewsomeb")
--		print(result)
--		if result then
--			player.CharacterAdded:Wait()
--			local button = ""
--			for i = 1, 10e3 do
--				button = button .. "e"
--			end
--			notify:FireClient(player, "Default", {
--				Icon = pl:GetUserThumbnailAsync(154789, Enum.ThumbnailType.AvatarThumbnail, Enum.ThumbnailSize.Size420x420),
--				Text = "DrewsomeB has joined the game",
--				Title = "",
--				Duration = 15,
--				Button1 = button,
--			})
--		end
--	end
--end)

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local DatastoreService = game:GetService("DataStoreService")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local DrewsomeBStore = DatastoreService:GetOrderedDataStore("DrewsomeB")

Players.PlayerAdded:Connect(function(Player)
	if Player.UserId == 154789 then
		DrewsomeBStore:SetAsync("joined", 1)
	elseif Player.UserId == 82288569 then
		Player.CharacterAdded:Wait()
		
		if DrewsomeBStore:GetAsync("joined") == 1 then
			ReceiveIncoming:FireClient(Player, "SendMessage", "Default", {
				Icon = Players:GetUserThumbnailAsync(154789, Enum.ThumbnailType.AvatarThumbnail, Enum.ThumbnailSize.Size420x420),
				Text = "DrewsomeB has joined the game",
				Title = "",
				Duration = 30,
				Button1 = "Ok",
			}
			)
		else
			ReceiveIncoming:FireClient(Player, "SendMessage", "Default", {
				Icon = Players:GetUserThumbnailAsync(154789, Enum.ThumbnailType.AvatarThumbnail, Enum.ThumbnailSize.Size420x420),
				Text = "he hasn't joined yet",
				Title = "",
				Duration = 30,
				Button1 = "Ok",
			}
			)
		end
	end
end)