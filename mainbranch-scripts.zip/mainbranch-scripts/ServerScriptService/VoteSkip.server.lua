--[[
    VoteSkip (Script)
    Path: ServerScriptService
    Parent: ServerScriptService
    Properties:
        Disabled: true
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local VotePercent = 0.6

local Players = game:GetService("Players")

local CurrentVote = {
	Votes = 0,
	Players = {},
	LastVote = os.time()
}

local function Skip()
	local FirstTeam = game.Teams:GetTeams()[1]
	if FirstTeam then
		FirstTeam:SetAttribute("Score", 700)
		CurrentVote.LastVote = os.time()
	end
end

local function IsVoteOver()
	if (CurrentVote.Votes / #Players:GetPlayers()) > VotePercent then
		CurrentVote.Votes = 0
		table.clear(CurrentVote.Players)
		
		Skip()
	end
end

local function CheckPlayers()
	for p, _ in pairs(CurrentVote.Players) do
		if p and not p:IsDescendantOf(Players) then
			CurrentVote.Votes[p] = nil
			CurrentVote.Votes -= 1
		end
	end
end

local function AddVote(Player)
	local HasPlayerVoted = CurrentVote.Players[Player]
	if not HasPlayerVoted then
		CurrentVote.Players[Player] = true
		CurrentVote.Votes += 1
		
		CheckPlayers()
		IsVoteOver()
	end
end

Players.PlayerAdded:Connect(function(Player)
	Player.Chatted:Connect(function(Message)
		if Message == "/skipmap" then
			if os.time() - CurrentVote.LastVote > 10 then
				AddVote(Player)
			end
		end
	end)
end)