--[[
    LocalScript (LocalScript)
    Path: ServerStorage → Storage → StarterPack → Dagger
    Parent: Dagger
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Tools = Modules:WaitForChild("Tools")
local Dagger = Tools:WaitForChild("Dagger")

local WeaponSettings = require(Projectiles:WaitForChild("Settings"))
local DaggerHelper = require(Dagger:WaitForChild("DaggerHelper"))
local SetupIcons = require(Tools:WaitForChild("SetupIcons"))
local LocalToolHelper = require(Tools:WaitForChild("LocalToolHelper"))

local Incoming = Remotes:WaitForChild("ReceiveIncoming")

local Tool = script.Parent
local Handle = Tool:WaitForChild("Handle")
local Equip = Handle:WaitForChild("Equip")
local LungeSound = Handle:WaitForChild("Lunge")
local SlashSound = Handle:WaitForChild("Slash")
local Player = Players.LocalPlayer

local EnabledCursor = "rbxasset://textures//GunCursor.png"
local DisabledCursor = "rbxasset://textures//GunWaitCursor.png"

local LastSwing = tick()
local Debounce = tick()

local function CanDamage()
	local Character = Player.Character
	if Character then
		local RightArm = Character:FindFirstChild("Right Arm")
		if RightArm then
			local RightGrip = RightArm:FindFirstChild("RightGrip")
			if RightGrip then
				return true
			end
		end
	end
end

Tool.Activated:Connect(function()
	if Handle and LocalToolHelper.CanActivate() then
		local Now = tick()
		if (Now - Debounce) >= WeaponSettings.Dagger.LungeDebounce then
			if (Now - LastSwing) <= WeaponSettings.Dagger.MinimumLungeTime then
				DaggerHelper.PlayAnimation(Tool, "Lunge")
				Incoming:FireServer("Dagger", "Lunge")
				DaggerHelper.Float()
				DaggerHelper.LungeAnimation(Tool, true)
				Tool.Enabled = false
				
				task.delay(WeaponSettings.Dagger.LungeTime, function()
					Tool.Enabled = true
				end)
				
				Debounce = Now
			else
				DaggerHelper.PlayAnimation(Tool, "Slash")
				DaggerHelper.SlashAnimation(Tool)
				Incoming:FireServer("Dagger", "Slash")
			end
			
			LastSwing = Now
		end
	end
end)

Tool.Equipped:Connect(function()
	DaggerHelper.PlaySound(Tool, "Equip")
	Incoming:FireServer("Dagger", "Equipped")
end)

Tool.Unequipped:Connect(function()
	Incoming:FireServer("Dagger", "Unequipped")
end)

Handle.Touched:Connect(function(Hit)
	local Character = Hit.Parent
	if Character and CanDamage() then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		if Humanoid then
			Incoming:FireServer("Dagger", "Touched", Hit)
		end
	end
end)

SetupIcons(Tool, EnabledCursor, DisabledCursor)