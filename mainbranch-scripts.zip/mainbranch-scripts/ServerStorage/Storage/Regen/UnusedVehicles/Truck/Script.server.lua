--[[
    Script (Script)
    Path: ServerStorage → Storage → Regen → UnusedVehicles → Truck
    Parent: Truck
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

script.Parent:MakeJoints()