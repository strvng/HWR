--[[
    Setup (Script)
    Path: ServerStorage → Storage → Regen → UnusedVehicles → Truck → Turret
    Parent: Turret
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local TurretFolder = Vehicle:WaitForChild("Turret")

local TurretClass = require(TurretFolder:WaitForChild("Turret"))

local Turret = script.Parent
local NewTurret = TurretClass.new(Turret)