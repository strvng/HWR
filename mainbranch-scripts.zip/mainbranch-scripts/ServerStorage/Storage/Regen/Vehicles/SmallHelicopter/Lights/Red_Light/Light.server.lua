--[[
    Light (Script)
    Path: ServerStorage → Storage → Regen → Vehicles → SmallHelicopter → Lights → Red Light
    Parent: Red Light
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local SetupScripts = Vehicle:WaitForChild("SetupScripts")

local LightScript = require(SetupScripts:WaitForChild("LightScript"))

LightScript(script.Parent)