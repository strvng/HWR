--[[
    Script (Script)
    Path: ServerStorage → Storage → Regen → Vehicles → VipHelicopter → Body → Admin2
    Parent: Admin2
    Properties:
        Disabled: true
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]
11