--[[
    AdminCommands (ModuleScript)
    Path: ServerStorage → Modules → Events → PlayerAdded
    Parent: PlayerAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local AdminFolder = Modules:WaitForChild("Admin")

local CommandHelper = require(AdminFolder:WaitForChild("CommandHelper"))
local RunCommand = require(AdminFolder:WaitForChild("RunCommand"))

local AdminGui = script:WaitForChild("Command")

return function(Player)
	local Level = CommandHelper.GetLevel(Player)
	if Level then
		Player.Chatted:Connect(function(Message)
			RunCommand(Player, Message)
		end)
		
		local NewMenu = AdminGui:Clone()
		NewMenu.Parent = Player:WaitForChild("PlayerGui")
	end
end