--[[
    ReplicateVip (ModuleScript)
    Path: ServerStorage → Modules → Events → PlayerAdded
    Parent: PlayerAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local SetupFolder = MapFolder:WaitForChild("Setup")

local VipReplicator = require(SetupFolder:WaitForChild("VipReplicator"))

return function(Player)
	VipReplicator:ReplicateToPlayer(Player)
end