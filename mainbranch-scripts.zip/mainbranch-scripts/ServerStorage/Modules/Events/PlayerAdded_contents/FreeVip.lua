--[[
    FreeVip (ModuleScript)
    Path: ServerStorage → Modules → Events → PlayerAdded
    Parent: PlayerAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local AdminFolder = Modules:WaitForChild("Admin")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local GamepassFolder = ReplicatedModules:WaitForChild("Gamepass")
local ServerGamepassFolder = Modules:WaitForChild("Gamepass")

local Marketplace = require(ServerGamepassFolder:WaitForChild("Marketplace"))
local Gamepasses = require(GamepassFolder:WaitForChild("Gamepasses"))
local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local FreeVipUsers = require(AdminFolder:WaitForChild("FreeVipUsers"))

local function IsFreeVipUser(Player)
	return table.find(FreeVipUsers, Player.UserId)
end

return function(Player)
	if IsFreeVipUser(Player) then
		for _, v in pairs(Gamepasses) do
			if not v.IsDevProduct then
				Marketplace:SetGamepassOwned(Player, v.Id)
			end
		end
	end
end