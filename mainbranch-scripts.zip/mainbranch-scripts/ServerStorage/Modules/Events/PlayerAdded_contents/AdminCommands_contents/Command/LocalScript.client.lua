--[[
    LocalScript (LocalScript)
    Path: ServerStorage → Modules → Events → PlayerAdded → AdminCommands → Command
    Parent: Command
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:25
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local Gui = script.Parent
local Container = Gui:WaitForChild("Frame")
local CommandTextbox = Container:WaitForChild("Command")

local function SetGuiVisible(Visible)
	if Visible then
		Gui.Enabled = true
		RunService.RenderStepped:Wait()
		CommandTextbox:CaptureFocus()
	else
		CommandTextbox:ReleaseFocus(false)
		Gui.Enabled = false
	end
end

UserInputService.InputBegan:Connect(function(InputObject, GameProcessed)
	if InputObject.KeyCode == Enum.KeyCode.Comma and not GameProcessed then
		if not Gui.Enabled then
			SetGuiVisible(true)
		end
	end
end)

CommandTextbox.FocusLost:Connect(function(EnterPressed)
	if EnterPressed and CommandTextbox.Text ~= "" then
		ReceiveIncoming:FireServer("ExecuteCommand", CommandTextbox.Text)
	end
	
	SetGuiVisible(false)
end)