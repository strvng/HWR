--[[
    Stats (ModuleScript)
    Path: ServerStorage → Modules → Events → PlayerAdded
    Parent: PlayerAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")

local StatController = require(Round:WaitForChild("StatController"))
local RoundController = require(Round:WaitForChild("RoundController"))

return function(Player)
	local ActiveStats = StatController.ActiveStats
	if ActiveStats and RoundController.ActiveRound then
		StatController.Apply(Player, ActiveStats)
	end
end