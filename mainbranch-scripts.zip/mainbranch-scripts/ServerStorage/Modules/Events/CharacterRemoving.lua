--[[
    CharacterRemoving (ModuleScript)
    Path: ServerStorage → Modules → Events
    Parent: Events
    Exported: 2026-09-21 11:23:25
]]
local Modules = {}

local ServerStorage = game:GetService("ServerStorage")

local ModulesFolder = ServerStorage:WaitForChild("Modules")
local Events = ModulesFolder:WaitForChild("Events")

local Died = require(Events:WaitForChild("Died"))

for i, v in pairs(script:GetChildren()) do
	table.insert(Modules, require(v))
end

return function(Player, Character)
	for i, v in pairs(Modules) do
		v(Player, Character)
	end
end