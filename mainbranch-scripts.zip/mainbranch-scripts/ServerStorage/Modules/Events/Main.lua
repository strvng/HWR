--[[
    Main (ModuleScript)
    Path: ServerStorage → Modules → Events
    Parent: Events
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")

local Events = Modules:WaitForChild("Events")

local PlayerAdded = require(Events:WaitForChild("PlayerAdded"))
local CharacterAdded = require(Events:WaitForChild("CharacterAdded"))
local PlayerRemoving = require(Events:WaitForChild("PlayerRemoving"))
local CharacterRemoving = require(Events:WaitForChild("CharacterRemoving"))

Players.PlayerAdded:Connect(function(Player)
	Player.CharacterAdded:Connect(function(Character)
		CharacterAdded(Player, Character)
	end)
	
	Player.CharacterRemoving:Connect(function(Character)
		CharacterRemoving(Player, Character)
	end)
	
	PlayerAdded(Player)
end)

Players.PlayerRemoving:Connect(function(Player)	
	PlayerRemoving(Player)
end)

return nil