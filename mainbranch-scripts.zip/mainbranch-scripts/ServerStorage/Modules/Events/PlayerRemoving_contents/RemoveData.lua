--[[
    RemoveData (ModuleScript)
    Path: ServerStorage → Modules → Events → PlayerRemoving
    Parent: PlayerRemoving
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local DataHandler = Modules:WaitForChild("DataHandler")

local Data = require(DataHandler:WaitForChild("Data"))

return function(Player)
	Data:RemoveData(Player)
end