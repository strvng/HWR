--[[
    CharacterAdded (ModuleScript)
    Path: ServerStorage → Modules → Events
    Parent: Events
    Exported: 2026-09-21 11:23:25
]]
local Modules = {}

local ServerStorage = game:GetService("ServerStorage")

local ModulesFolder = ServerStorage:WaitForChild("Modules")
local Events = ModulesFolder:WaitForChild("Events")

local Died = require(Events:WaitForChild("Died"))

for i, v in pairs(script:GetChildren()) do
	table.insert(Modules, require(v))
end

return function(Player, Character)
	local Humanoid = Character:FindFirstChild("Humanoid")
	
	for i, v in pairs(Modules) do
		v(Character, Player)
	end
	
	if Humanoid then
		local Connection;
		
		Connection = Humanoid.Died:Connect(function()
			Died(Player, Character, Humanoid)
			Connection:Disconnect()
			Connection = nil
		end)
	end
end