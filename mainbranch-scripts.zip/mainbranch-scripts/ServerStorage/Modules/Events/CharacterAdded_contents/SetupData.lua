--[[
    SetupData (ModuleScript)
    Path: ServerStorage → Modules → Events → CharacterAdded
    Parent: CharacterAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local DataHandler = Modules:WaitForChild("DataHandler")
local DataHandlerGeneral = DataHandler:WaitForChild("General")
local SettingsFolder = ReplicatedModules:WaitForChild("Settings")
local InventoryGeneral = DataHandlerGeneral:WaitForChild("Inventory")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local Utilites = ReplicatedModules:WaitForChild("Utilities")

local Marketplace = require(GamepassFolder:WaitForChild("Marketplace"))
local LoadStarterGear = require(InventoryGeneral:WaitForChild("LoadStarterGear"))
local DefaultTools = require(SettingsFolder:WaitForChild("DefaultTools"))
local Data = require(DataHandler:WaitForChild("Data"))
local GetDictionaryLength = require(Utilites:WaitForChild("GetDictionaryLength"))
local Settings = require(Modules:WaitForChild("Settings"))

local DefaultToolsClone = table.clone(DefaultTools)

return function(Character, Player)
	local Tools = DefaultToolsClone
	
	local PlayerData = Data:GetPlayer(Player)
	
	if Marketplace:UserOwnsGamepass(Player, Settings.Vip.SortGamepassId) then
		if PlayerData then
			local ToolData = PlayerData.Tools:Get()
			if ToolData then
				Tools = ToolData
			end
		end
	end
	
	LoadStarterGear(Player, Tools, true)
end