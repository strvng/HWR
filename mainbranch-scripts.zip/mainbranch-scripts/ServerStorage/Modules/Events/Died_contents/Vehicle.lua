--[[
    Vehicle (ModuleScript)
    Path: ServerStorage → Modules → Events → Died
    Parent: Died
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local VehicleFolder = Modules:WaitForChild("Vehicle")
local General = Modules:WaitForChild("General")

local VehicleRegistry = require(VehicleFolder:WaitForChild("VehicleRegistry"))
local Dictionaries = require(General:WaitForChild("Dictionaries"))

return function(Player)
	local Vehicle = VehicleRegistry:Get(Player)
	if Vehicle then
		local Model = Vehicle.Vehicle
		if Model then
			Model:BreakJoints()
		end
	end
end