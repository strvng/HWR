--[[
    General (ModuleScript)
    Path: ServerStorage → Modules → Events → Died
    Parent: Died
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")

local ScoreManager = require(General:WaitForChild("ScoreManager"))

return function(Player)
	ScoreManager:AddScore(Player, "WOs", 1)
end