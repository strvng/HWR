--[[
    TeamKilling (ModuleScript)
    Path: ServerStorage → Modules → Events → Died
    Parent: Died
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")
local Gamepass = Modules:WaitForChild("Gamepass")
local GamepassGeneral = Gamepass:WaitForChild("General")
local Round = Modules:WaitForChild("Round")
local SettingsFolder = ReplicatedModules:WaitForChild("Settings")
local DataHandler = Modules:WaitForChild("DataHandler")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local DataController = require(DataHandler:WaitForChild("Data"))
local Dictionaries = require(General:WaitForChild("Dictionaries"))
local ScoreManager = require(General:WaitForChild("ScoreManager"))
local Settings = require(Modules:WaitForChild("Settings"))
local Marketplace = require(Gamepass:WaitForChild("Marketplace"))
local GiveXP = require(GamepassGeneral:WaitForChild("GiveXP"))
local TeamController = require(Round:WaitForChild("TeamController"))
local UI = require(SettingsFolder:WaitForChild("UI"))

return function(Player)
	local Data = Dictionaries.Tagged[Player]
	if Data then
		local Attacker = Data.Attacker
		local AttackerData = DataController:GetPlayer(Attacker)
		--local DataFolder = Data.Attacker:FindFirstChild("Data")
		if AttackerData then
			if Attacker ~= Player then
				if Attacker.Team == Player.Team then
					local Character = Player.Character
					if Character then
						Character:BreakJoints()
					end
				else
					local XPAmount = Settings.Levels.KillXP
					
					if Marketplace:UserOwnsGamepass(Attacker, Settings.Vip.DoubleXPGamepassId) then
						XPAmount = Settings.Levels.DoubleXP
					end
					
					GiveXP(Attacker, XPAmount)
					--XP.Value += XPAmount
					ReceiveIncoming:FireClient(Attacker, "KillConfirmed", Player, XPAmount)
					
					ScoreManager:AddScore(Data.Attacker, "KOs", 1)
					
					local EnemyTeam = Attacker.Team
					if EnemyTeam then
						TeamController.IncrementScore(EnemyTeam, Settings.Round.KillScore)
						--Score:IncrementScore(EnemyTeam.Name, Settings.Round.KillScore)
						--Score:GiveTeamScore(EnemyTeam.Name, Settings.Round.KillScore)
					end
				end
			else
				ScoreManager:TakeScore(Player, "KOs", 1)
			end
		end
		
		Dictionaries.Tagged[Player] = nil
		ReceiveIncoming:FireClient(Player, "Spectate", Attacker, Data.Weapon)
	end
end