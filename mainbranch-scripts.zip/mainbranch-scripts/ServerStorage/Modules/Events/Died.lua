--[[
    Died (ModuleScript)
    Path: ServerStorage → Modules → Events
    Parent: Events
    Exported: 2026-09-21 11:23:25
]]
local Modules = {}

for i, v in pairs(script:GetChildren()) do
	table.insert(Modules, require(v))
end

return function(Player, Character, Humanoid)
	for i, v in pairs(Modules) do
		v(Player, Character, Humanoid)
	end
end