--[[
    API (ModuleScript)
    Path: ServerStorage → Modules → Uniforms
    Parent: Uniforms
    Exported: 2026-09-21 11:23:28
]]
--[[

Uniform API
This library provides functions for setting character uniforms.

PROPERTIES

API.UniformsFolder: Folder
	A folder containing all uniforms in the game.

FUNCTIONS

API.SetCharacterUniform(character: Model, uniformFolder: Folder): nil
	Removes the character's pants and shirt, then puts the pants, shirt and any accessories in
	the uniformFolder into the character. uniformFolder may be a child of
	API.UniformsFolder.

]]

local environment = script.Parent

local API = {
	UniformsFolder = environment.Uniform
}

function API.clearCharacter(character)
	local existingShirt = character:WaitForChild("Shirt")
	local existingPants = character:WaitForChild("Pants")
	local existingShirtGraphic = character:FindFirstChildWhichIsA("ShirtGraphic")
	
	if existingShirt then
		existingShirt:Destroy()
	end
	
	if existingPants then
		existingPants:Destroy()
	end
	
	if existingShirtGraphic then
		existingShirtGraphic:Destroy()
	end
end

function API.SetCharacterUniform(character, uniformFolder)
	API.clearCharacter(character)
	
	for _, item in uniformFolder:GetChildren() do
		if item:IsA("Accroutment") then
			local Humanoid = character:FindFirstChildWhichIsA("Humanoid")
			if Humanoid then
				local newItem = item:Clone()
				
				Humanoid:AddAccessory(newItem)
			end
		else
			item:Clone().Parent = character
		end
	end
end

return API