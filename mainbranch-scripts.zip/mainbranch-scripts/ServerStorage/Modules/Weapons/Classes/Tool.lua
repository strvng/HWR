--[[
    Tool (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Classes
    Parent: Classes
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local General = Weapons:WaitForChild("General")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local OriginCheck = require(General:WaitForChild("OriginCheck"))
local Requests = require(Weapons:WaitForChild("Requests"))

local Tool = {
	RequiresTool = false,
	Name = "",
}
Tool.__index = Tool

function Tool:AddRequest(Player, Tool, Type, Id, Origin, Endpoint)
	if OriginCheck(Player, Origin, self) then
		local Handle = Tool:FindFirstChild("Handle")
		
		if Handle then
			ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origin, Endpoint)
		end
		
		Requests:Add(Player, Type, Id, Origin, Endpoint)
	end
end

function Tool:RemoveRequest(Player, Id, ...)
	
end

return Tool