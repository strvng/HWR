--[[
    M24 (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local TeamFolder = Modules:WaitForChild("Teamkill")
local Tag = Modules:WaitForChild("Tag")
local General = Weapons:WaitForChild("General")

local AreTeammates = require(TeamFolder:WaitForChild("AreTeammates"))
local TagPlayer = require(Tag:WaitForChild("Main"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))
local Weapon = require(Classes:WaitForChild("Tool"))
local OriginCheck = require(General:WaitForChild("OriginCheck"))

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local M24 = setmetatable({}, Weapon)
M24.Name = "M24"
M24.RequiresTool = true

function M24:AddRequest(Player, Tool, Type, Id, Origin, Endpoint)
	if OriginCheck(Player, Origin, self) then
		local Handle = Tool:FindFirstChild("Handle")
		
		if Handle then
			ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origin, Endpoint, Handle)
		end
		
		Requests:Add(Player, Type, Id, Origin, Endpoint)
	end
end

function M24:RemoveRequest(Player, Id, ...)
	local HitPart = ...
	
	local HitPlayer = Players:GetPlayerFromCharacter(HitPart:FindFirstAncestorWhichIsA("Model"))
	if HitPlayer and not AreTeammates(Player, HitPlayer) then
		local Character = HitPlayer.Character
		if Character then
			local Humanoid = Character:FindFirstChild("Humanoid")
			if Humanoid then
				Humanoid:TakeDamage(Settings.Weapons.M24.Damage)
				
				TagPlayer(HitPlayer, Player, 5, "M24")
			end
		end
	end
	
	Requests:Remove(Id)
end

function M24:IsValidAddData(Origin, Endpoint)
	assert(typeof(Origin) == "Vector3")
	assert(typeof(Endpoint) == "Vector3")
	
	return true
end

function M24:IsValidRemoveData(HitPart)
	assert(typeof(HitPart) == "Instance")
	assert(HitPart:IsA("BasePart"))
	assert(HitPart.Parent)
	
	return true
end

return M24