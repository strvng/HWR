--[[
    AK47 (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local TeamFolder = Modules:WaitForChild("Teamkill")
local Tag = Modules:WaitForChild("Tag")
local General = Weapons:WaitForChild("General")

local AreTeammates = require(TeamFolder:WaitForChild("AreTeammates"))
local TagPlayer = require(Tag:WaitForChild("Main"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))
local Weapon = require(Classes:WaitForChild("Tool"))
local OriginCheck = require(General:WaitForChild("OriginCheck"))

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local AK47 = setmetatable({}, Weapon)
AK47.Name = "AK47"
AK47.RequiresTool = true

function AK47:AddRequest(Player, Tool, Type, Id, Origin, Endpoint)
	if OriginCheck(Player, Origin, self) then
		local Handle = Tool:FindFirstChild("Handle")
		
		if Handle then
			ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origin, Endpoint, Handle)
		end
		
		Requests:Add(Player, Type, Id, Origin, Endpoint)
	end
end

function AK47:RemoveRequest(Player, Id, ...)
	local HitPart = ...
	
	local HitPlayer = Players:GetPlayerFromCharacter(HitPart:FindFirstAncestorWhichIsA("Model"))
	if HitPlayer and not AreTeammates(Player, HitPlayer) then
		local Character = HitPlayer.Character
		if Character then
			local Humanoid = Character:FindFirstChild("Humanoid")
			if Humanoid then
				Humanoid:TakeDamage(Settings.Weapons.AK47.Damage)
				
				TagPlayer(HitPlayer, Player, 5, "AK47")
			end
		end
	end
	
	Requests:Remove(Id)
end

function AK47:IsValidAddData(Origin, Endpoint)
	assert(typeof(Origin) == "Vector3")
	assert(typeof(Endpoint) == "Vector3")
	
	return true
end

function AK47:IsValidRemoveData(HitPart)
	assert(typeof(HitPart) == "Instance")
	assert(HitPart:IsA("BasePart"))
	assert(HitPart.Parent)
	
	return true
end

return AK47