--[[
    VipMissile (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local ExplosionFolder = Modules:WaitForChild("Explosions")
local General = Weapons:WaitForChild("General")

local CompareExplosion = require(General:WaitForChild("CompareExplosion"))
local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local HandleExplosion = require(ExplosionFolder:WaitForChild("HandleExplosion"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))

local VipMissile = {}
VipMissile.Name = "VIPHeli"
VipMissile.RequiresTool = false
VipMissile.VehicleType = "VIPHelicopter"
VipMissile.DisplayName = "Vip Missile"

function VipMissile:AddRequest(Player, Type, Id, Origins)
	ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origins)
	
	Requests.List[Id] = {
		Player = Player,
		Type = Type,
		Id = Id,
		MissileCount = 0,
	}
end

function VipMissile:RemoveRequest(Player, Id, ...)
	local Data = Requests:Get(Id)
	local Position, Hit = ...
	
	Data.MissileCount += 1
	
	if Data then
		HandleExplosion(Player, Data.Type, Hit)
	end
	
	if Data.MissileCount >= Settings.Weapons.VipMissile.MaxRocketCount then
		Requests:Remove(Id)
	end
end

function VipMissile:IsValidAddData()
	return true
end

function VipMissile:IsValidRemoveData(Position, HitParts)
	assert(typeof(HitParts) == "table")
	assert(table.foreach(HitParts, function(i, v)
		if not typeof(v) == "Instance" and not v:IsA("BasePart") and v.Parent then
			return false
		end
	end) ~= false)
	assert(CompareExplosion(Position, HitParts))
	
	return true
end

return VipMissile