--[[
    HomingMissile (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local General = Weapons:WaitForChild("General")
local ExplosionFolder = Modules:WaitForChild("Explosions")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local HandleExplosion = require(ExplosionFolder:WaitForChild("HandleExplosion"))
local CompareExplosion = require(General:WaitForChild("CompareExplosion"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))

local HomingMissile = {}
HomingMissile.Name = "VIPHeli"
HomingMissile.RequiresTool = false
HomingMissile.VehicleType = "VIPHelicopter"
HomingMissile.DisplayName = "Homing Missile"

function HomingMissile:AddRequest(Player, Type, Id, Origins, Target)
	ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origins, Target)
	
	Requests.List[Id] = {
		Player = Player,
		Type = Type,
		Id = Id,
		MissileCount = 0,
	}
end

function HomingMissile:RemoveRequest(Player, Id, ...)
	local Data = Requests:Get(Id)
	local Position, Hit = ...
	
	Data.MissileCount += 1
	
	if Data then
		HandleExplosion(Player, HomingMissile.DisplayName, Hit)
	end
	
	if Data.MissileCount >= Settings.Weapons.VipMissile.MaxRocketCount then
		Requests:Remove(Id)
	end
end

function HomingMissile:IsValidAddData(Origins, Target)
	assert(typeof(Origins) == "table")
	assert(typeof(Target) == "Instance")
	
	return true
end

function HomingMissile:IsValidRemoveData(Position, HitParts)
	assert(typeof(HitParts) == "table")
	assert(table.foreach(HitParts, function(i, v)
		if not typeof(v) == "Instance" and not v:IsA("BasePart") and v.Parent then
			return false
		end
	end) ~= false)
	assert(CompareExplosion(Position, HitParts))
	
	return true
end

return HomingMissile