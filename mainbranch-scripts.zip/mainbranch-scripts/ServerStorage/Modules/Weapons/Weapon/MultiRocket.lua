--[[
    MultiRocket (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local ExplosionFolder = Modules:WaitForChild("Explosions")
local General = Weapons:WaitForChild("General")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local HandleExplosion = require(ExplosionFolder:WaitForChild("HandleExplosion"))
local CompareExplosion = require(General:WaitForChild("CompareExplosion"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))
local Weapon = require(Classes:WaitForChild("Tool"))

local MultiRocket = setmetatable({}, Weapon)
MultiRocket.Name = "MultiRocket"
MultiRocket.RequiresTool = true

function MultiRocket:AddRequest(Player, Tool, Type, Id, Origin, Endpoint)
	local Handle = Tool:FindFirstChild("Handle")
	
	if Handle then
		ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origin, Endpoint)
	end
	
	Requests.List[Id] = {
		Player = Player,
		Type = Type,
		Id = Id,
		Origin = Origin,
		Endpoint = Endpoint,
		RocketCount = 0,
	}
end

function MultiRocket:RemoveRequest(Player, Id, ...)
	local Data = Requests:Get(Id)
	local Position, Hit = ...
	
	Data.RocketCount += 1
	
	if Data then
		HandleExplosion(Player, Data.Type, Hit)
	end
	
	if Data.RocketCount >= Settings.Weapons.MultiRocket.MaxRocketCount then
		Requests:Remove(Id)
	end
end

function MultiRocket:IsValidAddData(Origin, Endpoint)
	assert(typeof(Origin) == "Vector3")
	assert(typeof(Endpoint) == "Vector3")

	return true
end

function MultiRocket:IsValidRemoveData(Position, HitParts)
	assert(typeof(HitParts) == "table")
	assert(table.foreach(HitParts, function(i, v)
		if not typeof(v) == "Instance" and not v:IsA("BasePart") and v.Parent then
			return false
		end
	end) ~= false)
	assert(CompareExplosion(Position, HitParts))
	
	return true
end

return MultiRocket