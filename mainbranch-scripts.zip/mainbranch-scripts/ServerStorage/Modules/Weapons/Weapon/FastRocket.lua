--[[
    FastRocket (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local ExplosionFolder = Modules:WaitForChild("Explosions")
local General = Weapons:WaitForChild("General")

local CompareExplosion = require(General:WaitForChild("CompareExplosion"))
local HandleExplosion = require(ExplosionFolder:WaitForChild("HandleExplosion"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Weapon = require(Classes:WaitForChild("Tool"))

local FastRocket = setmetatable({}, Weapon)
FastRocket.Name = "FastRocket"
FastRocket.RequiresTool = true

function FastRocket:RemoveRequest(Player, Id, ...)
	local Data = Requests:Get(Id)
	local Position, Hit = ...
	
	if Data then
		HandleExplosion(Player, Data.Type, Hit)
	end
	
	Requests:Remove(Id)
end

function FastRocket:IsValidAddData(Origin, Endpoint)
	assert(typeof(Origin) == "Vector3")
	assert(typeof(Endpoint) == "Vector3")
	
	return true
end

function FastRocket:IsValidRemoveData(Position, HitParts)
	assert(typeof(HitParts) == "table")
	assert(table.foreach(HitParts, function(i, v)
		if typeof(v) ~= "Instance" and not v:IsA("BasePart") and v.Parent then
			return false
		end
	end) ~= false)
	assert(CompareExplosion(Position, HitParts))
	
	return true
end

return FastRocket