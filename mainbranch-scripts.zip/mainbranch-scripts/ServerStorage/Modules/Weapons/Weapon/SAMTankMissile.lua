--[[
    SAMTankMissile (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local ExplosionFolder = Modules:WaitForChild("Explosions")
local General = Weapons:WaitForChild("General")

local CompareExplosion = require(General:WaitForChild("CompareExplosion"))
local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local HandleExplosion = require(ExplosionFolder:WaitForChild("HandleExplosion"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))

local SAMTankMissile = {}

SAMTankMissile.Name = "SAMTank"
SAMTankMissile.RequiresTool = false
SAMTankMissile.VehicleType = "SAMTank"
SAMTankMissile.DisplayName = "SAM Tank Missile"

function SAMTankMissile:AddRequest(Player, Type, Id, Origins)
	ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origins)
	
	Requests.List[Id] = {
		Player = Player,
		Type = Type,
		Id = Id,
	}
end

function SAMTankMissile:RemoveRequest(Player, Id, ...)
	local Data = Requests:Get(Id)
	local Position, Hit = ...
	
	if Data then
		HandleExplosion(Player, SAMTankMissile.DisplayName, Hit)
	end
	
	Requests:Remove(Id)
end

function SAMTankMissile:IsValidAddData()
	return true
end

function SAMTankMissile:IsValidRemoveData(Position, HitParts)
	assert(typeof(HitParts) == "table")
	assert(table.foreach(HitParts, function(i, v)
		if not typeof(v) == "Instance" and not v:IsA("BasePart") and v.Parent then
			return false
		end
	end) ~= false)
	assert(CompareExplosion(Position, HitParts))
	
	return true
end

return SAMTankMissile