--[[
    Bomb (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local ExplosionFolder = Modules:WaitForChild("Explosions")
local GeneralFolder = Weapons:WaitForChild("General")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local CompareExplosion = require(GeneralFolder:WaitForChild("CompareExplosion"))
local HandleExplosion = require(ExplosionFolder:WaitForChild("HandleExplosion"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))

local Bomb = {}
Bomb.Name = "VIPHeli"
Bomb.RequiresTool = false
Bomb.VehicleType = "VIPHelicopter"

function Bomb:AddRequest(Player, Type, Id, Origin)
	ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origin)
	
	Requests.List[Id] = {
		Player = Player,
		Type = Type,
		Id = Id,
	}
end

function Bomb:RemoveRequest(Player, Id, ...)
	local Data = Requests:Get(Id)
	local Position, Hit = ...
	
	if Data then
		HandleExplosion(Player, Data.Type, Hit)
	end
	
	Requests:Remove(Id)
end

function Bomb:IsValidAddData()
	return true
end

function Bomb:IsValidRemoveData(Position, HitParts)
	assert(typeof(HitParts) == "table")
	assert(table.foreach(HitParts, function(i, v)
		if not typeof(v) == "Instance" and not v:IsA("BasePart") and v.Parent then
			return false
		end
	end) ~= false)
	assert(CompareExplosion(Position, HitParts))

	return true
end

return Bomb