--[[
    JeepBullet (ModuleScript)
    Path: ServerStorage → Modules → Weapons → Weapon
    Parent: Weapon
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Classes = Weapons:WaitForChild("Classes")
local TagFolder = Modules:WaitForChild("Tag")
local TeamFolder = Modules:WaitForChild("Teamkill")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local AreTeammates = require(TeamFolder:WaitForChild("AreTeammates"))
local TagPlayer = require(TagFolder:WaitForChild("Main"))
local Requests = require(Weapons:WaitForChild("Requests"))
local Settings = require(Modules:WaitForChild("Settings"))

local JeepBullet = {}

JeepBullet.Name = "Jeep"
JeepBullet.RequiresTool = false
JeepBullet.VehicleType = "Jeep"
JeepBullet.DisplayName = "Jeep Bullet"

function JeepBullet:AddRequest(Player, Type, Id, Origin)
	ReceiveIncoming:FireAllClients("Visualize", Player, Type, Origin)
	
	Requests.List[Id] = {
		Player = Player,
		Type = Type,
		Id = Id,
	}
end

function JeepBullet:RemoveRequest(Player, Id, ...)
	local Data = Requests:Get(Id)
	local HitPart = ...
	
	local HitPlayer = Players:GetPlayerFromCharacter(HitPart.Parent)
	if HitPlayer and not AreTeammates(Player, HitPlayer) then
		local Character = HitPlayer.Character
		if Character then
			local Humanoid = Character:FindFirstChild("Humanoid")
			if Humanoid then
				Humanoid:TakeDamage(Settings.Weapons.JeepBullet.Damage)
				
				TagPlayer(HitPlayer, Player, 5, JeepBullet.DisplayName)
			end
		end
	end
	
	Requests:Remove(Id)
end

function JeepBullet:IsValidAddData(Origin)
	assert(typeof(Origin) == "CFrame")
	
	return true
end

function JeepBullet:IsValidRemoveData(Hit)
	assert(typeof(Hit) == "Instance")
	assert(Hit:IsA("BasePart"))
	assert(Hit.Parent)

	return true
end

return JeepBullet