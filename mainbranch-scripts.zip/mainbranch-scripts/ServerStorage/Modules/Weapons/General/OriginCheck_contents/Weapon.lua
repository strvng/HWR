--[[
    Weapon (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General → OriginCheck
    Parent: OriginCheck
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:28
]]
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")

local Settings = require(Modules:WaitForChild("Settings"))

local MaxDistance = Settings.Weapons.OriginLatency

return function(Player, Origin)
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChild("Humanoid")
		if Humanoid then
			local RootPart = Humanoid.RootPart
			if RootPart then
				local Distance = (RootPart.Position - Origin)
				
				if Distance.Magnitude <= MaxDistance then
					return true
				end
			end
		end
	end
end