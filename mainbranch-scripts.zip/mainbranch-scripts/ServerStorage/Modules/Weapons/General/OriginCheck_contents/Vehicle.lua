--[[
    Vehicle (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General → OriginCheck
    Parent: OriginCheck
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Vehicle = ReplicatedModules:WaitForChild("Vehicle")

local Settings = require(Modules:WaitForChild("Settings"))
--local VehicleController = require(Vehicle:WaitForChild("VehicleController"))
--local FindVehicle = require(ReplicatedModules:WaitForChild("FindVehicle"))

local MaxDistance = Settings.Weapons.VehicleOriginLatency

-- this never runs it just always returns true

return function(Player, Guns)
	local Vehicle = VehicleController.GetVehicle(Player)
	if Vehicle then
		local Engine = Vehicle:FindFirstChild("Engine")
		if Engine then
			local Distance = Engine.Position - Origin
			
			return Distance.Magntiude <= MaxDistance
		end
	end
end