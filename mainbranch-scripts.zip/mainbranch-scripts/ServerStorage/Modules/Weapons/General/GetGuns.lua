--[[
    GetGuns (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")

local FindVehicle = require(Modules:WaitForChild("FindVehicle"))

return function(Player, OverrideName)
	local Vehicle = FindVehicle:GetVehicle(Player)
	if Vehicle then
		local Type = FindVehicle:GetVehicleType(Vehicle)
		if Type then
			local Module = script:FindFirstChild(Type)
			if Module then
				return require(Module)(Vehicle, OverrideName)
			end
		end
	end
end