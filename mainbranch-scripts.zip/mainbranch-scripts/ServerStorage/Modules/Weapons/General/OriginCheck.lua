--[[
    OriginCheck (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

local Weapon = require(script:WaitForChild("Weapon"))
local Vehicle = require(script:WaitForChild("Vehicle"))

return function(Player, Origin, Module)
	local IsVehicle = Module.VehicleType
	if IsVehicle then
		--return Vehicle(Player, Origin)
		-- idk why i did this but it's probably for the better because of lag and desync
		return true
	else
		return Weapon(Player, Origin)
	end
end