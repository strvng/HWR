--[[
    CompareExplosion (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")

local Settings = require(Modules:WaitForChild("Settings"))

return function(Origin, Parts)
	local ValidHits = {}
	
	for i, v in pairs(Parts) do
		local Distance = (v.Position - Origin)
		if Distance.Magnitude <= Settings.Weapons.ExplosionLatency then -- adjust range for vehicles and add a setting for it
			table.insert(ValidHits, v)
		end
	end
	
	if ValidHits ~= {} then
		return ValidHits
	else
		return false
	end
end