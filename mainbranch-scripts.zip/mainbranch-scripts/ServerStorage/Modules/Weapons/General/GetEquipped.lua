--[[
    GetEquipped (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

return function(Player, Name)
	local Character = Player.Character
	if Character then
		local Tool = Character:FindFirstChild(Name)
		if Tool and Tool:IsA("Tool") then
			return Tool
		end
	end
end