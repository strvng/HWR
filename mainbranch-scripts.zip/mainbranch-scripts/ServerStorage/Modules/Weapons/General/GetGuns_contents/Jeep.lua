--[[
    Jeep (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General → GetGuns
    Parent: GetGuns
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:28
]]

return function(Vehicle)
	local Gun = Vehicle:FindFirstChild("MachineGun")
	if Gun then
		return Gun
	end
end