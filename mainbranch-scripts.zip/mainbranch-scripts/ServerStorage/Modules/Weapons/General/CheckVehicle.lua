--[[
    CheckVehicle (ModuleScript)
    Path: ServerStorage → Modules → Weapons → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")

local VehicleHelper = require(Vehicle:WaitForChild("VehicleHelper"))
--local FindVehicle = require(Modules:WaitForChild("FindVehicle"))

return function(Player, Module)
	if Module.VehicleType then
		local Vehicle = VehicleHelper.GetVehicle(Player)
		if Vehicle then
			local VehicleType = VehicleHelper.GetControllerType(Vehicle)
			if VehicleType then
				return VehicleType == Module.VehicleType
			end
		else
			return false
		end
	else
		return true
	end
end