--[[
    Requests (ModuleScript)
    Path: ServerStorage → Modules → Weapons
    Parent: Weapons
    Exported: 2026-09-21 11:23:28
]]
local Controller = {
	List = {}
}

function Controller:Add(Player, Type, Id, Origin, Endpoint)
	self.List[Id] = {
		Player = Player,
		Type = Type,
		Origin = Origin,
		Endpoint = Endpoint,
		Started = tick()
	}
end

function Controller:Get(Id)
	return self.List[Id]
end

function Controller:Remove(Id)
	self.List[Id] = nil
end

return Controller