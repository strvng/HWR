--[[
    ParachuteController (ModuleScript)
    Path: ServerStorage → Modules → Parachute
    Parent: Parachute
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local ParachuteFolder = Modules:WaitForChild("Parachute")
local ParachutesFolder = ParachuteFolder:WaitForChild("Parachutes")
local Tools = ReplicatedModules:WaitForChild("Tools")

local ToolHelper = require(Tools:WaitForChild("ToolHelper"))

local ParachuteController = {}

function ParachuteController.GetBaseHandle(Tool)
	return Tool:FindFirstChild("Handle")
end

function ParachuteController.GetParachute(Player)
	local Tool = ToolHelper.FindTool(Player, "Parachute")
	if Tool then
		local BaseHandle = ParachuteController.GetBaseHandle(Tool)
		if BaseHandle then
			return Tool, BaseHandle
		end
	end
end

function ParachuteController.ClearParachuteCustomization(Tool, BaseHandle)
	for _, v in pairs(BaseHandle:GetChildren()) do
		if not v:IsA("BodyVelocity") then
			v:Destroy()
		end
	end
	
	BaseHandle.Transparency = 0
	BaseHandle.Reflectance = 0.5
	Tool.Grip = CFrame.new(1.5, -4, -1.37)
	BaseHandle.BrickColor = BrickColor.new("Electric blue")
	BaseHandle.MaterialVariant = ""
	BaseHandle.Material = Enum.Material.Plastic
end

function ParachuteController.ApplyCustomization(Tool, Type)
	local CurrentParachuteFolder = ParachutesFolder:FindFirstChild(Type)
	if CurrentParachuteFolder then
		local BaseHandle = ParachuteController.GetBaseHandle(Tool)
		if BaseHandle then
			ParachuteController.ClearParachuteCustomization(Tool, BaseHandle)
			
			local ApplyModule = CurrentParachuteFolder:FindFirstChild("Apply")
			
			if not ApplyModule or (ApplyModule and ApplyModule:GetAttribute("ApplyFolderContent")) then
				for _, v in pairs(CurrentParachuteFolder:GetChildren()) do
					if not v:IsA("ModuleScript") then
						local NewItem = v:Clone()
						NewItem.Parent = BaseHandle
					end
				end
			end
			
			if ApplyModule then
				require(ApplyModule)(Tool, BaseHandle)
			end
		end
	end
end

return ParachuteController