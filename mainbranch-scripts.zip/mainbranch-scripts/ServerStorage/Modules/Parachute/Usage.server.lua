--[[
    Usage (Script)
    Path: ServerStorage → Modules → Parachute
    Parent: Parachute
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:25
]]

--[[

to create a parachute put all the content in a folder under the parachutes folder
and all the instances within the parachute will be parented to the handle

if further customization is needed add a modulescript called 'Apply' that returns a function.
the first parameter is the handle to the parachute

]]