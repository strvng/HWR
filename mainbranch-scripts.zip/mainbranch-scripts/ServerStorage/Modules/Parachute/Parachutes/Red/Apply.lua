--[[
    Apply (ModuleScript)
    Path: ServerStorage → Modules → Parachute → Parachutes → Red
    Parent: Red
    Exported: 2026-09-21 11:23:25
]]

return function(Parachute, BaseHandle)
	BaseHandle.BrickColor = BrickColor.new("Bright red")
end