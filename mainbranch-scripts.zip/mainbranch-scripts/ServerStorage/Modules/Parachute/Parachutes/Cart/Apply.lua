--[[
    Apply (ModuleScript)
    Path: ServerStorage → Modules → Parachute → Parachutes → Cart
    Parent: Cart
    Exported: 2026-09-21 11:23:25
]]

return function(Parachute, BaseHandle)
	local Cart = BaseHandle:WaitForChild("Cart", 5)
	if Cart then
		local Weld = Instance.new("Weld")
		Weld.Part0 = BaseHandle
		Weld.Part1 = Cart
		Weld.C1 = CFrame.new(0, 5, 0)
		Weld.Parent = BaseHandle
		
		BaseHandle.Transparency = 1
	end
end