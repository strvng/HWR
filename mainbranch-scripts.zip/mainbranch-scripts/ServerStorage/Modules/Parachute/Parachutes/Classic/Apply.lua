--[[
    Apply (ModuleScript)
    Path: ServerStorage → Modules → Parachute → Parachutes → Classic
    Parent: Classic
    Exported: 2026-09-21 11:23:25
]]

return function(Parachute, BaseHandle)
	BaseHandle.Material = Enum.Material.Glacier
	BaseHandle.BrickColor = BrickColor.new("Bright blue")
	BaseHandle.MaterialVariant = "2008 Weld"
end