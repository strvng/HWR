--[[
    Apply (ModuleScript)
    Path: ServerStorage → Modules → Parachute → Parachutes → Gold
    Parent: Gold
    Exported: 2026-09-21 11:23:25
]]

return function(Parachute, BaseHandle)
	BaseHandle.BrickColor = BrickColor.new("Gold")
end