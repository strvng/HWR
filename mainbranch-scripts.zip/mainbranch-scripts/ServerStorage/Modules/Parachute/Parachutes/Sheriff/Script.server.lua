--[[
    Script (Script)
    Path: ServerStorage → Modules → Parachute → Parachutes → Sheriff
    Parent: Sheriff
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:25
]]

local Handle = script.Parent
local Tool = Handle.Parent

local Equip = Handle:WaitForChild("Equip")
local Yeehaw = Handle:WaitForChild("Yeehaw")
local Horse = Handle:WaitForChild("Horse")
local Gunshot = Handle:WaitForChild("Gunshot")

local CurrentThread

Tool.Grip = CFrame.new(-1.5, -4, 1.37) * CFrame.Angles(0, math.rad(180), 0)

local PlaybackSpeeds = {
	0.94, 1, 1, 1, 1.1, 0.98, 0.98
}

Tool.Equipped:Connect(function()
	CurrentThread = task.defer(function()
		Equip.PlaybackSpeed = PlaybackSpeeds[math.random(1, #PlaybackSpeeds)]
		Yeehaw.PlaybackSpeed = math.clamp(Equip.PlaybackSpeed + 0.1, 0.95, 1.1)
		Equip:Play()
		task.wait(0.6)
		Yeehaw:Play()
		task.wait(0.4)
		Gunshot:Play()
		task.wait(0.8)
		Horse:Play()
	end)
end)

Tool.Unequipped:Connect(function()
	if CurrentThread then
		task.cancel(CurrentThread)
		CurrentThread = nil
	end
	Equip:Stop()
	Yeehaw:Stop()
	Horse:Stop()
	Gunshot:Stop()
end)

Handle.Material = Enum.Material.Leather
Handle.BrickColor = BrickColor.new("Medium brown")