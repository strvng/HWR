--[[
    IsPrivateServer (ModuleScript)
    Path: ServerStorage → Modules → PrivateServer
    Parent: PrivateServer
    Exported: 2026-09-21 11:23:25
]]

return game.PrivateServerId ~= ""