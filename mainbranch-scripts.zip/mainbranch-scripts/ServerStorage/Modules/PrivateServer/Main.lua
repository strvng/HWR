--[[
    Main (ModuleScript)
    Path: ServerStorage → Modules → PrivateServer
    Parent: PrivateServer
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")

local PrivateServer = Modules:WaitForChild("PrivateServer")
local Settings = require(Modules:WaitForChild("Settings"))

local IsPrivateServer = require(PrivateServer:WaitForChild("IsPrivateServer"))

if IsPrivateServer then
	Settings.Levels.KillXP = 0
	Settings.Levels.DoubleXP = 0
	Settings.Flag.DoubleXP = 0
	Settings.Flag.CaptureXP = 0
end

return nil