--[[
    Settings (ModuleScript)
    Path: ServerStorage → Modules
    Parent: Modules
    Exported: 2026-09-21 11:23:25
]]
return {
	Vehicles = {
		VehicleRemovalTime = 60 * 10,
		CrashRemovalTime = 5,
		SpawnMagnitude = 30,
	},
	Weapons = {
		OriginLatency = 100, -- Originally 60
		VehicleOriginLatency = 300, -- Originally 150
		ExplosionLatency = 10000000, -- Originally 200, cranked to 10000000 to prevent invis glitch (test)
		["Pistol"] = {
			Damage = 25,
			Cooldown = 0.25,
			Max = 5,
		},
		["FastRocket"] = {
			Cooldown = 6,
			Max = 2,
		},
		["MultiRocket"] = {
			Cooldown = 3,
			MaxRocketCount = 7,
			Max = 2,
			Offset = {
				[1] = -15,
				[2] = -10,
				[3] = -5,
				[4] = 0,
				[5] = 5,
				[6] = 10,
				[7] = 15,
			}
		},
		["PlaneMissile"] = {
			Cooldown = 1,
			MaxRocketCount = 2,
			Max = 3,
		},
		["JeepBullet"] = {
			Cooldown = 0.2,
			Damage = 40,
			Max = 7,
		},
		["VipMissile"] = {
			Cooldown = 1,
			MaxRocketCount = 4,
			Max = 3,
		},
		["Bomb"] = {
			Cooldown = 1.5,
			Max = 3,
		},
		["HomingMissile"] = {
			Cooldown = 15,
			MaxRocketCount = 2,
			Max = 2,
		},
		["Dagger"] = {
			SlashDamage = 10,
			LungeDamage = 20,
			LungeDebounce = 0.75,
			Range = 20,
		},
		["DeathMissile"] = {
			MaxRocketCount = 5,
			Cooldown = 3,
			Max = 2
		},
		["AK47"] = {
			Cooldown = 1,
			Max = 20,
			Damage = 27,
		},
		["M24"] = {
			Cooldown = 6,
			Max = 2,
			Damage = 100,
		},
		["SAMTankMissile"] = {
			Cooldown = 5,
			Max = 2,
		},
	},
	Regen = {
		DebounceTime = 20,
		PauseTime = 4,
		--GlobalRegenTime = 60 * 5,
		--GlobalPauseTime = 4,
		MaxDistance = 20,
		TowerRegenTime = 5 * 60,
		ButtonOnColor = BrickColor.new("Bright violet"),
		ButtonOffColor = BrickColor.new("Black"),
	},
	Vip = {
		OriginalVIP = 2546452,
		VIPGamepassId = 16210289,
		DoubleXPGamepassId = 25244382,
		SortGamepassId = 25272794,
		
		GiverDebounceTime = 2,
		GiverOnBrickColor = BrickColor.new("Bright green"),
		GiverOffBrickColor = BrickColor.new("Bright red")
	},
	Cleanup = {
		OutgoingLimit = 60 * 2,
		OutgoingCheck = 60 * 2,
	},
	Levels = {
		KillXP = 100,
		DoubleXP = 200,
	},
	Flag = {
		CaptureXP = 750,
		DoubleXP = 1500,
	},
	Round = {
		KillScore = 1,
		CaptureScore = 5,
		PointsToWin = 50,
		IntermissionTime = 7.5,
	},
	Admin = {
		Admins = {
			82288569,
		},
		Mods = {
			
		},
		Suffix = ":"
	},
	Feedback = {
		WebhookURL = "https://webhook.lewisakura.moe/api/webhooks/1092845257047167006/xwfad2PGM4HPHPdJ7wMJEp63H4b3YvYJ1s9jMEeQWwhTMRSDhMYQnLbHGecGcuzWLxsN",
		--WebhookURL = "https://discord.com/api/webhooks/1092845257047167006/xwfad2PGM4HPHPdJ7wMJEp63H4b3YvYJ1s9jMEeQWwhTMRSDhMYQnLbHGecGcuzWLxsN",
		ProxyURL = "https://bloxrank.net/api/webhook/"
	}
}