--[[
    GiveXP (ModuleScript)
    Path: ServerStorage → Modules → Gamepass → General
    Parent: General
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")

local DataHandler = Modules:WaitForChild("DataHandler")

local Data = require(DataHandler:WaitForChild("Data"))

return function(Player, Amount)
	local PlayerData = Data:GetPlayer(Player)
	if PlayerData then
		PlayerData.XP.Store:Increment(Amount)
		
		return true
	end
	--local Data = Player:FindFirstChild("Data")
	--if Data then
	--	local LevelFolder = Data:FindFirstChild("LevelFolder")
	--	if LevelFolder then
	--		local XP = LevelFolder:FindFirstChild("XP")
	--		if XP then
	--			XP.Value += Amount
				
	--			return true
	--		end
	--	end
	--end
end