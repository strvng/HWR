--[[
    Marketplace (ModuleScript)
    Path: ServerStorage → Modules → Gamepass
    Parent: Gamepass
    Exported: 2026-09-21 11:23:25
]]
local Module = {
	GamepassCache = {}
}

local MarketplaceService = game:GetService("MarketplaceService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

function Module:UserOwnsGamepass(Player, Id)
	local Cache = self.GamepassCache
	
	if Cache[Player] and table.find(Cache[Player], Id) then
		return true
	end
	
	local success, result = pcall(function()
		return MarketplaceService:UserOwnsGamePassAsync(Player.UserId, Id)
	end)
	
	if success and result then
		return true
	end
end

function Module:SetGamepassOwned(Player, Id)
	local Cache = self.GamepassCache[Player]
	if Cache then
		table.insert(Cache, Id)
		self.GamepassCache[Player] = Cache
	else
		self.GamepassCache[Player] = {Id}
	end
	
	ReceiveIncoming:FireClient(Player, "SetGamepassOwned", Id)
end

return Module