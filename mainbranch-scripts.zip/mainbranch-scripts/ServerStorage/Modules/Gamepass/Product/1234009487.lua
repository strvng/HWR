--[[
    1234009487 (ModuleScript)
    Path: ServerStorage → Modules → Gamepass → Product
    Parent: Product
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local General = GamepassFolder:WaitForChild("General")

local GiveXP = require(General:WaitForChild("GiveXP"))

return function(Player, Receipt)
	local WasSuccessful = GiveXP(Player, 10000)
	
	if WasSuccessful then
		return Enum.ProductPurchaseDecision.PurchaseGranted
	end
end