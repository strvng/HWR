--[[
    Main (ModuleScript)
    Path: ServerStorage → Modules → Gamepass
    Parent: Gamepass
    Exported: 2026-09-21 11:23:25
]]

local MarketplaceService = game:GetService("MarketplaceService")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local ProductFolder = GamepassFolder:WaitForChild("Product")

local Marketplace = require(GamepassFolder:WaitForChild("Marketplace"))

MarketplaceService.PromptGamePassPurchaseFinished:Connect(function(Player, Id, WasPurchased)
	if WasPurchased then
		Marketplace:SetGamepassOwned(Player, Id)
	end
end)

MarketplaceService.ProcessReceipt = function(Receipt)
	local Player = Players:GetPlayerByUserId(Receipt.PlayerId)
	if Player then
		local Module = ProductFolder:FindFirstChild(Receipt.ProductId)
		if Module then
			return require(Module)(Player, Receipt)
		end
	else
		return Enum.ProductPurchaseDecision.NotProcessedYet
	end
end

return nil