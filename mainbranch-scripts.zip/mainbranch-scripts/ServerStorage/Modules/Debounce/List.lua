--[[
    List (ModuleScript)
    Path: ServerStorage → Modules → Debounce
    Parent: Debounce
    Exported: 2026-09-21 11:23:25
]]

local Controller = {
	List = {}
}

function Controller:AddToList(Tool)
	local Data = {
		Last = tick(),
		Count = 0
	}
	
	self.List[Tool] = Data
	
	return Data
end

function Controller:GetData(Tool)
	return self.List[Tool]
end

function Controller:RemoveData(Tool)
	self.List[Tool] = nil
end

return Controller