--[[
    VehicleList (ModuleScript)
    Path: ServerStorage → Modules → Debounce
    Parent: Debounce
    Exported: 2026-09-21 11:23:25
]]

local VehicleList = {
	List = {}
}

function VehicleList:AddToList(Vehicle, ProjectileType)
	local Data = {
		Last = tick(),
		Count = 0,
	}
	
	local ExistingData = self.List[Vehicle]
	if ExistingData then
		ExistingData[ProjectileType] = Data
	else
		self.List[Vehicle] = {
			[ProjectileType] = Data
		}
	end
	
	return Data
end

function VehicleList:GetData(Vehicle, ProjectileType)
	local Data = self.List[Vehicle]
	if Data then
		return Data[ProjectileType]
	end
end

function VehicleList:RemoveData(Vehicle, ProjectileType)
	local Data = self.List[Vehicle]
	if Data then
		Data[ProjectileType] = nil
	end
end

function VehicleList:RemoveAllData(Vehicle)
	self.List[Vehicle] = nil
end

return VehicleList