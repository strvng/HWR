--[[
    CanFireVehicle (ModuleScript)
    Path: ServerStorage → Modules → Debounce
    Parent: Debounce
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Debounce = Modules:WaitForChild("Debounce")

local VehicleList = require(Debounce:WaitForChild("VehicleList"))
local CheckBucket = require(Debounce:WaitForChild("CheckBucket"))

return function(Vehicle, ProjectileType, FireRate, Max)
	local Data = VehicleList:GetData(Vehicle, ProjectileType)
	
	if not Data then
		Data = VehicleList:AddToList(Vehicle, ProjectileType)
	end
	
	CheckBucket(Data, FireRate, Max)
	Data.Count += 1
	Data.Last = tick()
	
	if Data.Count <= Max then
		return true
	end
end