--[[
    CanFire (ModuleScript)
    Path: ServerStorage → Modules → Debounce
    Parent: Debounce
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Debounce = Modules:WaitForChild("Debounce")

local List = require(Debounce:WaitForChild("List"))
local CheckBucket = require(Debounce:WaitForChild("CheckBucket"))

return function(Tool, FireRate, Max)
	local Data = List:GetData(Tool)
	
	if not Data then
		Data = List:AddToList(Tool)
	end
	
	CheckBucket(Data, FireRate, Max)
	Data.Count += 1
	Data.Last = tick()
	
	if Data.Count <= Max then
		return true
	end
end