--[[
    CheckBucket (ModuleScript)
    Path: ServerStorage → Modules → Debounce
    Parent: Debounce
    Exported: 2026-09-21 11:23:25
]]

return function(Data, FireRate, Max)
	local Difference = tick() - Data.Last
	local TimePassed = math.floor(Difference / FireRate) * Max
	
	Data.Count = math.clamp(Data.Count - TimePassed, 0, 100)
end