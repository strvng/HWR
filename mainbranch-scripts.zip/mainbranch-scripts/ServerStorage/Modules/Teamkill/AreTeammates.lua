--[[
    AreTeammates (ModuleScript)
    Path: ServerStorage → Modules → Teamkill
    Parent: Teamkill
    Exported: 2026-09-21 11:23:28
]]

return function(Player, Player2)
	return Player.Team == Player2.Team
end