--[[
    StatController (ModuleScript)
    Path: ServerStorage → Modules → Round
    Parent: Round
    Exported: 2026-09-21 11:23:25
]]

local Players = game:GetService("Players")

local StatController = {
	ActiveStats = {}
}

function StatController.Apply(Player, StatData)
	if Player:FindFirstChild("leaderstats") then
		StatController.Clear(Player)
	end
	
	local leaderstats = Instance.new("Folder")
	leaderstats.Name = "leaderstats"
	
	for _, v in ipairs(StatData) do
		local Stat = Instance.new(v.Type)
		Stat.Name = v.Name
		Stat.Value = v.Default
		Stat.Parent = leaderstats
	end
	
	leaderstats.Parent = Player
end

function StatController.Clear(Player)
	local Leader = Player:FindFirstChild("leaderstats")
	if Leader then
		Leader:Destroy()
	end
end

function StatController:LoadStats(StatData)
	self.ActiveStats = StatData
	
	for _, v in pairs(Players:GetPlayers()) do
		StatController.Apply(v, StatData)
	end
end

function StatController:ClearStats()
	self.ActiveStats = nil
	
	for _, v in pairs(Players:GetPlayers()) do
		StatController.Clear(v)
	end
end

return StatController