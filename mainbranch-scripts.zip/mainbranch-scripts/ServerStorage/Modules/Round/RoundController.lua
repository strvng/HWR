--[[
    RoundController (ModuleScript)
    Path: ServerStorage → Modules → Round
    Parent: Round
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Utilities = ReplicatedModules:WaitForChild("Utilities")
local Round = Modules:WaitForChild("Round")

local DebrisFolder = workspace:WaitForChild("Debris")
local RecieveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local GetStatistics = require(Round:WaitForChild("GetStatistics"))
local Signal = require(Utilities:WaitForChild("Signal"))
local Clean = require(Round:WaitForChild("Clean"))

local RoundController = {
	ActiveRound = false,
	ExperienceData = {},
	RoundEnded = Signal.new()
}

function RoundController:LoadPlayers()
	table.clear(self.ExperienceData)
	
	for _, v in pairs(Players:GetPlayers()) do
		local DataFolder = v:FindFirstChild("Data")
		if DataFolder then
			local XP = DataFolder:FindFirstChild("XP")
			local Level = DataFolder:FindFirstChild("Level")
			if XP and Level then
				self.ExperienceData[v.Name] = {
					XP = XP.Value,
					Level = Level.Value
				}
			end
		end
		
		v:LoadCharacter()
	end
end

function RoundController:UnloadPlayers()
	for i, v in pairs(Players:GetPlayers()) do
		local Character = v.Character
		if Character then
			Character:Destroy()
		end
		
		--local Leader = v:FindFirstChild("leaderstats")
		--if Leader then
		--	local KOs = Leader:FindFirstChild("KOs")
		--	local WOs = Leader:FindFirstChild("WOs")
		--	local Captures = Leader:FindFirstChild("Captures")
		--	if KOs and WOs and Captures then
		--		KOs.Value = 0
		--		WOs.Value = 0
		--		Captures.Value = 0
		--	end
		--end
	end
end

function RoundController:ClearDebris()
	for _, v in pairs(DebrisFolder:GetChildren()) do
		v:ClearAllChildren()
	end
end

function RoundController:Start()
	--BalanceTeams()
	
	Players.CharacterAutoLoads = true
	
	self.ActiveRound = true
	self:LoadPlayers()
	-- balance teams
	-- spawn players
	-- archive xp
end

function RoundController:End(WinningTeam)
	local Data, CurrentStats = GetStatistics()
	
	Players.CharacterAutoLoads = false
	
	RecieveIncoming:FireAllClients("Endround", Data, WinningTeam, self.ExperienceData, CurrentStats)
	
	Clean()
	self.ActiveRounded = false
	self.RoundEnded:Fire(WinningTeam)
	self:UnloadPlayers()
	self:ClearDebris()
end

return RoundController