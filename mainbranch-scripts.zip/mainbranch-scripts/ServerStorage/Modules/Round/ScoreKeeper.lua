--[[
    ScoreKeeper (ModuleScript)
    Path: ServerStorage → Modules → Round
    Parent: Round
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")

local RoundController = require(Round:WaitForChild("RoundController"))
local TeamController = require(Round:WaitForChild("TeamController"))
local Settings = require(Modules:WaitForChild("Settings"))

local ScoreKeeper = {
	Enabled = false
}
ScoreKeeper.__index = ScoreKeeper

function ScoreKeeper:IsGameOver()
	for _, v in pairs(TeamController.Teams) do
		if v:GetScore() >= TeamController:GetPointsToWin() then
			RoundController:End(
				TeamController.GetTeamReplicationData(v)
			)
			break
		end
	end
end

function ScoreKeeper:Start()
	self.Enabled = true
end

function ScoreKeeper:Stop()
	self.Enabled = false
end

TeamController.ScoreChanged:Connect(function()
	ScoreKeeper:IsGameOver()
end)

return ScoreKeeper