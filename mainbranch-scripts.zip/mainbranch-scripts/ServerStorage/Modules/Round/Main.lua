--[[
    Main (ModuleScript)
    Path: ServerStorage → Modules → Round
    Parent: Round
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local MapModules = MapFolder:WaitForChild("MapModules")
local SetupFunctions = MapFolder:WaitForChild("Setup")

local MapController = require(MapFolder:WaitForChild("MapController"))
local RoundController = require(Round:WaitForChild("RoundController"))
local TeamVoiceChat = require(SetupFunctions:WaitForChild("TeamVoiceChat"))
local Settings = require(Modules:WaitForChild("Settings"))

local Loop = {}

local function GetDifferentMap(Current)
	local Map = MapController.GetRandomMap()
	if Map.Name == Current then
		return GetDifferentMap(Current)
	else
		return Map
	end
end

function Loop:Run(Map)
	TeamVoiceChat:SetGlobalChatEnabled(false)
	MapController:Load(Map)
	RoundController:Start()
	
	RoundController.RoundEnded:Wait()
	TeamVoiceChat:SetGlobalChatEnabled(true)
	task.wait(Settings.Round.IntermissionTime * 0.75)
	MapController:Unload()
	task.wait(Settings.Round.IntermissionTime * 0.25)
end

Players.PlayerAdded:Wait()

local Desert = require(MapModules:WaitForChild("Desert"))
local Winter = require(MapModules:WaitForChild("Winter"))
local Sky = require(MapModules:WaitForChild("Sky"))
local Cave = require(MapModules:WaitForChild("Cave"))
local Jungle = require(MapModules:WaitForChild("Jungle"))

local function ModifiedLoop()
	Loop:Run(Cave)
	
	while true do
		for i = 1, 4 do
			Loop:Run(Desert)
		end
		
		Loop:Run(Winter)
		
		for i = 1, 4 do
			Loop:Run(Desert)
		end
		
		Loop:Run(Jungle)
		
		for i = 1, 4 do
			Loop:Run(Desert)
		end
		
		Loop:Run(Sky)
	end
end

--local function OriginalLoop()
--	while true do
--		for i = 1, 4 do
--			Loop:Run(Desert)
--		end
		
--		Loop:Run(Winter)
		
--		for i = 1, 4 do
--			Loop:Run(Desert)
--		end
		
--		Loop:Run(Jungle)
--	end
--end

ModifiedLoop()

return Loop