--[[
    Clean (ModuleScript)
    Path: ServerStorage → Modules → Round
    Parent: Round
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Debounce = Modules:WaitForChild("Debounce")
local General = Modules:WaitForChild("General")
local Vehicle = Modules:WaitForChild("Vehicle")
local Regen = Modules:WaitForChild("Regen")

local VehiclesToCheck = require(Regen:WaitForChild("VehiclesToCheck"))
local Dictionaries = require(General:WaitForChild("Dictionaries"))
local VehicleList = require(Debounce:WaitForChild("VehicleList"))
local VehicleRegistry = require(Vehicle:WaitForChild("VehicleRegistry"))

return function()
	table.clear(Dictionaries.EquipKeys)
	table.clear(Dictionaries.Tagged)
	table.clear(Dictionaries.VehicleOwners)
	table.clear(Dictionaries.HomingDebounce)
	table.clear(VehicleRegistry.Vehicles)
	table.clear(VehicleList.List)
	table.clear(VehiclesToCheck.List)
end