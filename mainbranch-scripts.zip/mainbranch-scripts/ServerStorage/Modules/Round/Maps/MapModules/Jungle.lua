--[[
    Jungle (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → MapModules
    Parent: MapModules
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local SetupFolder = MapFolder:WaitForChild("Setup")
local Storage = ServerStorage:WaitForChild("Storage")
local RegenModels = Storage:WaitForChild("Regen")
local BuildingFolder = RegenModels:WaitForChild("Buildings")
local TowerModel = BuildingFolder:WaitForChild("Tower")

local BaseMap = require(MapFolder:WaitForChild("BaseMap"))

local Jungle = setmetatable({}, BaseMap)
Jungle.__index = Jungle

local MapModel = script:WaitForChild("Map")
local TanTowerColor = BrickColor.new("Brick yellow").Color

local singleton

function Jungle.new()
	local self = setmetatable(BaseMap.new(), Jungle)
	
	self.Name = "Jungle"
	self.Model = nil
	self.Stats = BaseMap.Config.StatPresets.CTF
	self.Teams = BaseMap.Config.TeamPresets.Jungle
	
	return self
end

function Jungle:Setup()
	local Model = self.Model
	if Model then
		BaseMap.Setup(self)
		
		--local TanBase = Model:WaitForChild("JungleBase")
		--local GreenBase = Model:WaitForChild("GreenBase")
		local FlagFolder = Model:WaitForChild("FlagStands")
		local GiverFolder = Model:WaitForChild("Givers")
		local RegenButtonFolder = Model:WaitForChild("RegenButtons")
		--local VipDoors = Model:WaitForChild("VIPDoors")
		local VipTeleporters = Model:WaitForChild("VIPTeleporters")
		
		BaseMap.SetupFunctions.Flagstands(FlagFolder)
		BaseMap.SetupFunctions.Givers(GiverFolder)
		BaseMap.SetupFunctions.RegenButtons(RegenButtonFolder)
		BaseMap.SetupFunctions.LightingController.LoadFromMap(script)
		BaseMap.SetupFunctions.TeamVoiceChat:Enable()
		
		BaseMap.SetupFunctions.VipReplicator:SetFeatures(
			{},
			VipTeleporters:GetChildren()
		)
	end
	-- setup flag stands
	-- start vehicle spawner
	-- setup givers
	-- setup vip teleport
	-- setup vip doors
end

function Jungle:Load()
	local Map = MapModel:Clone()
	
	self.Model = Map
	
	return Map
end

function Jungle:Unload()
	local Model = self.Model
	if Model then
		BaseMap.Unload(self)
		
		Model:Destroy()
	end
end

singleton = Jungle.new()
return singleton