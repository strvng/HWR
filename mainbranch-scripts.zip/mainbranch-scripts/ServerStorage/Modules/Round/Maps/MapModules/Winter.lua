--[[
    Winter (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → MapModules
    Parent: MapModules
    Exported: 2026-09-21 11:23:27
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local SetupFolder = MapFolder:WaitForChild("Setup")
local Storage = ServerStorage:WaitForChild("Storage")
local RegenModels = Storage:WaitForChild("Regen")
local BuildingFolder = RegenModels:WaitForChild("Buildings")
local TowerModel = BuildingFolder:WaitForChild("Tower")

local BaseMap = require(MapFolder:WaitForChild("BaseMap"))
local TowerSpawner = BaseMap.SetupFunctions.TowerSpawner

local Winter = setmetatable({}, BaseMap)
Winter.__index = Winter

local MapModel = script:WaitForChild("Map")

local singleton

function Winter.new()
	local self = setmetatable(BaseMap.new(), Winter)
	
	self.Name = "Winter"
	self.Model = nil
	self.Stats = BaseMap.Config.StatPresets.CTF
	self.Teams = BaseMap.Config.TeamPresets.Winter
	
	return self
end

function Winter:Setup()
	local Model = self.Model
	if Model then
		BaseMap.Setup(self)
		
		local SnowBase = Model:WaitForChild("SnowBase")
		local GreenBase = Model:WaitForChild("GreenBase")
		local TanTowerSpawn = SnowBase:WaitForChild("TowerSpawn")
		local GreenTowerSpawn = GreenBase:WaitForChild("TowerSpawn")
		local FlagFolder = Model:WaitForChild("FlagStands")
		local RegenButtonFolder = Model:WaitForChild("RegenButtons")
		
		BaseMap.SetupFunctions.Flagstands(FlagFolder)
		BaseMap.SetupFunctions.RegenButtons(RegenButtonFolder)
		BaseMap.SetupFunctions.LightingController.LoadFromMap(script)
		BaseMap.SetupFunctions.TeamVoiceChat:Enable()
		--BaseMap.SetupFunctions.LightingController.Apply(BaseMap.Config.LightingSettings.Winter)
		--BaseMap.SetupFunctions.LightingController.LoadSkyFromModule(script)
		
		local SnowTower = {
			Model = TowerModel,
			CFrame = TanTowerSpawn.CFrame,
			Color = BaseMap.Config.TeamPresets.Winter.Teams.Snow.Primary
		}
		
		local GreenTower = {
			Model = TowerModel,
			CFrame = GreenTowerSpawn.CFrame,
			Color = BaseMap.Config.TeamPresets.Winter.Teams.Green.Primary
		}
		
		TowerSpawner:AddTowers(
			{SnowTower, GreenTower}
		)
		TowerSpawner:Enable()
		TowerSpawner:SpawnTowers()
	end
end

function Winter:Load()
	local Map = MapModel:Clone()
	
	self.Model = Map
	
	return Map
end

function Winter:Unload()
	local Model = self.Model
	if Model then
		BaseMap.Unload(self)
		
		Model:Destroy()
	end
	
	TowerSpawner:Disable()
end

singleton = Winter.new()
return singleton