--[[
    DoorPrompt (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Old → Cave (V1) → Map
    Parent: Map
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:27
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Settings = ReplicatedModules:WaitForChild("Settings")
local Gamepass = Modules:WaitForChild("Gamepass")

local Marketplace = require(Gamepass:WaitForChild("Marketplace"))
local VIP = require(Settings:WaitForChild("Vip"))

local Doors = script.Parent:WaitForChild("VIPDoors")

local PromptScript = script:WaitForChild("Prompt")

local function PromptPlayer(Player)
	if not Marketplace:UserOwnsGamepass(Player, VIP.VIPGamepassID) then
		local PlayerGui = Player:FindFirstChild("PlayerGui")
		if PlayerGui then
			PromptScript:Clone().Parent = PlayerGui
			return true
		end
	end
	
	return false
end

for _, v in pairs(Doors:GetChildren()) do
	if v:IsA("BasePart") then
		local Cooldown = false
		v.Touched:Connect(function(Hit)
			local Player = Players:GetPlayerFromCharacter(Hit.Parent)
			if Player and not Cooldown then
				local NotVip = PromptPlayer(Player, v)
				if NotVip then
					Cooldown = true
					task.wait(5)
					Cooldown = false
				end
			end
		end)
	end
end