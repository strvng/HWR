--[[
    Prompt (LocalScript)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Old → Cave (V1) → Map → DoorPrompt
    Parent: DoorPrompt
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:27
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vip = Modules:WaitForChild("VIP")

local PromptPurchase = require(Vip:WaitForChild("PromptPurchase"))

PromptPurchase()

MarketplaceService.PromptGamePassPurchaseFinished:Wait()
script:Destroy()