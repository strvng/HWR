--[[
    CTFDebug (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Old
    Parent: Old
    Exported: 2026-09-21 11:23:27
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local SetupFolder = MapFolder:WaitForChild("Setup")
local Storage = ServerStorage:WaitForChild("Storage")
local RegenModels = Storage:WaitForChild("Regen")

local BaseMap = require(MapFolder:WaitForChild("BaseMap"))

local Debug = setmetatable({}, BaseMap)
Debug.__index = Debug

local MapModel = script:WaitForChild("Map")

local singleton

function Debug.new()
	local self = setmetatable(BaseMap.new(), Debug)

	self.Model = nil
	self.Name = "Debug"
	self.Stats = BaseMap.Config.StatPresets.CTF
	self.Teams = BaseMap.Config.TeamPresets.Original
	
	return self
end

function Debug:Setup()
	local Model = self.Model
	if Model then
		BaseMap.Setup(self)
		
		local RegenButtonFolder = Model:WaitForChild("RegenButtons")
		
		BaseMap.SetupFunctions.Flagstands(self.Model.FlagStands)
		BaseMap.SetupFunctions.RegenButtons(RegenButtonFolder)
		--BaseMap.SetupFunctions.Flagstands(FlagFolder)
	end
end

function Debug:Load()
	local Map = MapModel:Clone()

	self.Model = Map

	return Map
end

function Debug:Unload()
	local Model = self.Model
	if Model then
		BaseMap.Unload(self)
		Model:Destroy()
	end
end

singleton = Debug.new()
return singleton