--[[
    Script (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Old → Desert → Map → Scenery → Platform
    Parent: Platform
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:27
]]

local Players = game:GetService("Players")
local BadgeService = game:GetService("BadgeService")

script.Parent.Touched:Connect(function(Hit)
	local Player = Players:GetPlayerFromCharacter(Hit.Parent)
	if Player then
		BadgeService:AwardBadge(
			Player.UserId,
			364372745713157
		)
	end
end)