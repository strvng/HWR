--[[
    Script (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Old → Cave (V1) → Map → GreenBase → Model → Giver → ProximityPrompt
    Parent: ProximityPrompt
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:27
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Settings = ReplicatedModules:WaitForChild("Settings")
local Gamepass = Modules:WaitForChild("Gamepass")
local Tools = ReplicatedModules:WaitForChild("Tools")

local Marketplace = require(Gamepass:WaitForChild("Marketplace"))
local ToolHelper = require(Tools:WaitForChild("ToolHelper"))
local VIP = require(Settings:WaitForChild("Vip"))

local Prompt = script.Parent
local Tool = Prompt:WaitForChild("Tool")

Prompt.Triggered:Connect(function(Player)
	if not Tool.Value or not Marketplace:UserOwnsGamepass(Player, VIP.VIPGamepassID) then
		return
	end
	
	if not ToolHelper.FindTool(Player, Tool.Value.Name) then
		local NewTool = Tool.Value:Clone()
		NewTool.Parent = Player.Backpack
	end
end)