--[[
    Script (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Old → CTFDebug → Map → Part
    Parent: Part
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:27
]]


local c = game.Players
script.Parent.Touched:Connect(function(p)
	local char = c:GetPlayerFromCharacter(p.Parent)
	if char then
		char.Team:SetAttribute("Score", 100)
	end
end)