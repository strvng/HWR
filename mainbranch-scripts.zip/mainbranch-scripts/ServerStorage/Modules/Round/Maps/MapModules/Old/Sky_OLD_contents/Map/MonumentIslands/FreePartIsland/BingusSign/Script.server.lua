--[[
    Script (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Old → Sky(OLD)) → Map → MonumentIslands → FreePartIsland → BingusSign
    Parent: BingusSign
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:27
]]

local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")

local Model = script.Parent

local function WeldModel()
	Model:BreakJoints()
	
	local last
	for _, v in pairs(Model:GetDescendants()) do
		if v:IsA("BasePart") then
			if last then
				local Weld = Instance.new("Weld")
				Weld.Part0 = last
				Weld.Part1 = v
				Weld.C0 = last.CFrame:Inverse()
				Weld.C1 = v.CFrame:Inverse()
				Weld.Parent = v
			end
			
			last = v
		end
	end
end

local function PlayerWithinRange()
	for _, v in pairs(Players:GetPlayers()) do
		local Character = v.Character
		if Character and v:DistanceFromCharacter(Model.PrimaryPart.Position) < 100 then
			return true
		end
	end
end

local function AnimateModel()
	local PrimaryPart = Model.PrimaryPart
	
	local Callback = Instance.new("NumberValue")
	
	Callback.Value = 1
	
	local NewTween = TweenService:Create(
		Callback,
		TweenInfo.new(
			0.5,
			Enum.EasingStyle.Quart,
			Enum.EasingDirection.Out,
			-1,
			true,
			0.10
		),
		{
			Value = 1.1
		}
	)
	
	Callback:GetPropertyChangedSignal("Value"):Connect(function()
		Model:ScaleTo(Callback.Value)
	end)
	
	NewTween:Play()
end

local function SetModelVisible(Visible)
	for _, v in pairs(Model:GetChildren()) do
		if v:IsA("BasePart") then
			v.Transparency = Visible and 0 or 1
		end
	end
end

AnimateModel()

while true do
	if PlayerWithinRange() then
		SetModelVisible(true)
	else
		SetModelVisible(false)
	end
	
	task.wait(10)
end