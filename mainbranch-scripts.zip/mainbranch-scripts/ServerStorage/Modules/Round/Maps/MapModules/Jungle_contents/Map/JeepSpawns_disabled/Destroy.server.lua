--[[
    Destroy (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Jungle → Map → JeepSpawns(disabled)
    Parent: JeepSpawns(disabled)
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:26
]]

script.Parent:Destroy()