--[[
    Sky (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → MapModules
    Parent: MapModules
    Exported: 2026-09-21 11:23:26
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local SetupFolder = MapFolder:WaitForChild("Setup")
local Storage = ServerStorage:WaitForChild("Storage")
local RegenModels = Storage:WaitForChild("Regen")

local BaseMap = require(MapFolder:WaitForChild("BaseMap"))

local Sky = setmetatable({}, BaseMap)
Sky.__index = Sky

local MapModel = script:WaitForChild("Map")

local singleton

function Sky.new()
	local self = setmetatable(BaseMap.new(), Sky)
	
	self.Name = "Sky"
	self.Model = nil
	self.Stats = BaseMap.Config.StatPresets.CTF
	self.Teams = BaseMap.Config.TeamPresets.Sky
	
	return self
end

function Sky:Setup()
	local Model = self.Model
	if Model then
		BaseMap.Setup(self)
		
		local RegenButtonFolder = Model:WaitForChild("RegenButtons")
		local FlagFolder = Model:WaitForChild("FlagStands")
		
		BaseMap.SetupFunctions.RegenButtons(RegenButtonFolder)
		BaseMap.SetupFunctions.LightingController.LoadFromMap(script)
		BaseMap.SetupFunctions.Flagstands(FlagFolder)
	end
end

function Sky:Load()
	local Map = MapModel:Clone()
	
	self.Model = Map
	
	return Map
end

function Sky:Unload()
	local Model = self.Model
	if Model then
		BaseMap.Unload(self)
		
		Model:Destroy()
	end
end

singleton = Sky.new()
return singleton