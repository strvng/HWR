--[[
    Script (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Winter → Map → AKGiver
    Parent: AKGiver
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:27
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Storage = ServerStorage:WaitForChild("Storage")
local StorageTools = Storage:WaitForChild("Tools")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")

local ToolHelper = require(Tools:WaitForChild("ToolHelper"))

local Model = script.Parent
local FakeAK = Model:WaitForChild("FakeAK")
local Giver = Model:WaitForChild("Giver")
local AK47 = StorageTools:WaitForChild("AK47")

local RespawnTime = 60 * 2
local Distance = 15
local Debounce = false

local function SetAK47Visible(Visible)
	local Transparency = Visible and 0 or 1
	for _, v in pairs(FakeAK:GetDescendants()) do
		if v:IsA("BasePart") then
			v.Transparency = Transparency
		end
	end
end

Giver.Touched:Connect(function(Hit)
	local Character = Hit.Parent
	if Character then
		local Player = Players:GetPlayerFromCharacter(Hit.Parent)
		if Player and not ToolHelper.FindTool(Player, AK47.Name) then
			local Humanoid = Character:FindFirstChild("Humanoid")
			local Backpack = Player:FindFirstChild("Backpack")
			if Humanoid and Backpack and Player:DistanceFromCharacter(Giver.Position) <= Distance then
				Debounce = true
				
				local NewAK = AK47:Clone()
				NewAK.Parent = Backpack
				
				Humanoid:EquipTool(NewAK)
				SetAK47Visible(false)
				task.wait(RespawnTime)
				Debounce = false
				SetAK47Visible(true)
			end
		end
	end
end)