--[[
    Script (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Winter → Map → MiddleRegen
    Parent: MiddleRegen
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:27
]]

local RegenTime = 60 * 3

local Model = script.Parent
local RegenModel = Model:WaitForChild("Middle")
local Backup = RegenModel:Clone()

local DebrisFolder = workspace:WaitForChild("Debris")
local ClearOnRegen = DebrisFolder:WaitForChild("ClearOnRegen")

local function Regenerate()
	RegenModel:Destroy()
	local New = Backup:Clone()
	New.Parent = Model
	RegenModel = New
	task.wait(RegenTime)
	Regenerate()
end

task.wait(RegenTime)
Regenerate()