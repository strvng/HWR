--[[
    Script (Script)
    Path: ServerStorage → Modules → Round → Maps → MapModules → Desert → Map → Scenery → Platform
    Parent: Platform
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local BadgeService = game:GetService("BadgeService")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")

local Badges = require(Settings:WaitForChild("Badges"))

local Part = script.Parent

Part.Touched:Connect(function(Hit)
	local Player = Players:GetPlayerFromCharacter(Hit.Parent)
	if Player then
		BadgeService:AwardBadge(
			Player.UserId,
			Badges.Caves
		)
	end
end)