--[[
    Cave (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → MapModules
    Parent: MapModules
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local SetupFolder = MapFolder:WaitForChild("Setup")
local Storage = ServerStorage:WaitForChild("Storage")
local RegenModels = Storage:WaitForChild("Regen")

local BaseMap = require(MapFolder:WaitForChild("BaseMap"))

local Cave = setmetatable({}, BaseMap)
Cave.__index = Cave

local MapModel = script:WaitForChild("Map")

local singleton

function Cave.new()
	local self = setmetatable(BaseMap.new(), Cave)
	
	self.Model = nil
	self.Name = "Cave"
	self.Stats = BaseMap.Config.StatPresets.CTF
	self.Teams = BaseMap.Config.TeamPresets.Cave
	
	return self
end

function Cave:Setup()
	local Model = self.Model
	if Model then
		BaseMap.Setup(self)
		
		local TanBase = Model:WaitForChild("TanBase")
		local GreenBase = Model:WaitForChild("GreenBase")
		local FlagFolder = Model:WaitForChild("FlagStands")
		local RegenButtonFolder = Model:WaitForChild("RegenButtons")
		local VIPDoors = Model:WaitForChild("VIPDoors")
		
		BaseMap.SetupFunctions.TeamVoiceChat:Enable()
		BaseMap.SetupFunctions.VipReplicator:SetFeatures(
			VIPDoors:GetChildren(),
			{}
		)
		BaseMap.SetupFunctions.RegenButtons(RegenButtonFolder)
		BaseMap.SetupFunctions.Flagstands(FlagFolder)
	end
end

function Cave:Load()
	local Map = MapModel:Clone()
	
	self.Model = Map
	
	return Map
end

function Cave:Unload()
	local Model = self.Model
	if Model then
		BaseMap.Unload(self)
		Model:Destroy()
	end
end

singleton = Cave.new()
return singleton