--[[
    Desert (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → MapModules
    Parent: MapModules
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local MapFolder = Round:WaitForChild("Maps")
local SetupFolder = MapFolder:WaitForChild("Setup")
local Storage = ServerStorage:WaitForChild("Storage")
local RegenModels = Storage:WaitForChild("Regen")
local BuildingFolder = RegenModels:WaitForChild("Buildings")
local TowerModel = BuildingFolder:WaitForChild("Tower")

local BaseMap = require(MapFolder:WaitForChild("BaseMap"))

local Desert = setmetatable({}, BaseMap)
Desert.__index = Desert

local MapModel = script:WaitForChild("Map")
local TanTowerColor = BrickColor.new("Brick yellow").Color

local singleton

function Desert.new()
	local self = setmetatable(BaseMap.new(), Desert)
	
	self.Name = "Desert"
	self.Model = nil
	self.Stats = BaseMap.Config.StatPresets.CTF
	self.Teams = BaseMap.Config.TeamPresets.Original
	
	return self
end

function Desert:Setup()
	local Model = self.Model
	if Model then
		BaseMap.Setup(self)
		
		local TanBase = Model:WaitForChild("TanBase")
		local GreenBase = Model:WaitForChild("GreenBase")
		local TanTowerSpawn = TanBase:WaitForChild("TowerSpawn")
		local GreenTowerSpawn = GreenBase:WaitForChild("TowerSpawn")
		local FlagFolder = Model:WaitForChild("FlagStands")
		local GiverFolder = Model:WaitForChild("Givers")
		local RegenButtonFolder = Model:WaitForChild("RegenButtons")
		local VipDoors = Model:WaitForChild("VIPDoors")
		local VipTeleporters = Model:WaitForChild("VIPTeleporters")
		
		BaseMap.SetupFunctions.Flagstands(FlagFolder)
		BaseMap.SetupFunctions.Givers(GiverFolder)
		BaseMap.SetupFunctions.RegenButtons(RegenButtonFolder)
		BaseMap.SetupFunctions.LightingController.LoadFromMap(script)
		BaseMap.SetupFunctions.TeamVoiceChat:Enable()
		
		BaseMap.SetupFunctions.VipReplicator:SetFeatures(
			VipDoors:GetChildren(),
			VipTeleporters:GetChildren()
		)
		
		local TanTower = {
			Model = TowerModel,
			CFrame = TanTowerSpawn.CFrame,
			Color = TanTowerColor
		}
		
		local GreenTower = {
			Model = TowerModel,
			CFrame = GreenTowerSpawn.CFrame,
			Color = BaseMap.Config.TeamPresets.Original.Teams.Green.Primary
		}
		
		BaseMap.SetupFunctions.TowerSpawner:AddTowers(
			{TanTower, GreenTower}
		)
		BaseMap.SetupFunctions.TowerSpawner:Enable()
		BaseMap.SetupFunctions.TowerSpawner:SpawnTowers()
	end
	-- setup flag stands
	-- start vehicle spawner
	-- setup givers
	-- setup vip teleport
	-- setup vip doors
end

function Desert:Load()
	local Map = MapModel:Clone()
	
	self.Model = Map
	
	return Map
end

function Desert:Unload()
	local Model = self.Model
	if Model then
		BaseMap.Unload(self)
		
		Model:Destroy()
	end
	
	BaseMap.SetupFunctions.TowerSpawner:Disable()
end

singleton = Desert.new()
return singleton