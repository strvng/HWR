--[[
    WithinRange (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Givers → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")

local Settings = require(Modules:WaitForChild("Settings"))

return function(Player, Button)
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChild("Humanoid")
		if Humanoid then
			local RootPart = Humanoid.RootPart
			if RootPart then
				local Distance = (RootPart.Position - Button.Position).Magnitude
				if Distance <= Settings.Regen.MaxDistance then
					return true
				end
			end
		end
	end
end