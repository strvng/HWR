--[[
    SetupGiver (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Givers → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local Objects = Maps:WaitForChild("Objects")
local Givers = Objects:WaitForChild("Givers")
local General = Givers:WaitForChild("General")
local Gamepass = Modules:WaitForChild("Gamepass")

local GetComponents = require(General:WaitForChild("GetComponents"))
local Marketplace = require(Gamepass:WaitForChild("Marketplace"))
local GiveTool = require(General:WaitForChild("GiveTool"))
local Settings = require(Modules:WaitForChild("Settings"))

return function(Giver)
	local Button, ItemValue = GetComponents(Giver)
	if Button and ItemValue then
		local Tool = ItemValue.Value
		local OldColor = Button.BrickColor
		local Cooldown = {}
		
		Button.Touched:Connect(function(Hit)
			local Character = Hit.Parent
			local Player = Players:GetPlayerFromCharacter(Character)
			if Player and not Cooldown[Player] and Marketplace:UserOwnsGamepass(Player, Settings.Vip.VIPGamepassId) then
				GiveTool(Player, Tool)
				
				Cooldown[Player] = true
				Button.BrickColor = Settings.Vip.GiverOffBrickColor
				
				task.defer(function()
					task.wait(Settings.Vip.GiverDebounceTime)
					
					Cooldown[Player] = false
					Button.BrickColor = OldColor
				end)
			end
		end)
	end
end