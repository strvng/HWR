--[[
    HasTool (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Givers → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")

local ToolHelper = require(Tools:WaitForChild("ToolHelper"))

return function(Player, Tool)
	local Tools = ToolHelper.GetAllTools(Player)
	
	for _, v in pairs(Tools) do
		if v.Name == Tool.Name then
			return true
		end
	end
end