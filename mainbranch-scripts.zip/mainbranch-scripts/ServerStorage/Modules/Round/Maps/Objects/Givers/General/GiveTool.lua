--[[
    GiveTool (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Givers → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

return function(Player, Tool)
	local Backpack = Player:WaitForChild("Backpack", 5)
	if Backpack then
		local NewTool = Tool:Clone()
		NewTool.Parent = Backpack
	end
end