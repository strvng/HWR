--[[
    GetComponents (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Givers → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

return function(Giver)
	local Button = Giver:FindFirstChild("Button")
	if Button then
		local ItemValue = Button:FindFirstChild("Tool")
		if ItemValue and ItemValue.Value then
			return Button, ItemValue
		end
	end
end