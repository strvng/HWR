--[[
    Giver (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Givers
    Parent: Givers
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local RegularGeneral = Modules:WaitForChild("General")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local Objects = Maps:WaitForChild("Objects")
local GiverFolder = Objects:WaitForChild("Givers")
local GiverGeneral = GiverFolder:WaitForChild("General")
local Tools = ReplicatedModules:WaitForChild("Tools")

local Marketplace = require(GamepassFolder:WaitForChild("Marketplace"))
local GetPlayerFromHit = require(RegularGeneral:WaitForChild("GetPlayerFromHit"))
local Settings = require(Modules:WaitForChild("Settings"))
local ToolHelper = require(Tools:WaitForChild("ToolHelper"))
--local HasTool = require(GiverGeneral:WaitForChild("HasTool"))

local Giver = {}
Giver.__index = Giver

local function IsVip(Player)
	return Marketplace:UserOwnsGamepass(Player, Settings.Vip.VIPGamepassId)
end

function Giver.new(Model, Button, Tool)
	local self = {}
	self.Model = Model
	self.Button = Button
	self.Tool = Tool
	self.Debounce = {}
	
	setmetatable(self, Giver)
	
	self.TouchedConnection = Button.Touched:Connect(function(Hit)
		local Player = GetPlayerFromHit(Hit)
		if Player and not self.Debounce[Player] and IsVip(Player) and not ToolHelper.FindTool(Player, self.Tool.Name) then
			self:Give(Player)
			self:AddToDebounce(Player)
		end
	end)
	
	return self
end

function Giver:Give(Player)
	local Backpack = Player:FindFirstChild("Backpack")
	if Backpack then
		local NewTool = self.Tool:Clone()
		NewTool.Parent = Backpack
	end
end

function Giver:ChangeColor(On)
	local Button = self.Button
	if On then
		Button.BrickColor = Settings.Vip.GiverOnBrickColor
	else
		Button.BrickColor = Settings.Vip.GiverOffBrickColor
	end
end

function Giver:AddToDebounce(Player)
	local Button = self.Button
	self.Debounce[Player] = true
	self:ChangeColor(false)
	
	task.defer(function()
		task.wait(Settings.Vip.GiverDebounceTime)
		
		self.Debounce[Player] = nil
		self:ChangeColor(true)
	end)
end

function Giver:Destroy()
	local TouchedConnection = self.TouchedConnection
	if TouchedConnection then
		TouchedConnection:Disconnect()
		self.TouchedConnection = nil
	end
end

return Giver