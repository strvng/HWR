--[[
    GetFlags (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")
local Tools = ReplicatedModules:WaitForChild("Tools")

local ToolHelper = require(Tools:WaitForChild("ToolHelper"))
--local GetTools = require(General:WaitForChild("GetTools"))

return function(Player)
	local Flags = {}
	
	for _, v in pairs(ToolHelper.GetAllTools(Player)) do
		if v:HasTag("Flag") then
			table.insert(Flags, v)
		end
	end
	
	return Flags
end