--[[
    FlagCaptured (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags
    Parent: Flags
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local General = GamepassFolder:WaitForChild("General")
local Round = Modules:WaitForChild("Round")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local Marketplace = require(GamepassFolder:WaitForChild("Marketplace"))
local Settings = require(Modules:WaitForChild("Settings"))
local GiveXP = require(General:WaitForChild("GiveXP"))
local TeamController = require(Round:WaitForChild("TeamController"))

return function(Player)
	local Leader = Player:FindFirstChild("leaderstats")
	if Leader then
		local Captures = Leader:FindFirstChild("Captures")
		if Captures then
			local XPAmount = Settings.Flag.CaptureXP
			local Team = Player.Team
			
			if Team then
				TeamController.IncrementScore(Team, Settings.Round.CaptureScore)
				--ScoreKeeper:IncrementScore(Team.Name, Settings.Round.CaptureScore)
				--Score:GiveTeamScore(Team.Name, Settings.Round.CaptureScore)
			end
			
			if Marketplace:UserOwnsGamepass(Player, Settings.Vip.DoubleXPGamepassId) then
				XPAmount = Settings.Flag.DoubleXP
			end
			
			Captures.Value += 1
			GiveXP(Player, XPAmount)
			ReceiveIncoming:FireClient(Player, "FlagCapture", XPAmount)
		end
	end
end