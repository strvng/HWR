--[[
    CreateNewFlag (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags → Flag
    Parent: Flag
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local Objects = Maps:WaitForChild("Objects")
local Flags = Objects:WaitForChild("Flags")
local General = Flags:WaitForChild("General")

local FlagTextures = require(General:WaitForChild("FlagTextures"))

local FlagTool = script:WaitForChild("Flag")

return function(TeamColor)
	local FlagTexture = FlagTextures[tostring(TeamColor)]
	if FlagTexture then
		local NewFlag = FlagTool:Clone()
		local Handle = NewFlag:WaitForChild("Handle")
		Handle.TextureID = FlagTexture
		
		NewFlag:SetAttribute("TeamColor", TeamColor)
		
		return NewFlag
	end
end