--[[
    FlagTextures (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]
return {
	["Bright blue"] = "rbxassetid://1043975",
	["Bright red"] = "rbxassetid://1043977",
	["Bright green"] = "rbxassetid://1043976",
	["Bright yellow"] = "rbxassetid://1043978",
	["Dark green"] = "rbxassetid://1043976",
	["Institutional white"] = "rbxassetid://155764025",
	
	["Brick yellow"] = "rbxassetid://1043978", -- duplicate of yellow texture for sky team
	["Medium brown"] = "rbxassetid://46034204", -- duplicate of yellow texture for cave team
	["Bronze"] = "rbxassetid://104126516966790", -- Jungle flag
	["Pastel Blue"] = "rbxassetid://74751228464961" -- Sky flag
}