--[[
    Flag (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags
    Parent: Flags
    Exported: 2026-09-21 11:23:28
]]

local Flag = {}
Flag.__index = Flag

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local Objects = Maps:WaitForChild("Objects")
local Flags = Objects:WaitForChild("Flags")
local General = Flags:WaitForChild("General")
local RegularGeneral = Modules:WaitForChild("General")
local Utilities = ReplicatedModules:WaitForChild("Utilities")

local Destroyed = require(Utilities:WaitForChild("Destroyed"))
local CreateNewFlag = require(script:WaitForChild("CreateNewFlag"))
local EquipTool = require(General:WaitForChild("EquipTool"))

function Flag.new(Flagstand)
	local TeamColor = Flagstand.TeamColor
	local New = CreateNewFlag(TeamColor)
	
	local self = {}
	self.Flagstand = Flagstand
	self.Carrier = nil
	self.Flag = New
	
	Destroyed(New, function()
		self.Flag = CreateNewFlag(TeamColor)
		self.Flagstand:NewVisual()
	end)
	
	setmetatable(self, Flag)
	
	return self
end

function Flag:SetCarrier(Player)
	local Backpack = Player:FindFirstChild("Backpack")
	local Character = Player.Character
	if Backpack and Character then
		local Flag = self.Flag
		
		Flag.Parent = Backpack
		EquipTool(Character, Flag)
	end
end

return Flag