--[[
    PositionFlag (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags → Flagstand
    Parent: Flagstand
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:28
]]

return function(Base, Flag)
	Flag.CFrame = Base.CFrame * CFrame.Angles(0, math.rad(90), 0) * CFrame.new(-1, 3, 0)
end