--[[
    Flagstand (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags
    Parent: Flags
    Exported: 2026-09-21 11:23:28
]]
local Flagstand = {}
Flagstand.__index = Flagstand

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Map = Round:WaitForChild("Maps")
local Objects = Map:WaitForChild("Objects")
local Flags = Objects:WaitForChild("Flags")
local General = Flags:WaitForChild("General")
local RegularGeneral = Modules:WaitForChild("General")
local Utilities = ReplicatedModules:WaitForChild("Utilities")

local CreateNewVisual = require(script:WaitForChild("CreateNewVisual"))
local Destroyed = require(Utilities:WaitForChild("Destroyed"))
local PositionFlag = require(script:WaitForChild("PositionFlag"))
local FlagCaptured = require(Flags:WaitForChild("FlagCaptured"))
local GetPlayerFromHit = require(RegularGeneral:WaitForChild("GetPlayerFromHit"))
local GetFlags = require(General:WaitForChild("GetFlags"))
local Flag = require(Flags:WaitForChild("Flag"))

function Flagstand.new(Base)
	local TeamColor = Base:GetAttribute("TeamColor")
	if TeamColor then
		local self = {}
		self.Stand = Base
		self.Visual = nil
		self.Flag = nil
		self.TeamColor = TeamColor
		self.CanCapture = true
		
		setmetatable(self, Flagstand)
		
		Base.Touched:Connect(function(Hit)
			if not self.CanCapture then return end
			
			self.CanCapture = false
			
			local Player = GetPlayerFromHit(Hit)
			if Player and Player.TeamColor == TeamColor then
				local CapturedFlags = GetFlags(Player)
				for _, v in pairs(CapturedFlags) do
					local FlagColor = v:GetAttribute("TeamColor")
					
					if FlagColor and FlagColor ~= TeamColor then
						FlagCaptured(Player)
					end
					
					v:Destroy()
				end
			end
			
			task.wait(1)
			self.CanCapture = true
		end)
		
		return self
	end
end

function Flagstand:NewVisual()
	local Stand = self.Stand
	local TeamColor = self.TeamColor
	local New = CreateNewVisual(TeamColor)
	local Flag = Flag.new(self)
	local Touched;
	
	PositionFlag(Stand, New)
	
	Touched = New.Touched:Connect(function(Hit)
		local Player = GetPlayerFromHit(Hit)
		if Player and Player.TeamColor ~= TeamColor then
			Flag:SetCarrier(Player)
			
			self:DeleteVisual()
		end
	end)
	
	self.Flag = Flag
	self.Visual = New
	New.Parent = Stand
end

function Flagstand:DeleteVisual()
	if self.Visual then
		self.Visual:Destroy()
	end
end

return Flagstand
