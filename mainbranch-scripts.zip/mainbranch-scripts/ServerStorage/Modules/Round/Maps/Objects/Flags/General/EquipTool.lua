--[[
    EquipTool (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Objects → Flags → General
    Parent: General
    Exported: 2026-09-21 11:23:28
]]

return function(Character, Tool)
	local Humanoid = Character:FindFirstChild("Humanoid")
	if Humanoid then
		Humanoid:UnequipTools()
		Humanoid:EquipTool(Tool)
	end
end