--[[
    MapController (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps
    Parent: Maps
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local MapModules = Maps:WaitForChild("MapModules")

local ActiveMapFolder = workspace:WaitForChild("ActiveMap")

local MapController = {
	ActiveMap = nil
}

function MapController.GetRandomMap()
	local Children = MapModules:GetChildren()
	local MapModule = Children[math.random(1, #Children)]
	if MapModule then
		return require(MapModule)
	end
end

--function MapController.LoadStats(StatData)
--	for _, v in pairs(Players:GetPlayers()) do
--		print(v)
--		local leaderstats = Instance.new("Folder")
--		leaderstats.Name = "leaderstats"
		
--		for _, v in pairs(StatData) do
--			local Stat = Instance.new(v.Type)
--			Stat.Name = v.Name
--			Stat.Value = v.Default
--			Stat.Parent = leaderstats
--		end
		
--		leaderstats.Parent = v
--	end
--end

--function MapController.ClearStats()
--	for _, v in pairs(Players:GetPlayers()) do
--		local leaderstats = v:FindFirstChild("leaderstats")
--		if leaderstats then
--			leaderstats:Destroy()
--		end
--	end
--end

function MapController:Load(Map)
	if Map then
		local CurrentMap = MapController.ActiveMap
		if CurrentMap then
			self:Unload()
		end
		
		MapController.ActiveMap = Map
		
		local Model = Map:Load()
		if Model then
			Model.Parent = ActiveMapFolder
		end
		
		Map:Setup()
	end
end

function MapController:Unload()
	local CurrentMap = MapController.ActiveMap
	if CurrentMap then
		CurrentMap:Unload()
	end
end

return MapController