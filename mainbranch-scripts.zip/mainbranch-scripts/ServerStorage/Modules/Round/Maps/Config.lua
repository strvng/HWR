--[[
    Config (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps
    Parent: Maps
    Exported: 2026-09-21 11:23:25
]]

return {
	StatPresets = {
		Default = {},
		CTF = {
			{
				Name = "KOs",
				Type = "IntValue",
				Default = 0,
				Order = 1
			},
			{
				Name = "WOs",
				Type = "IntValue",
				Default = 0,
				Order = 2
			},
			{
				Name = "Captures",
				Type = "IntValue",
				Default = 0,
				Order = 3
			}
		},
		Deathmatch = {
			{
				Name = "KOs",
				Type = "IntValue",
				Default = 0
			},
			{
				Name = "WOs",
				Type = "IntValue",
				Default = 0
			}
		}
	},
	LightingSettings = {
		Default = {
			ClockTime = 10,
			Brightness = 1.5,
			Ambient = Color3.fromRGB(255, 255, 255),
			OutdoorAmbient = Color3.fromRGB(127, 127, 127),
			GeographicLatitude = 41.333
		},
		--Desert = {
		--	ClockTime = 10,
		--	Brightness = 1.5,
		--	Ambient = Color3.fromRGB(255, 255, 255),
		--	OutdoorAmbient = Color3.fromRGB(127, 127, 127),
		--	GeographicLatitude = 41.333
		--},
		--Winter = {
		--	ClockTime = 5.5,
		--	Brightness = 0,
		--	OutdoorAmbient = Color3.fromRGB(127, 127, 127),
		--	GeographicLatitude = 179,
		--	Ambient = Color3.fromRGB(193, 193, 193),
		--}
	},
	TeamPresets = {
		Default = {},
		Original = {
			DefaultScore = 0,
			PointsToWin = 50,
			Teams = {
				Desert = {
					TeamColor = BrickColor.new("Bright yellow"),
					Name = "Desert Team",
					Primary = Color3.fromRGB(245, 205, 48),
					Secondary = Color3.fromRGB(202, 167, 39),
					AutoAssignable = true,
					LayoutOrder = 1
				},
				Green = {
					TeamColor = BrickColor.new("Bright green"),
					Name = "Green Team",
					Primary = Color3.fromRGB(39, 70, 45),
					Secondary = Color3.fromRGB(62, 113, 70),
					AutoAssignable = true,
					LayoutOrder = 2,
				},
			}
		},
		Winter = {
			DefaultScore = 0,
			PointsToWin = 50,
			Teams = {
				Snow = {
					TeamColor = BrickColor.new("Institutional white"),
					Name = "Snow Team",
					Primary = Color3.fromRGB(248, 248, 248),
					Secondary = Color3.fromRGB(214, 214, 214),
					AutoAssignable = true,
					LayoutOrder = 1,
					ScoreOutline = true
				},
				Green = {
					TeamColor = BrickColor.new("Bright green"),
					Name = "Green Team",
					Primary = Color3.fromRGB(39, 70, 45),
					Secondary = Color3.fromRGB(62, 113, 70),
					AutoAssignable = true,
					LayoutOrder = 2,
				},
			}
		},
		Sky = {
			DefaultScore = 0,
			PointsToWin = 40,
			Teams = {
				Sky = {
					TeamColor = BrickColor.new("Pastel Blue"),
					Name = "Sky Team",
					Primary = Color3.fromRGB(128, 187, 219),
					Secondary = Color3.fromRGB(86, 126, 148),
					AutoAssignable = true,
					LayoutOrder = 1
				},
				Green = {
					TeamColor = BrickColor.new("Bright green"),
					Name = "Green Team",
					Primary = Color3.fromRGB(39, 70, 45),
					Secondary = Color3.fromRGB(62, 113, 70),
					AutoAssignable = true,
					LayoutOrder = 2,
				},
			}
		},
		Cave = {
			DefaultScore = 0,
			PointsToWin = 25,
			Teams = {
				Cave = {
					TeamColor = BrickColor.new("Medium brown"),
					Name = "Cave Team",
					Primary = Color3.fromRGB(86, 66, 54),
					Secondary = Color3.fromRGB(63, 48, 39),
					AutoAssignable = true,
					LayoutOrder = 1
				},
				Green = {
					TeamColor = BrickColor.new("Bright green"),
					Name = "Green Team",
					Primary = Color3.fromRGB(39, 70, 45),
					Secondary = Color3.fromRGB(62, 113, 70),
					AutoAssignable = true,
					LayoutOrder = 2,
				},
			}
		},
		Jungle = {
			DefaultScore = 0,
			PointsToWin = 50,
			Teams = {
				Jungle = {
					TeamColor = BrickColor.new("Bronze"),
					Name = "Jungle Team",
					Primary = Color3.fromRGB(126, 104, 63),
					Secondary = Color3.fromRGB(91, 75, 45),
					AutoAssignable = true,
					LayoutOrder = 1,
				},
				Green = {
					TeamColor = BrickColor.new("Bright green"),
					Name = "Green Team",
					Primary = Color3.fromRGB(39, 70, 45),
					Secondary = Color3.fromRGB(62, 113, 70),
					AutoAssignable = true,
					LayoutOrder = 2,
				},
			}
		},
	}
}