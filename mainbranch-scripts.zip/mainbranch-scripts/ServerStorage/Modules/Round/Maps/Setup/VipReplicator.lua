--[[
    VipReplicator (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local Incoming = Remotes:WaitForChild("ReceiveIncoming")

local VipReplicator = {
	Doors = {},
	Teleporters = {}
}

function VipReplicator:SetFeatures(Doors, Teleporters)
	self.Doors = Doors
	self.Teleporters = Teleporters
	
	self:ReplicateAll()
end

function VipReplicator:ReplicateAll()
	Incoming:FireAllClients("SetVipFeatures", self.Doors, self.Teleporters)
end

function VipReplicator:ReplicateToPlayer(Player)
	Incoming:FireClient(Player, "SetVipFeatures", self.Doors, self.Teleporters)
end

return VipReplicator