--[[
    Givers (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local Objects = Maps:WaitForChild("Objects")
local GiversFolder = Objects:WaitForChild("Givers")
local DataHandler = Modules:WaitForChild("DataHandler")
local DataHandlerGeneral = DataHandler:WaitForChild("General")
local Inventory = DataHandlerGeneral:WaitForChild("Inventory")

local GetTool = require(Inventory:WaitForChild("GetTool"))
local Giver = require(GiversFolder:WaitForChild("Giver"))

return function(Folder)
	local Givers = {}
	
	for _, v in pairs(Folder:GetChildren()) do
		local Button = v:FindFirstChild("Button")
		if Button then
			local ToolName = Button:GetAttribute("Tool")
			if ToolName then
				local Tool = GetTool(ToolName)
				if Tool then
					-- possible memory leak
					
					table.insert(
						Givers,
						Giver.new(v, Button, Tool)
					)
				end
			end
		end
	end
	
	return Givers
end