--[[
    TowerSpawner (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Utilities = ReplicatedModules:WaitForChild("Utilities")

local DebrisFolder = workspace:WaitForChild("Debris")
local ClearOnRegen = DebrisFolder:WaitForChild("ClearOnRegen")

local TimerController = require(Utilities:WaitForChild("Timer"))
local Settings = require(Modules:WaitForChild("Settings"))

local TowerSpawner = {
	Towers = {},
	Enabled = false
}

local function SpawnTower(Tower)
	local NewTowerModel = Tower.Model:Clone()
	TowerSpawner.SetColor(NewTowerModel, Tower.Color)
	
	NewTowerModel.Parent = ClearOnRegen
	
	if Tower.ActiveTower then
		Tower.ActiveTower:Destroy()
	end
	
	NewTowerModel:PivotTo(Tower.CFrame)
	NewTowerModel:MakeJoints()
	Tower.ActiveTower = NewTowerModel
end

function TowerSpawner:AddTowers(Towers)
	for _, v in pairs(Towers) do
		table.insert(TowerSpawner.Towers, v)
	end
end

function TowerSpawner:ClearTowers()
	table.clear(TowerSpawner.Towers)
end

function TowerSpawner:SpawnTowers()
	for _, v in pairs(TowerSpawner.Towers) do
		SpawnTower(v)
	end
end

function TowerSpawner:Enable()
	TowerSpawner.Enabled = true
	TimerController:Subscribe("TowerSpawn", TowerSpawner.SpawnTowers, Settings.Regen.TowerRegenTime)
end

function TowerSpawner:Disable()
	TowerSpawner.Enabled = false
	TimerController:Unsubscribe("TowerSpawn")
	TowerSpawner:ClearTowers()
end

function TowerSpawner.SetColor(Tower, Color)
	for _, v in pairs(Tower:GetDescendants()) do
		if v:IsA("BasePart") and v:HasTag("Color") then
			v.Color = Color
		end
	end
end

return TowerSpawner