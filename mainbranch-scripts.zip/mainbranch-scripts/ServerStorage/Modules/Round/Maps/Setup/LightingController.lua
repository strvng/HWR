--[[
    LightingController (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")
local Lighting = game:GetService("Lighting")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")

local Config = require(Maps:WaitForChild("Config"))

local LightingController = {
	ActiveSky = nil
}

function LightingController.ClearSky()
	local ActiveSky = LightingController.ActiveSky
	if ActiveSky then
		ActiveSky:Destroy()
	end
	
	LightingController.ActiveSky = nil
end

function LightingController.SetSky(Sky)
	LightingController.ClearSky()
	local NewSky = Sky:Clone()
	NewSky.Parent = Lighting
	
	LightingController.ActiveSky = NewSky
end

function LightingController.ClearLighting()
	for _, v in pairs(Lighting:GetChildren()) do
		if not v:GetAttribute("IgnoreLightingClear") then
			v:Destroy()
		end
	end
end

function LightingController.LoadFromMap(Module)
	local LightingFolder = Module:FindFirstChild("Lighting")
	if LightingFolder then
		LightingController.ClearLighting()
		
		for _, v in pairs(LightingFolder:GetChildren()) do
			local Clone = v:Clone()
			Clone.Parent = Lighting
		end
		
		LightingController.Apply(LightingFolder:GetAttributes())
	end
end

function LightingController.LoadSkyFromModule(Module)
	local Sky = Module:FindFirstChildOfClass("Sky")
	if Sky then
		LightingController.SetSky(Sky)
	end
end

function LightingController.LoadDefault()
	LightingController.ClearSky()
	LightingController.ClearLighting()
	LightingController.Apply(Config.LightingSettings.Default)
end

function LightingController.Apply(Attributes)
	for Key, Value in pairs(Attributes) do
		Lighting[Key] = Value
	end
end

--function LightingController.LoadLightingConfig(Config)
--	local ConfigInstance = Config:FindFirstChild("Lighting")
--	if ConfigInstance then
--		LightingController.Apply(
--			ConfigInstance:GetAttributes()
--		)
--	end
	
--	local Sky = Config:FindFirstChildOfClass("Sky")
--	if Sky and Config:GetAttribute("LoadSky") then
--		LightingController.SetSky(Sky)
--	else
--		LightingController.ClearSky()
--	end
--end

return LightingController