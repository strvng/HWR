--[[
    Regen (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Regen = Modules:WaitForChild("Regen")
local Vehicle = Modules:WaitForChild("Vehicle")

local VehicleClass = require(Vehicle:WaitForChild("Vehicle"))
local RegenButton = require(Regen:WaitForChild("RegenButton"))
local ButtonTouched = require(Regen:WaitForChild("ButtonTouched"))
local GetVehicleModel = require(Vehicle:WaitForChild("GetVehicleModel"))

local function VehicleRegenCallback(Button, VehicleModel, Color, SpawnAttachment)
	local NewVehicle = VehicleClass.new(VehicleModel, Button)
	NewVehicle:SetColor(Color)
	NewVehicle:MoveTo(SpawnAttachment.WorldCFrame)
end

return function(Folder)
	for i, v in pairs(Folder:GetChildren()) do
		local VehicleName = v:GetAttribute("Model")
		local VehicleColor = v:GetAttribute("Color")
		local SpawnAttachment = v:FindFirstChild("Spawn")
		if VehicleName and VehicleColor and SpawnAttachment then
			local VehicleModel = GetVehicleModel(VehicleName)
			if VehicleModel then
				local RegenController = RegenButton.new(v, VehicleModel)
				RegenController.Regenerated = function(Button, New)
					VehicleRegenCallback(RegenController, New, VehicleColor.Color, SpawnAttachment)
				end
				ButtonTouched(v, RegenController)
				
				local FirstModel = RegenController:NewBackup()
				VehicleRegenCallback(RegenController, FirstModel, VehicleColor.Color, SpawnAttachment)
			end
		end
	end
end