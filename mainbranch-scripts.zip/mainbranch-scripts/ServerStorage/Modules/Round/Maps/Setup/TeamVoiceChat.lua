--[[
    TeamVoiceChat (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local Players = game:GetService("Players")
local Teams = game:GetService("Teams")

local MainChannel = Instance.new("AudioDeviceOutput")
MainChannel.Name = "MainVoiceChat"
MainChannel.Parent = workspace

local TeamVoiceChat = {
	Enabled = false,
	GlobalVoiceEnabled = false,
	DefaultVoiceVolume = 1.6
}

local function NewDeviceInput(Player)
	local Input = Instance.new("AudioDeviceInput")
	Input.Player = Player
	Input.Volume = TeamVoiceChat.DefaultVoiceVolume
	Input.AccessType = Enum.AccessModifierType.Allow
	Input.Parent = Player
	
	local Analyzer = Instance.new("AudioAnalyzer")
	Analyzer.Parent = Input
	
	local AnalyzerWire = Instance.new("Wire")
	AnalyzerWire.SourceInstance = Input
	AnalyzerWire.TargetInstance = Analyzer
	AnalyzerWire.Parent = Analyzer
	
	return Input
end

local function GetPlayerInput(Player, DontCreate)
	local Input = Player:FindFirstChildOfClass("AudioDeviceInput")
	if Input then
		return Input
	else
		if DontCreate then
			return
		end
		
		local NewInput = NewDeviceInput(Player)
		NewInput.Muted = not TeamVoiceChat.Enabled
		
		local Wire = Instance.new("Wire")
		Wire.SourceInstance = NewInput
		Wire.TargetInstance = MainChannel
		Wire.Name = Player.Name
		Wire.Parent = MainChannel
		
		return NewInput
	end
end

local function SetDevicesMuted(Muted)
	for _, v in pairs(Players:GetPlayers()) do
		local Input = GetPlayerInput(v, true)
		if Input then
			Input.Muted = Muted
		end
	end
end

local function GetAccessList(Team)
	local Ids = {}
	
	if TeamVoiceChat.GlobalVoiceEnabled then
		for _, v in pairs(Players:GetPlayers()) do
			table.insert(
				Ids, v.UserId
			)
		end
	else
		if Team then
			for _, v in pairs(Team:GetPlayers()) do
				table.insert(
					Ids, v.UserId
				)
			end
		end
	end
	
	return Ids
end

local function RefreshAccessList()
	for _, Team in pairs(Teams:GetTeams()) do
		local AccessList = GetAccessList(Team)
		if AccessList then
			for _, Player in pairs(Team:GetPlayers()) do
				local Input = GetPlayerInput(Player)
				if Input then
					Input:SetUserIdAccessList(AccessList)
				end
			end
		end
	end
end

function TeamVoiceChat:Enable()
	SetDevicesMuted(false)
	
	TeamVoiceChat.Enabled = true
end

function TeamVoiceChat:Disable()
	SetDevicesMuted(true)
	
	TeamVoiceChat.Enabled = false
end

function TeamVoiceChat:SetGlobalChatEnabled(Enabled)
	TeamVoiceChat.GlobalVoiceEnabled = Enabled
	
	RefreshAccessList()
end

-- Methods
-- Enable -> void
-- Disable -> void
-- SetGlobalChatEnabled(Enabled)

-- How this works
-- 

-- When Team is added we create PlayerAdded/PlayerRemoved connections
-- every time a member is added or removed we refresh the user id access list
-- that's it

local TeamConnections = {}

local function TeamAdded(Team)
	if Team:IsA("Team") and not TeamConnections[Team] then
		local PlayerAdded
		local PlayerRemoved
		
		PlayerAdded = Team.PlayerAdded:Connect(function(Player)
			RefreshAccessList()
		end)
		
		PlayerRemoved = Team.PlayerRemoved:Connect(function(Player)
			RefreshAccessList()
		end)
		
		TeamConnections[Team] = {
			PlayerAdded = PlayerAdded,
			PlayerRemoved = PlayerRemoved
		}
	end
end

local function TeamRemoved(Team)
	if Team:IsA("Team") then
		local Connections = TeamConnections[Team]
		if Connections then
			Connections.PlayerAdded:Disconnect()
			Connections.PlayerRemoved:Disconnect()
			table.clear(Connections)
		end
		
		TeamConnections[Team] = nil
	end
end

Teams.ChildAdded:Connect(TeamAdded)
Teams.ChildRemoved:Connect(TeamRemoved)

for _, v in pairs(Teams:GetTeams()) do
	TeamAdded(v)
end

RefreshAccessList()

return TeamVoiceChat