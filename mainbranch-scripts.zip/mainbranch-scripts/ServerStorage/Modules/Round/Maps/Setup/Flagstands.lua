--[[
    Flagstands (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps → Setup
    Parent: Setup
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local Objects = Maps:WaitForChild("Objects")
local Flags = Objects:WaitForChild("Flags")

local Flagstand = require(Flags:WaitForChild("Flagstand"))

return function(Folder)
	for _, v in pairs(Folder:GetChildren()) do
		local Stand = Flagstand.new(v)
		Stand:NewVisual()
	end
end