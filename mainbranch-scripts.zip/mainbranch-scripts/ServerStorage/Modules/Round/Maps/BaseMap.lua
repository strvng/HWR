--[[
    BaseMap (ModuleScript)
    Path: ServerStorage → Modules → Round → Maps
    Parent: Maps
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")
local Setup = Maps:WaitForChild("Setup")
local Round = Modules:WaitForChild("Round")

local Config = require(Maps:WaitForChild("Config"))
local Flagstands = require(Setup:WaitForChild("Flagstands"))
local Givers = require(Setup:WaitForChild("Givers"))
local ScoreKeeper = require(Round:WaitForChild("ScoreKeeper"))
local RegenButtons = require(Setup:WaitForChild("Regen"))
local TowerSpawner = require(Setup:WaitForChild("TowerSpawner"))
local VipReplicator = require(Setup:WaitForChild("VipReplicator"))
local StatController = require(Round:WaitForChild("StatController"))
local TeamController = require(Round:WaitForChild("TeamController"))
local LightingController = require(Setup:WaitForChild("LightingController"))
local TeamVoiceChat = require(Setup:WaitForChild("TeamVoiceChat"))

local BaseMap = {}
BaseMap.__index = BaseMap

BaseMap.SetupFunctions = {
	Flagstands = Flagstands,
	Givers = Givers,
	RegenButtons = RegenButtons,
	TowerSpawner = TowerSpawner,
	VipReplicator = VipReplicator,
	StatController = StatController,
	TeamController = TeamController,
	TeamVoiceChat = TeamVoiceChat,
	LightingController = LightingController,
}

BaseMap.Config = Config

function BaseMap.new()
	local self = setmetatable({}, BaseMap)
	
	self.Model = nil
	self.Name = "Base"
	self.Stats = BaseMap.Config.StatPresets.Default
	self.Teams = BaseMap.Config.TeamPresets.Default
	
	return self
end

function BaseMap:Setup()
	BaseMap.SetupFunctions.StatController:LoadStats(self.Stats)
	local NewTeams = BaseMap.SetupFunctions.TeamController:LoadTeams(self.Teams)
	
	self.SetupFunctions.TeamController:Balance(
		Players:GetPlayers(),
		NewTeams
	)
	ScoreKeeper:Start()
end

function BaseMap:Load()
	
end

function BaseMap:Unload()
	BaseMap.SetupFunctions.StatController:ClearStats()
	BaseMap.SetupFunctions.TeamController:ClearTeams()
	ScoreKeeper:Stop()
	BaseMap.SetupFunctions.LightingController.LoadDefault()
end

return BaseMap