--[[
    GetStatistics (ModuleScript)
    Path: ServerStorage → Modules → Round
    Parent: Round
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local Teams = game:GetService("Teams")

local Modules = ServerStorage:WaitForChild("Modules")
local Round = Modules:WaitForChild("Round")
local Maps = Round:WaitForChild("Maps")

local TeamController = require(Round:WaitForChild("TeamController"))
local MapController = require(Maps:WaitForChild("MapController"))

local function GetData(Player)
	local Data = {}
	
	local leaderstats = Player:FindFirstChild("leaderstats")
	if leaderstats then
		for i, v in ipairs(leaderstats:GetChildren()) do
			Data[i] = {
				Name = v.Name,
				Value = v.Value
			}
		end
	end
	
	return Data
end

return function()
	local ActiveMap = MapController.ActiveMap
	if ActiveMap then
		local CurrentStats = ActiveMap.Stats
		local Teams = TeamController.Teams
		if CurrentStats and Teams then
			local PlayerStatsData = {}
			
			for _, v in ipairs(Teams) do
				local TeamObject = v.TeamObject
				if TeamObject then
					local TeamPlayers = v.TeamObject:GetPlayers()
					
					local NewData = TeamController.GetTeamReplicationData(v)
					local TeamPlayerData = {}
					
					for _, v in pairs(TeamPlayers) do
						TeamPlayerData[v.DisplayName] = GetData(v)
					end
					
					NewData.TeamColor = NewData.TeamColor
					NewData.Players = TeamPlayerData
					
					PlayerStatsData[TeamObject.Name] = NewData
				end
			end
			
			return PlayerStatsData, CurrentStats
		end
	end
end

--return function()
--	local Score = require(Round:WaitForChild("Score"))
--	-- loop through all teams
--	-- find teams in Teams
--	-- use Team:GetPlayers()
--	-- loop through and save all data within leaderstats
--	local CurrentTeams = Score:GetTeams()
	
--	local Data = {}
--	local CurrentStats = Score.CurrentStats
	
--	for _, TeamData in ipairs(CurrentTeams) do
--		local TeamObject = Teams:FindFirstChild(TeamData.Name)
--		if TeamObject and TeamObject:IsA("Team") then
--			local TeamPlayers = TeamObject:GetPlayers()
			
--			local NewData = table.clone(TeamData)
--			local TeamPlayerData = {}
			
--			for _, v in pairs(TeamPlayers) do
--				TeamPlayerData[v.DisplayName] = GetData(v)
--			end
			
--			NewData.TeamColor = NewData.TeamColor
--			NewData.Players = TeamPlayerData
			
--			Data[TeamData.Name] = NewData
--		end
--	end
	
--	return Data, CurrentStats
--end