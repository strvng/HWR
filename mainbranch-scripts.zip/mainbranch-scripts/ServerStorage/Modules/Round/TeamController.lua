--[[
    TeamController (ModuleScript)
    Path: ServerStorage → Modules → Round
    Parent: Round
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local Teams = game:GetService("Teams")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Utilities = Modules:WaitForChild("Utilities")

local Signal = require(Utilities:WaitForChild("Signal"))

local TeamController = {
	Teams = {},
	ScoreChanged = Signal.new()
}

local Team = {}
Team.__index = Team

function Team.FromPreset(TeamData, DefaultScore)
	local self = setmetatable({}, Team)
	
	if TeamData then
		local TeamObject = Instance.new("Team")
		TeamObject.Name = TeamData.Name
		TeamObject.TeamColor = TeamData.TeamColor
		TeamObject.AutoAssignable = TeamData.AutoAssignable
		
		TeamObject:SetAttribute("Score", DefaultScore)
		TeamObject:SetAttribute("Primary", TeamData.Primary)
		TeamObject:SetAttribute("Secondary", TeamData.Secondary)
		TeamObject:SetAttribute("LayoutOrder", TeamData.LayoutOrder)
		
		if TeamData.ScoreOutline then
			TeamObject:SetAttribute("ScoreOutline", true)
		end
		
		TeamObject:GetAttributeChangedSignal("Score"):Connect(function()
			TeamController.ScoreChanged:Fire(self)
		end)
		
		self.TeamObject = TeamObject
	end
	
	return self
end

function Team:GetScore()
	local TeamObject = self.TeamObject
	if TeamObject then
		return TeamController.GetScore(TeamObject)
	end
end

function Team:SetScore(Value)
	local TeamObject = self.TeamObject
	if TeamObject then
		TeamController.SetScore(TeamObject, Value)
	end
end

function Team:SetParent(Parent)
	local TeamObject = self.TeamObject
	if TeamObject then
		TeamObject.Parent = Teams
	end
end

function Team:Destroy()
	local TeamObject = self.TeamObject
	if TeamObject then
		TeamObject:Destroy()
	end
end

function Team:IncrementScore(Amount)
	local TeamObject = self.TeamObject
	if TeamObject then
		TeamController.IncrementScore(TeamObject, Amount)
	end
end

function TeamController.GetScore(TeamObject)
	if TeamObject then
		return TeamObject:GetAttribute("Score")
	end
end

function TeamController.IncrementScore(TeamObject, Amount)
	if TeamObject and typeof(Amount) == "number" then
		local CurrentScore = TeamController.GetScore(TeamObject)
		if CurrentScore then
			TeamObject:SetAttribute("Score", CurrentScore + Amount)
		end
	end
end

function TeamController.SetScore(TeamObject, Value)
	if TeamObject and typeof(Value) == "number" then
		TeamObject:SetAttribute("Score", Value)
	end
end

function TeamController.GetTeamReplicationData(TeamClass)
	local TeamObject = TeamClass.TeamObject
	if TeamObject then
		return {
			Primary = TeamObject:GetAttribute("Primary"),
			Secondary = TeamObject:GetAttribute("Secondary"),
			Score = TeamObject:GetAttribute("Score"),
			TeamColor = TeamObject.TeamColor,
			Name = TeamObject.Name,
		}
	end
end

function TeamController:LoadTeams(Preset)
	local TeamData = Preset.Teams
	local DefaultScore = Preset.DefaultScore
	local PointsToWin = Preset.PointsToWin
	if TeamData and DefaultScore and PointsToWin then
		for _, v in pairs(TeamData) do
			local NewTeam = Team.FromPreset(v, DefaultScore)
			
			table.insert(
				self.Teams,
				NewTeam
			)
			NewTeam:SetParent(Teams)
		end
		
		self:SetPointsToWin(PointsToWin)
		
		return self.Teams
	end
end

function TeamController:ClearTeams()
	for _, v in pairs(self.Teams) do
		v:Destroy()
	end
	
	table.clear(self.Teams)
end

function TeamController:Balance(PlayersToBalance)
	local TeamsToBalance = {}
	
	for _, v in pairs(self.Teams) do
		table.insert(TeamsToBalance, v.TeamObject)
	end
	
	TeamController._Balance(PlayersToBalance, TeamsToBalance)
end

function TeamController._Balance(PlayersToBalance, Teams)
	local PlayersPerTeam = math.floor(#PlayersToBalance / #Teams)
	local Remainder = #PlayersToBalance % #Teams
	
	for _, v in pairs(Teams) do
		for _ = 1, PlayersPerTeam do
			local Index = math.random(1, #PlayersToBalance)
			local Player = PlayersToBalance[Index]
			
			Player.Team = v
			
			table.remove(PlayersToBalance, Index)
		end
	end
	
	for _, v in pairs(Teams) do
		if #PlayersToBalance >= 1 then
			local Player = PlayersToBalance[1]
			
			Player.Team = v
			
			table.remove(PlayersToBalance, 1)
		else
			break
		end
	end
end

function TeamController:GetPointsToWin()
	return Teams:GetAttribute("PointsToWin")
end

function TeamController:SetPointsToWin(PointsToWin)
	if typeof(PointsToWin) == "number" then
		Teams:SetAttribute("PointsToWin", PointsToWin)
	end
end

return TeamController