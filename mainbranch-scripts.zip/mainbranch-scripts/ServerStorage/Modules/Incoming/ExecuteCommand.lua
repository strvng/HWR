--[[
    ExecuteCommand (ModuleScript)
    Path: ServerStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")

local RunCommand = require(Admin:WaitForChild("RunCommand"))

return function(Player, Command)
	RunCommand(Player, Command)
end