--[[
    AddRequest (ModuleScript)
    Path: ServerStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Debounce = Modules:WaitForChild("Debounce")
local Weapon = Weapons:WaitForChild("Weapon")
local General = Weapons:WaitForChild("General")
local VehicleFolder = ReplicatedModules:WaitForChild("Vehicle")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local CanFire = require(Debounce:WaitForChild("CanFire"))
local Settings = require(Modules:WaitForChild("Settings"))
local OriginCheck = require(General:WaitForChild("OriginCheck"))
local GetEquipped = require(General:WaitForChild("GetEquipped"))
local CheckVehicle = require(General:WaitForChild("CheckVehicle"))
local VehicleHelper = require(VehicleFolder:WaitForChild("VehicleHelper"))
local CanFireVehicle = require(Debounce:WaitForChild("CanFireVehicle"))
local VehicleList = require(Debounce:WaitForChild("VehicleList"))

return function(Player, Type, Id, Origin, ...)
	local Module = Weapon:FindFirstChild(Type)
	if Module then
		local Data = Settings.Weapons[Type]
		if Data then
			Module = require(Module)
			if Module.RequiresTool then
				local Tool = GetEquipped(Player, Module.Name)
				if Tool and CanFire(Tool, Data.Cooldown, Data.Max) and OriginCheck(Player, Origin, Module) and Module:IsValidAddData(Origin, ...) then
					Module:AddRequest(Player, Tool, Type, Id, Origin, ...)
				end
			else
				if Module.VehicleType then
					local Vehicle = VehicleHelper.GetVehicle(Player)
					if Vehicle then
						local Controller = VehicleHelper.GetControllerType(Vehicle)
						if Controller and Module.VehicleType == Controller and CanFireVehicle(Vehicle, Type, Data.Cooldown, Data.Max) and Module:IsValidAddData(Origin, ...) then
							Module:AddRequest(Player, Type, Id, Origin, ...)
						end
					end
				end
			end
		end
	end
end