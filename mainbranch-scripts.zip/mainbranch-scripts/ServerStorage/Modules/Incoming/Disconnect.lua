--[[
    Disconnect (ModuleScript)
    Path: ServerStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]

local LocalizationService = game:GetService("LocalizationService")
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")

local Countries = require(script:WaitForChild("Countries"))
local Webhook = require(General:WaitForChild("Webhook"))

local function GetCountry(Code)
	local Result = Countries[Code]
	if Result then
		return Result
	else
		return "Unknown"
	end
end

local ReasonsQueue = {}

local function AddToQueue(Player, Reason)
	local Data = ReasonsQueue[Player]
	if Data then
		local Exists = table.find(Data, Reason)
		if not Exists then
			table.insert(Data, Reason)
		end
	else
		ReasonsQueue[Player] = {
			Reason
		}
	end
end

local function CompileReasonString(Player)
	local Data = ReasonsQueue[Player]
	if Data then
		return table.concat(Data, ", ")
	else
		return "Failed to compile reason string"
	end
end

local function IsBeingKicked(Player)
	return ReasonsQueue[Player] ~= nil
end

return function(Player, Reason)
	if not IsBeingKicked(Player) then
		local CountryCode = LocalizationService:GetCountryRegionForPlayerAsync(Player)
		task.delay(15, function()
			local DisconnectMessage = Webhook.ComposeDisconnectMessage(
				{
					UserId = Player.UserId,
					Reason = CompileReasonString(Player),
					Country = GetCountry(CountryCode)
				}
			)
			
			local Success = Webhook.PostMessage(DisconnectMessage)
			if Success then
				Player:Kick()
			end
		end)
	end
	
	AddToQueue(Player, Reason)
end
--return function(Player, Reason)
--	local CountryCode = LocalizationService:GetCountryRegionForPlayerAsync(Player)
	
--	local DisconnectMessage = Webhook.ComposeDisconnectMessage(
--		{
--			UserId = Player.UserId,
--			Reason = Reason,
--			CountryCode = CountryCode
--		}
--	)
	
--	local Success, Result = Webhook.PostMessage(DisconnectMessage)
--	if Success then
--		--Player:Kick()
--		task.delay(15, function()
--			-- just so they don't immediately know
--			Player:Kick()
--		end)
--	end
--end