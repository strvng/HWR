--[[
    Equipped (ModuleScript)
    Path: ServerStorage → Modules → Incoming → Dagger
    Parent: Dagger
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Dagger = Modules:WaitForChild("Dagger")
local General = Modules:WaitForChild("General")

local Dictionaries = require(General:WaitForChild("Dictionaries"))
local GetDagger = require(Dagger:WaitForChild("GetDagger"))
local Incoming = Remotes:WaitForChild("ReceiveIncoming")

return function(Player)
	local Tool = GetDagger(Player, true)
	if Tool and not Dictionaries.EquipKeys[Tool] then
		local Handle = Tool:FindFirstChild("Handle")
		if Handle then
			Incoming:FireAllClients("Dagger", "PlaySound", Player, Tool, "Equip")
			Dictionaries.EquipKeys[Tool] = true
		end
	end
end