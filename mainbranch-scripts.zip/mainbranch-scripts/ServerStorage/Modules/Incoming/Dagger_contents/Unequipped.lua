--[[
    Unequipped (ModuleScript)
    Path: ServerStorage → Modules → Incoming → Dagger
    Parent: Dagger
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Dagger = Modules:WaitForChild("Dagger")
local General = Modules:WaitForChild("General")

local Dictionaries = require(General:WaitForChild("Dictionaries"))
local GetDagger = require(Dagger:WaitForChild("GetDagger"))

return function(Player, Tool)
	local Tool = GetDagger(Player, false)
	if Tool then
		local Data = Dictionaries.EquipKeys[Tool]
		if Data then
			Dictionaries.EquipKeys[Tool] = nil
		end
	end
end