--[[
    Touched (ModuleScript)
    Path: ServerStorage → Modules → Incoming → Dagger
    Parent: Dagger
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Teamkill = Modules:WaitForChild("Teamkill")
local Dagger = Modules:WaitForChild("Dagger")
local Tag = Modules:WaitForChild("Tag")

--local GetHumanoid = require(General:WaitForChild("GetHumanoid"))
local AreTeammates = require(Teamkill:WaitForChild("AreTeammates"))
--local RangeCheck = require(General:WaitForChild("RangeCheck"))
local GetDagger = require(Dagger:WaitForChild("GetDagger"))
local TagPlayer = require(Tag:WaitForChild("Main"))
local Settings = require(Modules:WaitForChild("Settings"))

return function(SwordPlayer, HitPart, IsLunged)
	local SwordCharacter = SwordPlayer.Character
	if SwordCharacter then
		local RightArm = SwordCharacter:FindFirstChild("Right Arm")
		local Tool = GetDagger(SwordPlayer, true)
		if Tool and HitPart and SwordPlayer:DistanceFromCharacter(HitPart.Position) <= Settings.Weapons.Dagger.Range and RightArm then
			local RightGrip = RightArm:FindFirstChild("RightGrip")
			local HitCharacter = HitPart.Parent
			if HitCharacter and RightGrip then
				local Humanoid = HitCharacter:FindFirstChildOfClass("Humanoid")
				if Humanoid then
					local HitPlayer = Players:GetPlayerFromCharacter(HitCharacter)
					if HitPlayer then
						if AreTeammates(SwordPlayer, HitPlayer) then
							return
						end
						
						TagPlayer(HitPlayer, SwordPlayer, 5, "Dagger")
					end
					
					if IsLunged then
						Humanoid:TakeDamage(Settings.Weapons.Dagger.LungeDamage)
					else
						Humanoid:TakeDamage(Settings.Weapons.Dagger.SlashDamage)
					end
				end
			end
		end
	end
	-- make sure players aren't team mates
	-- make sure players are within range
	-- take damage
	-- tag player
	
	
	--local Humanoid, RootPart = GetHumanoid(SwordPlayer, Hit)
	--local Humanoid, RootPart = GetHumanoid(SwordPlayer)
	--if Humanoid and RootPart and RangeCheck(SwordPlayer, RootPart) and not AreTeammates(Player, Hit) then
	--	if IsLunged then
	--		Humanoid:TakeDamage(Settings.Weapons.Dagger.LungeDamage)
	--	else
	--		Humanoid:TakeDamage(Settings.Weapons.Dagger.SlashDamage)
	--	end
		
	--	TagPlayer(Hit, Player, 5, "Dagger")
	--end
end