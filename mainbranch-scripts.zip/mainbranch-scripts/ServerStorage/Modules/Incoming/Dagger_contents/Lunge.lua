--[[
    Lunge (ModuleScript)
    Path: ServerStorage → Modules → Incoming → Dagger
    Parent: Dagger
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Dagger = Modules:WaitForChild("Dagger")

local Incoming = Remotes:WaitForChild("ReceiveIncoming")
local GetDagger = require(Dagger:WaitForChild("GetDagger"))

return function(Player)
	local Tool = GetDagger(Player, true)
	if Tool then
		Incoming:FireAllClients("Dagger", "Lunge", Player, Tool)
	end
end