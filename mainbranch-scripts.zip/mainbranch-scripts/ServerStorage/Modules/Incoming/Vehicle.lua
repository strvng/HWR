--[[
    Vehicle (ModuleScript)
    Path: ServerStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]

return function(Player, Action, ...)
	local Module = script:FindFirstChild(Action)
	if Module then
		require(Module)(Player, ...)
	end
end