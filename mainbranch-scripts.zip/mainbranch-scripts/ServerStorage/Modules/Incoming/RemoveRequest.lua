--[[
    RemoveRequest (ModuleScript)
    Path: ServerStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ServerStorage:WaitForChild("Modules")
local Weapons = Modules:WaitForChild("Weapons")
local Weapon = Weapons:WaitForChild("Weapon")
local General = Weapons:WaitForChild("General")

local Requests = require(Weapons:WaitForChild("Requests"))

return function(Player, Id, ...)
	local Data = Requests:Get(Id)
	if Data then
		local Type = Data.Type
		if Type then
			local Module = Weapon:FindFirstChild(Type)
			if Module then
				Module = require(Module)
				if Module:IsValidRemoveData(...) then
					Module:RemoveRequest(Player, Id, ...)
				end
			end
		end
	end
end