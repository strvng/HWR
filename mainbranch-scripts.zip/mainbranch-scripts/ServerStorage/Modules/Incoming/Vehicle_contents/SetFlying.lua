--[[
    SetFlying (ModuleScript)
    Path: ServerStorage → Modules → Incoming → Vehicle
    Parent: Vehicle
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")

local VehicleHelper = require(Vehicle:WaitForChild("VehicleHelper"))

return function(Player, Flying)
	assert(typeof(Flying) == "boolean")
	
	local Vehicle = VehicleHelper.GetVehicle(Player)
	if Vehicle then
		local ServerFolder = Vehicle:FindFirstChild("Server")
		if ServerFolder then
			local Moving = ServerFolder:WaitForChild("Moving")
			if Moving then
				Moving.Value = Flying
			end
		end
	end
end