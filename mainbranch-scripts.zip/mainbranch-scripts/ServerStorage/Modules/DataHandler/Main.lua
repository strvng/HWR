--[[
    Main (ModuleScript)
    Path: ServerStorage → Modules → DataHandler
    Parent: DataHandler
    Exported: 2026-09-21 11:23:25
]]

--[[
this script will handle all the requests to save/get data
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local DataHandler = Modules:WaitForChild("DataHandler")
local Incoming = DataHandler:WaitForChild("Incoming")

local UploadData = Remotes:WaitForChild("UploadData")

UploadData.OnServerEvent:Connect(function(Player, Action, ...)
	local Module = Incoming:FindFirstChild(Action)
	if Module then
		require(Module)(Player, ...)
	end
end)

return nil