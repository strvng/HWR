--[[
    README (Script)
    Path: ServerStorage → Modules → DataHandler
    Parent: DataHandler
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:25
]]

--[[
USAGE
DataHandler.Data is the main entry point for handling the users data on the server.

DataHandler.Data:GetPlayer() will return a PlayerData object this is the main function you need to use
go read the PlayerData class there is usage in there

if you need to get a value from the PlayerData object just use PlayerData.XP:Get()

DataHandler.Data:HandlePlayer should be called everytime the player joins

DataHandler.Data:RemovePlayer DOES NOT save data it only removes their data from memory


]]