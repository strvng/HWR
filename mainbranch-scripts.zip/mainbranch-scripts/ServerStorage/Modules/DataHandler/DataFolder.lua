--[[
    DataFolder (ModuleScript)
    Path: ServerStorage → Modules → DataHandler
    Parent: DataHandler
    Exported: 2026-09-21 11:23:25
]]

--[[
DataFolder
this class is used for replicating the players' data on the server on the client without using RemoteEvents
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local DataHandler = Modules:WaitForChild("DataHandler")
local General = Modules:WaitForChild("General")
local DataHandlerGeneral = DataHandler:WaitForChild("General")
local InventoryGeneral = DataHandlerGeneral:WaitForChild("Inventory")
local Parachute = Modules:WaitForChild("Parachute")
local CustomizationFolder = ReplicatedModules:WaitForChild("Customization")

local ParachuteController = require(Parachute:WaitForChild("ParachuteController"))
local LevelController = require(CustomizationFolder:WaitForChild("LevelController"))
local LoadStarterGear = require(InventoryGeneral:WaitForChild("LoadStarterGear"))
local LoadCharacter = require(General:WaitForChild("LoadCharacter"))
local Config = require(DataHandler:WaitForChild("Config"))

local DataFolder = {}
DataFolder.__index = DataFolder

function DataFolder.new(PlayerData)
	local self = setmetatable({}, DataFolder)
	
	local Folder = Instance.new("Folder")
	Folder.Name = "Data"
	Folder.Parent = PlayerData.Player
	
	local Level = Instance.new("IntValue")
	Level.Name = "Level"
	Level.Parent = Folder
	
	local XP = Instance.new("IntValue")
	XP.Name = "XP"
	XP.Parent = Folder
	
	local CustomizationFolder = Instance.new("Folder")
	CustomizationFolder.Name = "Customization"
	CustomizationFolder.Parent = Folder
	
	local Trail = Instance.new("StringValue")
	Trail.Name = "Trail"
	Trail.Parent = CustomizationFolder
	
	local Parachute = Instance.new("StringValue")
	Parachute.Name = "Parachute"
	Parachute.Parent = CustomizationFolder
	
	self.Folder = Folder
	self.XP = XP
	self.Level = Level
	self.Trail = Trail
	self.Parachute = Parachute
	self.PlayerData = PlayerData
	
	local function XPChanged(Value)
		local XPToLevel = LevelController:GetXPToLevel(Level.Value)
		if XPToLevel and Value >= XPToLevel and Level.Value < LevelController:GetMaxLevel() then
			local Difference = Value - XPToLevel
			PlayerData.XP:Set(Difference)
			PlayerData.Level.Store:Increment(1)
		else
			XP.Value = Value
		end
	end
	
	local function LevelChanged(Value)
		Level.Value = Value
	end
	
	local function TrailChanged(Value)
		Trail.Value = Value
	end
	
	local function ParachuteChanged(Value)
		Parachute.Value = Value
		
		local Player = PlayerData.Player
		if Player then
			local Parachute, BaseHandle = ParachuteController.GetParachute(Player)
			if Parachute and BaseHandle then
				ParachuteController.ApplyCustomization(Parachute, Value)
			end
		end
	end
	
	PlayerData.XP:OnUpdate(XPChanged)
	PlayerData.Level:OnUpdate(LevelChanged)
	PlayerData.Customization.Trail:OnUpdate(TrailChanged)
	PlayerData.Customization.Parachute:OnUpdate(ParachuteChanged)
	
	self.XP.Value = PlayerData.XP:Get()
	self.Level.Value = PlayerData.Level:Get()
	self.Trail.Value = PlayerData.Customization.Trail:Get()
	self.Parachute.Value = PlayerData.Customization.Parachute:Get()
	
	return self
end

return DataFolder