--[[
    LoadStarterGear (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → General → Inventory
    Parent: Inventory
    Exported: 2026-09-21 11:23:25
]]
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local DataHandler = Modules:WaitForChild("DataHandler")
local General = DataHandler:WaitForChild("General")
local InventoryGeneral = General:WaitForChild("Inventory")
--local Maps = Modules:WaitForChild("Maps")

--local MapController = require(Maps:WaitForChild("MapController"))
local SortData = require(InventoryGeneral:WaitForChild("SortData"))
local GetTool = require(InventoryGeneral:WaitForChild("GetTool"))

return function(Player, Data, CloneToBackpack)
	local StarterGear = Player:WaitForChild("StarterGear")
	local Backpack = Player:WaitForChild("Backpack")
	local Character = Player.Character
	if StarterGear then
		StarterGear:ClearAllChildren()
		
		if CloneToBackpack then
			Backpack:ClearAllChildren()
		end
		
		for _, Saved in pairs(SortData(Data)) do
			local Slot = Saved.Slot
			local Name = Saved.Name
			if Slot then
				local Tool = GetTool(Name)
				if Tool then
					Tool = Tool:Clone()
					Tool:SetAttribute("LayoutOrder", Slot)
					Tool.Parent = StarterGear
					
					if CloneToBackpack and Character and Backpack then
						local Second = Tool:Clone()
						Second.Parent = Backpack
					end
				end
			end
		end
	end
end