--[[
    IsValidSort (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → General → Inventory
    Parent: Inventory
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

local DefaultTools = require(Settings:WaitForChild("DefaultTools"))
local IsVipTool = require(Settings:WaitForChild("VipTools"))
local GetDictionaryLength = require(Utilities:WaitForChild("GetDictionaryLength"))

local function IsTool(Name)
	local IsValid = false
	
	for _, v in pairs(DefaultTools) do
		local ToolName = v.Name
		if ToolName == Name then
			IsValid = true
		end
	end
	
	
	return IsValid or IsVipTool[Name]
end

return function(Sort, IsVip)
	local SortMax = 4
	local UsedTools = {}
	
	if IsVip then
		SortMax = 5
	end
	
	assert(typeof(Sort) == "table")
	assert(GetDictionaryLength(Sort) <= SortMax)
	
	for _, Data in pairs(Sort) do
		local Tool = Data.Name
		local Slot = Data.Slot
		
		if not table.find(UsedTools, Tool) then
			table.insert(UsedTools, Tool)
		else
			print('not valid sort')
			return false
		end
		
		if IsVipTool[Tool] then
			assert(IsVip)
		end
		
		assert(typeof(Slot) == "number")
		assert(typeof(Tool) == "string")
		assert(IsTool(Tool))
		assert(Slot <= 10)
		assert(Slot >= -1)
	end
	
	return true
end