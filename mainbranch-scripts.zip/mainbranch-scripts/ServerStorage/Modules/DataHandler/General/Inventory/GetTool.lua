--[[
    GetTool (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → General → Inventory
    Parent: Inventory
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Storage = ServerStorage:WaitForChild("Storage")
local StarterPack = Storage:WaitForChild("StarterPack")
local VipItems = Storage:WaitForChild("VipItems")
local Tools = Storage:WaitForChild("Tools")

return function(Name)
	return StarterPack:FindFirstChild(Name) or VipItems:FindFirstChild(Name) or Tools:FindFirstChild(Name)
end