--[[
    SortData (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → General → Inventory
    Parent: Inventory
    Exported: 2026-09-21 11:23:25
]]

return function(Data)
	table.sort(Data, function(a, b)
		return a.Slot < b.Slot
	end)
	
	return Data
end