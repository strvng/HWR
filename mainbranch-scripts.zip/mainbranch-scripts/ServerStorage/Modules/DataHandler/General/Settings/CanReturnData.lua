--[[
    CanReturnData (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → General → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:25
]]

local RequestHistory = {}

return function(Player, Request)
	-- leak
	local PreviousRequests = RequestHistory[Player]
	if PreviousRequests then
		if table.find(PreviousRequests, Request) then
			Player:Kick()
		else
			table.insert(PreviousRequests, Request)
			RequestHistory[Player] = PreviousRequests
			return true
		end
	else
		RequestHistory[Player] = {Request}
		return true
	end
end