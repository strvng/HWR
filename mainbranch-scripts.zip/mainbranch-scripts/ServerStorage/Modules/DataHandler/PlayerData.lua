--[[
    PlayerData (ModuleScript)
    Path: ServerStorage → Modules → DataHandler
    Parent: DataHandler
    Exported: 2026-09-21 11:23:25
]]

--[[
PlayerData
this class is to be contained under DataHandler.Data and is used for saving, getting and modifying user data

i will be using a folder saved under the player's object for easy replication to the client

i use local functions in order to encapsulate the module. i don't want access to those functions outside the module
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Utilities = ReplicatedModules:WaitForChild("Utilities")
local General = Modules:WaitForChild("General")
local DataHandler = Modules:WaitForChild("DataHandler")

local GetDictionaryLength = require(Utilities:WaitForChild("GetDictionaryLength"))
local DataFolder = require(DataHandler:WaitForChild("DataFolder"))
local Datastore2 = require(General:WaitForChild("Datastore2"))
local Signal = require(Utilities:WaitForChild("Signal"))
local Config = require(DataHandler:WaitForChild("Config"))

local PlayerData = {}
PlayerData.__index = PlayerData

local Keys = Config.Keys

local function HasOldData(Data)
	local LevelData = Data.Level.Store:Get(nil)
	
	if LevelData and typeof(LevelData) == "table" then
		return LevelData
	end
end

local Field = {}
Field.__index = Field

function Field.new(Player, Key, Default, SetCriteria)
	local self = setmetatable({}, Field)
	
	self.Key = Key
	self.Default = Default
	self.Store = Datastore2(Key, Player)
	self.SetCriteria = SetCriteria
	
	self:Get()
	
	return self
end

function Field:OnUpdate(Function)
	local Store = self.Store
	if Store then
		Store:OnUpdate(Function)
	end
end

function Field:Set(Value)
	local Store = self.Store
	local SetCriteria = self.SetCriteria
	if Store and SetCriteria then
		SetCriteria(Value)
		Store:Set(Value)
	end
end

function Field:Get()
	local Store = self.Store
	local Default = self.Default
	if Store then
		return Store:Get(Default)
	end
end

function PlayerData.new(Player)
	local self = setmetatable({}, PlayerData)
	
	self.Player = Player
	self.XP = Field.new(Player, Keys.XP, Config.Default.XP, function(Value)
		assert(typeof(Value) == "number")
		assert(Value >= 0)
	end)
	self.Level = Field.new(Player, Keys.Level, Config.Default.Level, function(Value)
		assert(typeof(Value) == "number")
		assert(Value >= 0)
	end)
	self.Settings = Field.new(Player, Keys.Settings, Config.Default.Settings, function(Value)
		assert(typeof(Value) == "table")
		assert(GetDictionaryLength(Value) == GetDictionaryLength(Config.Default.Settings))
	end)
	self.Tools = Field.new(Player, Keys.Tools, Config.Default.Tools, function(Value)
		assert(typeof(Value) == "table")
		-- very lenient because it is handled in Incoming.SetInventory
	end)
	self.Customization = {
		-- both also lenient because it's already handled
		Trail = Field.new(Player, Keys.Trail, Config.Default.Trail, function(Value)
			assert(typeof(Value) == "string")
		end),
		Parachute = Field.new(Player, Keys.Parachute, Config.Default.Parachute, function(Value)
			assert(typeof(Value) == "string")
		end)
	}
	
	--self.XP = Datastore2(Keys.XP, Player)
	--self.Level = Datastore2(Keys.Level, Player)
	--self.Settings = Datastore2(Keys.Settings, Player)
	--self.Tools = Datastore2(Keys.Tools, Player)
	--self.Customization = {
	--	Trail = Datastore2(Keys.Trail, Player),
	--	Parachute = Datastore2(Keys.Parachute, Player)
	--}
	--self.Level:Set(100)
	self.DataFolder = DataFolder.new(self)
	
	--[[
		my old system does not store data like this.
		it stores xp, level and trail under the "level" key
		we can't save data like this anymore because i was using datastore2 incorrectly and was saving on player removal.
		datastore2 caches the value until the game is closed then it saves everything.
		we don't want to send :OnUpdate when the trail updates but the xp is the same
		
		
		this new system will check if the player has old data and it will fill in the new
		values with the old data. once the player leaves the new data will overwrite the old
	]]
	
	local OldData = HasOldData(self)
	if OldData then
		self.XP:Set(0)--OldData.XP, reset xp in case they have max and have hundreds of thousands stacked
		self.Customization.Trail:Set(OldData.Trail)
		self.Level:Set(OldData.Level)
	end
	
	return self
end

function PlayerData:GetCustomization(Name)
	local CustomizationTable = self.Customization
	if CustomizationTable then
		local Key = CustomizationTable[Name]
		if Key then
			return Key
		end
	end
end

return PlayerData