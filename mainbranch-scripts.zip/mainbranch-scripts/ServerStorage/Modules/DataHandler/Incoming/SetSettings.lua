--[[
    SetSettings (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local SettingsFolder = ReplicatedModules:WaitForChild("Settings")
local Modules = ServerStorage:WaitForChild("Modules")
local DataHandler = Modules:WaitForChild("DataHandler")
local Utilities = ReplicatedModules:WaitForChild("Utilities")

local DefaultSettings = require(SettingsFolder:WaitForChild("Player"))
local GetDictionaryLength = require(Utilities:WaitForChild("GetDictionaryLength"))
local Data = require(DataHandler:WaitForChild("Data"))

local function IsValidSettings(Data)
	assert(typeof(Data) == "table")
	
	for k, v in pairs(Data) do
		assert(DefaultSettings[k] ~= nil)
		assert(typeof(v) == "boolean") -- forces it to only be boolean, no numbers
	end
	
	return true
end

return function(Player, SettingsData)
	if IsValidSettings(SettingsData) then
		local PlayerData = Data:GetPlayer(Player)
		if PlayerData then
			PlayerData.Settings:Set(SettingsData)
		end
	end
end