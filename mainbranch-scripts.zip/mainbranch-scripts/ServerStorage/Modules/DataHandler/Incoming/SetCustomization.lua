--[[
    SetCustomization (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Customization = ReplicatedModules:WaitForChild("Customization")
local DataHandler = Modules:WaitForChild("DataHandler")

local CustomizationController = require(Customization:WaitForChild("CustomizationController"))
local Data = require(DataHandler:WaitForChild("Data"))

local function GetCustomizationKey(PlayerData, Name)
	local Customization = PlayerData.Customization
	if Customization then
		return Customization[Name]
	end
end

return function(Player, Category, Item)
	local Customization = CustomizationController.GetCustomization(Category, Item)
	if Customization then
		local PlayerData = Data:GetPlayer(Player)
		if PlayerData and Customization:IsUnlocked(Player) then
			local Key = PlayerData:GetCustomization(Category)
			if Key then
				Key:Set(Item)
			end
		end
	end
end

--return function(Player, Category, Item)
--	local Customization = CustomizationController.GetCustomization(Category, Item)
--	if Customization then
--		local CustomizationLevel = Customization.Level
--		local PlayerData = Data:GetPlayer(Player)
--		if PlayerData and CustomizationLevel then
--			local Level = PlayerData.Level:Get()
--			if Level and Level >= CustomizationLevel then
--				local Key = PlayerData:GetCustomization(Category)
--				if Key then
--					Key:Set(Item)
--				end
--			end
--		end
--	end
--end