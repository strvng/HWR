--[[
    SetInventory (ModuleScript)
    Path: ServerStorage → Modules → DataHandler → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:25
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Menu = ReplicatedModules:WaitForChild("Menu")
local ReplicatedGeneral = Menu:WaitForChild("General")
local ReplicatedInventoryGeneral = ReplicatedGeneral:WaitForChild("Inventory")

local Modules = ServerStorage:WaitForChild("Modules")
local DataHandler = Modules:WaitForChild("DataHandler")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local General = Modules:WaitForChild("General")
local DataHandlerGeneral = DataHandler:WaitForChild("General")
local InventoryGeneral = DataHandlerGeneral:WaitForChild("Inventory")

local Marketplace = require(GamepassFolder:WaitForChild("Marketplace"))
local LoadStarterGear = require(InventoryGeneral:WaitForChild("LoadStarterGear"))
local LoadCharacter = require(General:WaitForChild("LoadCharacter"))
local IsValidSort = require(InventoryGeneral:WaitForChild("IsValidSort"))
local Settings = require(Modules:WaitForChild("Settings"))
local ToolOrder = require(ReplicatedInventoryGeneral:WaitForChild("ToolOrder"))
local Data = require(DataHandler:WaitForChild("Data"))

--local IsValidSort = require(Inventory:WaitForChild("IsValidSort"))
--local LoadStarterGear = require(Inventory:WaitForChild("LoadStarterGear"))
--local CreateSortCache = require(Inventory:WaitForChild("CreateSortCache"))

local function GetFallbackSort(IsVip)
	local DefaultSort = ToolOrder.GetToolsToSave(IsVip)
	
	for _, v in pairs(DefaultSort) do
		v.Slot = -1
	end
	
	return DefaultSort
end

local function FindTool(Sort, Name)
	for _, v in pairs(Sort) do
		if v.Name == Name then
			return v
		end
	end
end

return function(Player, ToolData)
	local PlayerData = Data:GetPlayer(Player)
	if PlayerData then
		if Marketplace:UserOwnsGamepass(Player, Settings.Vip.SortGamepassId) then
			local IsVip = Marketplace:UserOwnsGamepass(Player, Settings.Vip.VIPGamepassId)
			if IsValidSort(ToolData, IsVip) then
				local Fallback = GetFallbackSort(IsVip)
				for i, v in pairs(Fallback) do
					if not FindTool(ToolData, v.Name) then
						table.insert(ToolData, {
							Name = v.Name,
							Slot = -1
						})
					end
				end
				
				PlayerData.Tools:Set(ToolData)
			end
		end
	end
end