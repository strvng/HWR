--[[
    Config (ModuleScript)
    Path: ServerStorage → Modules → DataHandler
    Parent: DataHandler
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")

local DefaultSettings = require(Settings:WaitForChild("Player"))
local DefaultTools = require(Settings:WaitForChild("DefaultTools"))

return {
	MASTER_KEY = "master",
	Keys = {
		XP = "xp",
		Level = "level",
		Settings = "settings",
		Tools = "tools",
		Trail = "trail",
		Parachute = "parachute"
	},
	Default = {
		XP = 0,
		Level = 1,
		Trail = "None",
		Parachute = "None",
		Settings = DefaultSettings,
		Tools = nil,
		CustomizationDefault = "None"
	}
}