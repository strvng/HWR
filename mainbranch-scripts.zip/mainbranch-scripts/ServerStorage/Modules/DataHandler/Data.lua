--[[
    Data (ModuleScript)
    Path: ServerStorage → Modules → DataHandler
    Parent: DataHandler
    Exported: 2026-09-21 11:23:25
]]

--[[
Data
this singleton will handle all data for the server

the old version had PlayerRemoving functions but Datastore2 is not supposed to be used when the player leaves

Data:RemoveData does NOT save the players data. it will remove it from memory
when the player has left the game
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")
local DataHandler = Modules:WaitForChild("DataHandler")
local Utilities = ReplicatedModules:WaitForChild("Utilities")

local Signal = require(Utilities:WaitForChild("Signal"))
local Datastore2 = require(General:WaitForChild("Datastore2"))
local PlayerData = require(DataHandler:WaitForChild("PlayerData"))
local Config = require(DataHandler:WaitForChild("Config"))

local singleton

local Data = {}
Data.__index = Data
Data.DataLoaded = Signal.new()

for _, v in pairs(Config.Keys) do
	Datastore2.Combine(Config.MASTER_KEY, v)
end

function Data.new()
	local self = setmetatable({}, Data)
	
	self.Players = {}
	
	return self
end

function Data:_Get(Player)
	return self.Players[Player]
end

function Data:HandlePlayer(Player)
	local ExistingData = self:_Get(Player)
	if not ExistingData then
		local NewPlayerData = PlayerData.new(Player)
		
		self.Players[Player] = NewPlayerData
		
		Data.DataLoaded:Fire(NewPlayerData)
		
		return NewPlayerData
	end
end

function Data:RemoveData(Player)
	local ExistingData = self:_Get(Player)
	if ExistingData then
		-- fix for ancestry changed not firing
		local Store = Datastore2("master", Player)
		Store:Save()
		
		--ExistingData:Save()
		self.Players[Player] = nil
	end
end

function Data:GetPlayer(Player)
	local PlayerData = self:_Get(Player)
	if PlayerData then
		return PlayerData
	else
		return self:HandlePlayer(Player)
	end
end

singleton = Data.new()
return singleton