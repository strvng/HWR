--[[
    Dictionaries (ModuleScript)
    Path: ServerStorage → Modules → General
    Parent: General
    Exported: 2026-09-21 11:23:25
]]
return {
	VehicleOwners = {},
	RequestHistory = {},
	CachedSettings = {},
	HomingDebounce = {},
	Tagged = {},
	EquipKeys = {}
}