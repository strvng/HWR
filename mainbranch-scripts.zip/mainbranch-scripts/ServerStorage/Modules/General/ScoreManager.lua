--[[
    ScoreManager (ModuleScript)
    Path: ServerStorage → Modules → General
    Parent: General
    Exported: 2026-09-21 11:23:25
]]
local Module = {}

function GetLeader(Player)
	return Player:FindFirstChild("leaderstats")
end

function Module:GetScore(Player, ScoreName)
	local Leader = GetLeader(Player)
	if Leader then
		return Leader:FindFirstChild(ScoreName)
	end
end

function Module:AddScore(Player, ScoreName, Amount)
	local Score = self:GetScore(Player, ScoreName)
	if Score then
		Score.Value += Amount
	end
end

function Module:TakeScore(Player, ScoreName, Amount)
	local Score = self:GetScore(Player, ScoreName)
	if Score then
		Score.Value -= Amount
	end
end

function Module:SetScore(Player, ScoreName, Amount)
	local Score = self:GetScore(Player, ScoreName)
	if Score then
		Score.Value = Amount
	end
end

return Module
