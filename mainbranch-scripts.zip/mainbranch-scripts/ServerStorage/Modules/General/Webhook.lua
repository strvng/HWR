--[[
    Webhook (ModuleScript)
    Path: ServerStorage → Modules → General
    Parent: General
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")

local Settings = require(Modules:WaitForChild("Settings"))

local Webhook = {}

local BASE_PROFILE_URL = "https://www.roblox.com/users/%s/profile"

function Webhook.GetProfileURL(UserId)
	return string.format(BASE_PROFILE_URL, UserId)
end

function Webhook.FormatDuration(Duration)
	if Duration <= -1 then
		return "forever"
	elseif Duration > 1 then
		return string.format("%s days", Duration)
	elseif Duration == 1 then
		return "1 day"
	end
end

function Webhook.GetProfileAsMaskedLink(UserId)
	local Username = Players:GetNameFromUserIdAsync(UserId)
	return string.format("[%s](%s)", Username, Webhook.GetProfileURL(UserId))
end

function Webhook.ProfileList(UserIds)
	local Links = {}
	
	for _, v in pairs(UserIds) do
		table.insert(
			Links,
			Webhook.GetProfileAsMaskedLink(v)
		)
	end
	
	return table.concat(Links, ", ")
end

function Webhook.ComposeBanMessage(Params)
	local AdminId = Params.AdminId
	local PublicReason = Params.PublicReason
	local PrivateReason = Params.PrivateReason
	local Duration = Params.Duration
	local UserIds = Params.UserIds
	
	assert(AdminId)
	assert(PublicReason)
	assert(PrivateReason)
	assert(Duration)
	assert(UserIds)
	
	return {
		username = "BansBot",
		content = nil,
		embeds = {
			{
				title = "Banned users",
				description = string.format("Admin - **%s**", Webhook.GetProfileAsMaskedLink(AdminId)),
				color = 12387075,
				fields = {
					{
						name = "Public Reason",
						value = PublicReason
					},
					{
						name = "Private Reason",
						value = PrivateReason
					},
					{
						name = "Duration",
						value = Webhook.FormatDuration(Duration)
					},
					{
						name = "Users",
						value = Webhook.ProfileList(UserIds)
					}
				}
			}
		}
	}
end

function Webhook.ComposeUnbanMessage(Params)
	local AdminId = Params.AdminId
	local UserIds = Params.UserIds

	assert(AdminId)
	assert(UserIds)
	
	if Params.Reason then
		return {
			username = "BansBot",
			content = nil,
			embeds = {
				{
					title = "Unbanned Users",
					description = string.format("Admin - **%s**", Webhook.GetProfileAsMaskedLink(AdminId)),
					color = 1288709,
					fields = {
						{
							name = "Users",
							value = Webhook.ProfileList(UserIds)
						},
						{
							name = "Reason",
							value = Params.Reason
						}
					}
				}
			},
		}
	else
		return {
			username = "BansBot",
			content = nil,
			embeds = {
				{
					title = "Unbanned Users",
					description = string.format("Admin - **%s**", Webhook.GetProfileAsMaskedLink(AdminId)),
					color = 1288709,
					fields = {
						{
							name = "Users",
							value = Webhook.ProfileList(UserIds)
						}
					}
				}
			},
		}
	end
end

function Webhook.ComposeDisconnectMessage(Params)
	local UserId = Params.UserId
	local Reason = Params.Reason
	local Country = Params.Country
	assert(Country)
	assert(UserId)
	assert(Reason)
	assert(typeof(Reason) == "string")
	if #Reason > 250 then
		Reason = string.sub(Reason, 1, 250)
	end
	assert(#Reason < 1000)
	
	return {
		content = nil,
		username = "Disconnect Bot",
		description = "",
		--flags = 4,
		embeds = {
			{
				title = "Player Disconnected",
				color = 14869004,
				fields = {
				{
					name = "Reason",
					value = Reason
				},
				{
					name = "Country",
					value = Country
				},
				{
					name = "User",
					value = Webhook.GetProfileAsMaskedLink(UserId)
				}
				}
			}
		},
	}
end

function Webhook.ComposeKickMessage(Params)
	local AdminId = Params.AdminId
	local Reason = Params.Reason
	local UserId = Params.UserId
	
	assert(AdminId)
	assert(Reason)
	assert(UserId)
	
	return {
		username = "KickBot",
		content = nil,
		embeds = {
			{
				title = "Kicked user",
				description = string.format("Admin - **%s**", Webhook.GetProfileAsMaskedLink(AdminId)),
				color = 12065306,
				fields = {
					{
						name = "Reason",
						value = Reason
					},
					{
						name = "User",
						value = Webhook.GetProfileAsMaskedLink(UserId)
					}
				}
			}
		}
	}
end

function Webhook.ComposeFeedbackMessage(UserId, Message)
	assert(UserId)
	assert(Message)
	
	return {
		content = nil,
		username = "FeedbackBot",
		embeds = {
			{
				title = "Feedback",
				description = string.format("User - **%s**", Webhook.GetProfileAsMaskedLink(UserId)),
				color = 344490,
				fields = {
					{
						name = "Content",
						value = Message
					}
				}
			}
		},
	}

end

function Webhook.PostMessage(JSON)
	local Success, _ = pcall(function()
		HttpService:PostAsync(Settings.Feedback.WebhookURL, HttpService:JSONEncode(JSON), Enum.HttpContentType.ApplicationJson)
	end)
	
	if Success then
		return true
	end
end

return Webhook