--[[
    LoadCharacter (ModuleScript)
    Path: ServerStorage → Modules → General
    Parent: General
    Exported: 2026-09-21 11:23:25
]]

local Players = game:GetService("Players")

return function(Player)
	if Players.CharacterAutoLoads then
		Player:LoadCharacter()
	end
end