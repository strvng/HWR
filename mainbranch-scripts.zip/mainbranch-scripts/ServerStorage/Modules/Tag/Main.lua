--[[
    Main (ModuleScript)
    Path: ServerStorage → Modules → Tag
    Parent: Tag
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")

local Dictionaries = require(General:WaitForChild("Dictionaries"))

return function(Player, Attacker, Time, Type)
	Dictionaries.Tagged[Player] = {
		Attacker = Attacker,
		Weapon = Type,
	}
	
	task.defer(function()
		task.wait(Time)
		
		local Data = Dictionaries.Tagged[Player]
		if Data and Data.Attacker == Attacker then
			Dictionaries.Tagged[Player] = nil
		end
	end)
end