--[[
    HandleExplosion (ModuleScript)
    Path: ServerStorage → Modules → Explosions
    Parent: Explosions
    Exported: 2026-09-21 11:23:25
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Projectiles = ReplicatedModules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local Teamkill = Modules:WaitForChild("Teamkill")
local Weapons = Modules:WaitForChild("Weapons")
local General = Weapons:WaitForChild("General")
local Tag = Modules:WaitForChild("Tag")

local TagPlayer = require(Tag:WaitForChild("Main"))
local AreTeammates = require(Teamkill:WaitForChild("AreTeammates"))
local BreakJoints = require(Explosions:WaitForChild("BreakJoints"))

return function(Player, WeaponName, Hit)
	for i, v in pairs(Hit) do
		if typeof(v) == "Instance" and v:IsA("BasePart") and v.Parent and not v.Anchored and v:IsDescendantOf(workspace) then
			local Character = v:FindFirstAncestorOfClass("Model")
			if Character then
				local HitPlayer = Players:GetPlayerFromCharacter(Character)
				if HitPlayer then
					if not Character:FindFirstChildOfClass("ForceField") and (not AreTeammates(Player, HitPlayer) or Player == HitPlayer) then
						if AreTeammates(Player, HitPlayer) and HitPlayer ~= Player then
							return
						end
						
						TagPlayer(HitPlayer, Player, 5, WeaponName)
						BreakJoints(v)
						v:SetNetworkOwner(Player)
					end
				else
					BreakJoints(v)
					v:SetNetworkOwner(Player)
				end
			else
				BreakJoints(v)
				v:SetNetworkOwner(Player)
			end
		end
	end
end