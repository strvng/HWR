--[[
    GetEquipped (ModuleScript)
    Path: ServerStorage → Modules → Dagger
    Parent: Dagger
    Exported: 2026-09-21 11:23:25
]]

return function(Player)
	local Character = Player.Character
	if Character then
		return Character:FindFirstChildOfClass("Tool")
	end
end