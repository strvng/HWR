--[[
    GetDagger (ModuleScript)
    Path: ServerStorage → Modules → Dagger
    Parent: Dagger
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Dagger = Modules:WaitForChild("Dagger")

local GetEquipped = require(Dagger:WaitForChild("GetEquipped"))

return function(Player, ShouldBeEquipped)
	local Dagger = GetEquipped(Player)
	
	if not Dagger and not ShouldBeEquipped then
		local Backpack = Player:FindFirstChild("Backpack")
		if Backpack then
			Dagger = Backpack:FindFirstChild("Dagger")
		end
	end
	
	if Dagger and Dagger.Name == "Dagger" then
		return Dagger
	end
end