--[[
    GetSettings (ModuleScript)
    Path: ServerStorage → Modules → IncomingRequests
    Parent: IncomingRequests
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local ReplicatedSettings = ReplicatedModules:WaitForChild("Settings")
local DataHandler = Modules:WaitForChild("DataHandler")
local DataHandlerGeneral = DataHandler:WaitForChild("General")
local SettingsFolder = DataHandlerGeneral:WaitForChild("Settings")

local Data = require(DataHandler:WaitForChild("Data"))
local DefaultSettings = require(ReplicatedSettings:WaitForChild("Player"))
local CanReturnData = require(SettingsFolder:WaitForChild("CanReturnData"))

local function Reconcile(Data)
	-- removes old settings, adds new
	local Default = table.clone(DefaultSettings)
	
	for k, v in pairs(Data) do
		if Default[k] ~= nil then
			Default[k] = v
		end
	end
	
	return Default
end

return function(Player, Request, ...)
	if CanReturnData(Player, Request) then
		local PlayerData = Data:GetPlayer(Player)
		if PlayerData then
			local Settings = PlayerData.Settings:Get(nil)
			if Settings then
				return Reconcile(Settings)
			end
			--local Base = PlayerSettings.Settings
			--local SavedData = SettingsStore:Get(nil)
			
			--if SavedData then
			--	for Setting, Default in pairs(Base) do
			--		local IsSetting = SavedData[Setting] ~= nil
			--		if not IsSetting then
			--			SavedData[Setting] = Default
			--		end
			--	end
				
			--	return SavedData
			--else
			--	return nil
			--end
		end
	end
	
	return nil
end