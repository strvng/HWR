--[[
    Moderate (ModuleScript)
    Path: ServerStorage → Modules → IncomingRequests
    Parent: IncomingRequests
    Exported: 2026-09-21 11:23:25
]]

local MarketplaceService = game:GetService("MarketplaceService")
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Gamepass = Modules:WaitForChild("Gamepass")

local Settings = require(Modules:WaitForChild("Settings"))
--local Marketplace = require(Gamepass:WaitForChild("Marketplace"))
local General = Modules:WaitForChild("General")
local CommandHelper = require(Admin:WaitForChild("CommandHelper"))
local Webhook = require(General:WaitForChild("Webhook"))

local function CanBanUser(UserId)
	local success, result = pcall(function()
		return MarketplaceService:UserOwnsGamePassAsync(UserId, Settings.Vip.VIPGamepassId)
	end)
	
	if success and result then
		return false
	end
	
	return true
end

local Durations = {
	["1"] = 1 * 86400,
	["3"] = 3 * 86400,
	["5"] = 5 * 86400,
	["Perm"] = -1
}

local function GetDurationFromName(Name)
	return Durations[Name]
end

local function GetFinalData(Data)
	local FinalData = {}
	
	if not Data.Type or not Data.TargetPlayer then
		return
	end
	
	if Data.Type == "Ban" then
		if not Data.PublicReason or not Data.PrivateReason or not Data.Duration or Data.IsUserId == nil then
			return
		end
		
		if Data.IsUserId then
			FinalData.UserId = Data.TargetPlayer
		else
			FinalData.UserId = Data.TargetPlayer.UserId
		end
		
		FinalData.PublicReason = Data.PublicReason
		FinalData.PrivateReason = Data.PrivateReason
		
		local Duration = GetDurationFromName(Data.Duration)
		if not Duration then
			return
		end
		
		if Duration == -1 and Data.IsExploiting ~= true then
			return
		end
		print(Duration)
		FinalData.Duration = Duration
	elseif Data.Type == "Kick" then
		if not Data.Reason then
			return
		end
		
		FinalData.Player = Data.TargetPlayer
		FinalData.Reason = Data.Reason
	elseif Data.Type == "Unban" then
		print(Data.Reason)
		if not Data.Reason then
			return
		end
		
		FinalData.Reason = Data.Reason
		FinalData.UserId = Data.TargetPlayer
	end
	
	return FinalData
end

local function BanFunctionCopiedStraightFromBanCommandNeedsReplaced(Player, BannedUserId, PublicReason, PrivateReason, Duration)
	if not CommandHelper.IsUserStaff(BannedUserId) and PublicReason and PrivateReason and Duration then
		local NumberDuration = tonumber(Duration)
		local Config = {
			UserIds = {BannedUserId},
			Duration = NumberDuration,
			DisplayReason = PublicReason,
			PrivateReason = string.format("Banned by %s: %s", Player.Name, PrivateReason),
			ExcludeAltAccounts = false,
			ApplyToUniverse = true
		}
		
		local BanMessage = Webhook.ComposeBanMessage({
			AdminId = Player.UserId,
			PublicReason = PublicReason,
			PrivateReason = PrivateReason,
			Duration = NumberDuration,
			UserIds = {BannedUserId}
		})
		
		local Success = Webhook.PostMessage(BanMessage)
		if Success then
			Players:BanAsync(
				Config
			)
			
			local PlayerInGame = Players:GetPlayerByUserId(BannedUserId)
			if PlayerInGame then
				PlayerInGame:Kick(string.format("You are banned. Duration: %s, Reason: %s", Webhook.FormatDuration(NumberDuration), PublicReason))
			end
		end
	end
end

return function(Player, _, Data)
	local Level = CommandHelper.GetLevel(Player)
	if Level then
		local Commands = CommandHelper.GetAvailableCommands(Level)
		if Commands and Commands["BANMENU"] ~= nil then
			local FinalData = GetFinalData(Data)
			if FinalData then
				if Data.Type == "Ban" and CanBanUser(FinalData.UserId) then
					BanFunctionCopiedStraightFromBanCommandNeedsReplaced(
						Player,
						FinalData.UserId,
						FinalData.PublicReason,
						FinalData.PrivateReason,
						FinalData.Duration
					)
					
					return true
				elseif Data.Type == "Kick" then
					local KickMessage = Webhook.ComposeKickMessage({
						AdminId = Player.UserId,
						Reason = FinalData.Reason,
						UserId = FinalData.Player.UserId
					})
					
					local Success = Webhook.PostMessage(KickMessage)
					if Success then
						FinalData.Player:Kick(
							FinalData.Reason
						)
						
						return true
					end
				elseif Data.Type == "Unban" then
					local UnbanMessage = Webhook.ComposeUnbanMessage(
						{
							AdminId = Player.UserId,
							UserIds = {
								FinalData.UserId
							},
							Reason = FinalData.Reason
						}
					)
					
					local Success = Webhook.PostMessage(UnbanMessage)
					if Success then
						Players:UnbanAsync({
							UserIds = {FinalData.UserId},
							ApplyToUniverse = true
						})
						
						return true
					end
				end
			end
		end
	end
	
	return false
end

