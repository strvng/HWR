--[[
    JoinTeam (ModuleScript)
    Path: ServerStorage → Modules → IncomingRequests
    Parent: IncomingRequests
    Exported: 2026-09-21 11:23:25
]]


local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local Teams = game:GetService("Teams")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")

local UI = require(Settings:WaitForChild("UI"))

local StatusCodes = UI.TeamChange.StatusCodes
--local function CanJoinTeam(Player, Team)
--	local TeamCount = #Teams:GetTeams()
--	local TeamMemberCount = #Team:GetPlayers()
--	local MaxPlayers = Players.MaxPlayers

--	local BalancedAmount = MaxPlayers / TeamCount
--	-- add better logic
--	return TeamMemberCount < BalancedAmount
--end

local function CanJoinTeam(Player, Team)
	local CurrentTeam = Player.Team

	if not CurrentTeam then
		return true, StatusCodes.Success
	end

	local FromSize = #CurrentTeam:GetPlayers()
	local ToSize = #Team:GetPlayers()

	-- player can join if
	-- from team is greater than to team
	
	local CanJoin = FromSize > ToSize
	
	return CanJoin, (CanJoin and StatusCodes.Success) or StatusCodes.Unbalanced
end

return function(Player, _, TeamName)
	local Team = Teams:FindFirstChild(TeamName)
	
	if not Team or (Team and not Team:IsA("Team")) then
		return
	end
	
	local CanJoin, Status = CanJoinTeam(Player, Team)
	
	if CanJoin then
		Player.Team = Team
		Player:LoadCharacter()
	end
	
	return Status
end