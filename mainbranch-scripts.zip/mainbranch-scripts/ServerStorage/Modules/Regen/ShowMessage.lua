--[[
    ShowMessage (ModuleScript)
    Path: ServerStorage → Modules → Regen
    Parent: Regen
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local Settings = require(Modules:WaitForChild("Settings"))

return function()
	ReceiveIncoming:FireAllClients("SendMessage", "Message", {
		Text = "Regenerating Helicopters, Jeeps, And Towers...",
		Time = Settings.Regen.GlobalPauseTime
	})
end