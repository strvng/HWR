--[[
    ButtonTouched (ModuleScript)
    Path: ServerStorage → Modules → Regen
    Parent: Regen
    Exported: 2026-09-21 11:23:25
]]

local Players = game:GetService("Players")

return function(Button, RegenButton)
	Button.Touched:Connect(function(Hit)
		local Character = Hit.Parent
		if Character then
			local Player = Players:GetPlayerFromCharacter(Character)
			if Player then
				RegenButton:Regenerate()
			end
		end
	end)
end