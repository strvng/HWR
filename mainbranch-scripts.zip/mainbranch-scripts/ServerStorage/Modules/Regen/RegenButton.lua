--[[
    RegenButton (ModuleScript)
    Path: ServerStorage → Modules → Regen
    Parent: Regen
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Utilites = ReplicatedModules:WaitForChild("Utilities")

local DebrisFolder = require(Utilites:WaitForChild("DebrisFolder"))
local Settings = require(Modules:WaitForChild("Settings"))

local RegenButton = {}
RegenButton.__index = RegenButton

function RegenButton.new(Button, Model)
	local self = {}
	self.Button = Button
	self.Backup = Model:Clone()
	self.Enabled = true
	self.Regenerated = nil
	
	setmetatable(self, RegenButton)
	
	return self
end

function RegenButton:ChangeColor(On)
	local Button = self.Button
	
	if On then
		Button.BrickColor = Settings.Regen.ButtonOnColor
	else
		Button.BrickColor = Settings.Regen.ButtonOffColor
	end
end

function RegenButton:NewBackup()
	local New = self.Backup:Clone()
	New.Parent = DebrisFolder.ClearOnRegen
	
	return New
end

function RegenButton:Regenerate()
	if self.Enabled then
		local Regenerated = self.Regenerated
		local New = self:NewBackup()
		
		self:ChangeColor(false)
		self.Enabled = false
		
		if Regenerated then
			Regenerated(self, New)
		end
		
		task.defer(function()
			task.wait(Settings.Regen.DebounceTime)
			
			self:ChangeColor(true)
			self.Enabled = true
		end)
	end
end

return RegenButton