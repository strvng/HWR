--[[
    VehiclesToCheck (ModuleScript)
    Path: ServerStorage → Modules → Regen
    Parent: Regen
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local Utilities = ReplicatedModules:WaitForChild("Utilities")

local Settings = require(Modules:WaitForChild("Settings"))
local Timer = require(Utilities:WaitForChild("Timer"))

local Controller = {
	List = {}
}

local function CheckAll()
	for Vehicle, Data in pairs(Controller.List) do
		local Engine = Vehicle:FindFirstChild("Engine")
		if Engine then
			local EnginePosition = Engine.Position
			if (Data.StartPosition - EnginePosition).Magnitude >= Settings.Vehicles.SpawnMagnitude then
				Controller:RemoveFromList(Vehicle)
				
				Data.Callback()
			end
		else
			Controller:RemoveFromList(Vehicle)
		end
	end
end

function Controller:AddToList(Vehicle, Callback)
	local Engine = Vehicle:FindFirstChild("Engine")
	if Engine then
		self.List[Vehicle] = {
			Callback = Callback,
			StartPosition = Engine.Position
		}
	end
end

function Controller:RemoveFromList(Vehicle)
	self.List[Vehicle] = nil
end

Timer:Subscribe("MagnitudeTimer", CheckAll, 2)

return Controller