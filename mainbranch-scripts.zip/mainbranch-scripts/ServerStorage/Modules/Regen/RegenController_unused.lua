--[[
    RegenController(unused) (ModuleScript)
    Path: ServerStorage → Modules → Regen
    Parent: Regen
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local RegenFolder = Modules:WaitForChild("Regen")
local Utilites = ReplicatedModules:WaitForChild("Utilities")
local VehicleFolder = Modules:WaitForChild("Vehicle")

local Settings = require(Modules:WaitForChild("Settings"))
local ShowMessage = require(RegenFolder:WaitForChild("ShowMessage"))
local VehicleController = require(VehicleFolder:WaitForChild("Vehicle"))
local ButtonTouched = require(RegenFolder:WaitForChild("ButtonTouched"))
--local VehiclesToCheck = require(RegenFolder:WaitForChild("VehiclesToCheck"))
local RegenButtonController = require(RegenFolder:WaitForChild("RegenButton"))
--local DebrisFolder = require(Utilites:WaitForChild("DebrisFolder"))

--local DebrisFolder = workspace:WaitForChild("Debris")
--local Regen = workspace:WaitForChild("Regen")
--local ClearOnRegen = DebrisFolder:WaitForChild("ClearOnRegen")
--local VehiclesFolder = DebrisFolder:WaitForChild("Vehicles")

local RegenController = {
	--Backup = Regen:Clone(),
	--Model = Regen,
}

function RegenController:NewFolder(New)
	local VehiclesFolder = New:FindFirstChild("Vehicles")
	if VehiclesFolder then
		for i, v in pairs(VehiclesFolder:GetChildren()) do
			local RegenButton = v:FindFirstChild("Button")
			local VehicleModel = v:FindFirstChildOfClass("Model")
			if RegenButton and VehicleModel then
				local RegenController = RegenButtonController.new(RegenButton, VehicleModel)
				RegenController.Regenerated = function(Button, New)
					local NewVehicle = VehicleController.new(New, RegenController)
				end
				ButtonTouched(RegenButton, RegenController)
				
				VehicleController.new(VehicleModel, RegenController)
			end
		end
	end
end

--function RegenController:Regenerate()
--	local New = RegenController.Backup:Clone()
	
--	RegenController.Model:Destroy()
--	ClearOnRegen:ClearAllChildren()
--	VehiclesFolder:ClearAllChildren()
--	ShowMessage()
	
--	task.defer(function()
--		task.wait(Settings.Regen.PauseTime)
--		New.Parent = workspace
--	end)
	
--	RegenController:NewFolder(New)
--	RegenController.Model = New
	
--	return New
--end

--RegenController:NewFolder(Regen)

return RegenController