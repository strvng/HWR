--[[
    GetPlayerFromHumanoid (ModuleScript)
    Path: ServerStorage → Modules → Regen
    Parent: Regen
    Exported: 2026-09-21 11:23:25
]]
local Players = game:GetService("Players")

return function(Humanoid)
	if Humanoid then
		local Character = Humanoid.Parent
		return Players:GetPlayerFromCharacter(Character)
	end
end