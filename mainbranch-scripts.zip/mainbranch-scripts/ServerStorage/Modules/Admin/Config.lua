--[[
    Config (ModuleScript)
    Path: ServerStorage → Modules → Admin
    Parent: Admin
    Exported: 2026-09-21 11:23:25
]]

return {
	Ranks = {
		Admins = {
			Level = 3,
			Users = {
				82288569,
			}
		},
		Mods = {
			Level = 2,
			Users = {
				190046
			}
		},
		JrMods = {
			Level = 1,
			Users = {
				8157399518, -- striving
				9449347119, -- zvy97
				222563845 -- monsta86
			}
		}
	},
	Prefix = ":"
}