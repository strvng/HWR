--[[
    FreeVipUsers (ModuleScript)
    Path: ServerStorage → Modules → Admin
    Parent: Admin
    Exported: 2026-09-21 11:23:25
]]

return {
	190046, -- Bingus,
	8157399518 -- Striving
}