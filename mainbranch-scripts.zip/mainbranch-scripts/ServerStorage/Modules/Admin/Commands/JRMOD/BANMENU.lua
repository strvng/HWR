--[[
    BANMENU (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → JRMOD
    Parent: JRMOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))

local Menu = script:WaitForChild("Moderation")

return function(Player)
	local PlayerGui = Player:FindFirstChild("PlayerGui")
	if PlayerGui then
		if PlayerGui:FindFirstChild(Menu.Name) then
			return
		end
		
		local NewMenu = Menu:Clone()
		NewMenu.Parent = PlayerGui
	end
end