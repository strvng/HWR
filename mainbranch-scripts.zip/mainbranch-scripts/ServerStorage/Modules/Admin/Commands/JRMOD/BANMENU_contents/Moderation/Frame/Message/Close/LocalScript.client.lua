--[[
    LocalScript (LocalScript)
    Path: ServerStorage → Modules → Admin → Commands → JRMOD → BANMENU → Moderation → Frame → Message → Close
    Parent: Close
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:25
]]

script.Parent.Activated:Connect(function()
	script.Parent.Parent.Visible = false
	script.Parent.Parent.Parent.Content.Interactable = true
end)