--[[
    Main (LocalScript)
    Path: ServerStorage → Modules → Admin → Commands → JRMOD → BANMENU → Moderation → Frame → Content
    Parent: Content
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:25
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local RequestData = Remotes:WaitForChild("RequestData")

local Frame = script.Parent
local Gui = Frame.Parent
local PlayerFrame = Frame:WaitForChild("Player")
local BanType = Frame:WaitForChild("BanType")
local ControlsFrame = Frame:WaitForChild("Controls")

local MessageFrame = Frame.Parent:WaitForChild("Message")
local MessageText = MessageFrame:WaitForChild("Message")

local function ShowMessage(Text)
	Frame.Interactable = false
	MessageFrame.Visible = true
	MessageText.Text = Text
end

local UsernameBox = PlayerFrame:WaitForChild("Username")
local PlayerIcon = PlayerFrame:WaitForChild("Icon")

--local function FindPlayerBySubstring(substring)
--	substring = string.lower(substring)
--	for _, player in ipairs(Players:GetPlayers()) do
--		if string.find(string.lower(player.Name), substring, 1, true) 
--			or string.find(string.lower(player.DisplayName), substring, 1, true) then
--			return player
--		end
--	end
	
--	return nil
--end

local function FindPlayerBySubstring(substring)
	substring = string.lower(substring)
	for _, player in ipairs(Players:GetPlayers()) do
		local name = string.lower(player.Name)
		local displayName = string.lower(player.DisplayName)
		
		-- Only match if the name *starts with* the substring
		if name:sub(1, #substring) == substring 
			or displayName:sub(1, #substring) == substring then
			return player
		end
	end
	return nil
end

local CurrentPlayer
local IsUserId = false

UsernameBox.FocusLost:Connect(function()
	local Player = FindPlayerBySubstring(UsernameBox.Text)
	local UserId = tonumber(UsernameBox.Text)
	if Player and UsernameBox.Text ~= "" then
		CurrentPlayer = Player
		IsUserId = false
		PlayerIcon.Image = Players:GetUserThumbnailAsync(
			Player.UserId,
			Enum.ThumbnailType.HeadShot,
			Enum.ThumbnailSize.Size420x420
		)
		UsernameBox.Text = Player.Name
	elseif UserId ~= nil then
		CurrentPlayer = UserId
		IsUserId = true
		
		local Username = Players:GetNameFromUserIdAsync(UserId)
		if Username then
			UsernameBox.Text = Username
		end
		
		PlayerIcon.Image = Players:GetUserThumbnailAsync(
			UserId,
			Enum.ThumbnailType.HeadShot,
			Enum.ThumbnailSize.Size420x420
		)
	else
		IsUserId = false
		CurrentPlayer = nil
		PlayerIcon.Image = ""
	end
end)

local function GroupSelection(Frame, Callback, Descendants)
	local Current
	local Buttons = {}
	local Group = Descendants and Frame:GetDescendants() or Frame:GetChildren()
	
	local function Highlight(Button)
		Button.BackgroundColor3 = Color3.fromRGB(29, 29, 29)
		
		local UIStroke = Button:FindFirstChild("UIStroke")
		if UIStroke then
			UIStroke.Color = Color3.fromRGB(255, 255, 255)
		end
	end
	
	local function Unhighlight(Button)
		Button.BackgroundColor3 = Color3.fromRGB(51, 51, 51)
		
		local UIStroke = Button:FindFirstChild("UIStroke")
		if UIStroke then
			UIStroke.Color = Color3.fromRGB(0, 0, 0)
		end
	end
	
	local function SetCurrent(v)
		if Current then
			Unhighlight(Current)
		end
		
		if Current == v then
			Current = nil
			return
		end
		
		Current = v
		Highlight(v)
		if Callback then
			Callback(Current)
		end
	end
	
	for _, v in pairs(Group) do
		if v:IsA("TextButton") then
			v.Activated:Connect(function()
				SetCurrent(v)
			end)
			
			table.insert(Buttons, v)
		end
	end
	
	local function GetCurrent()
		return Current
	end
	
	return GetCurrent, Buttons, SetCurrent
end

local DurationFrame = Frame:WaitForChild("Duration")
local PermBanButton = DurationFrame:WaitForChild("Perm")
local TypesFrame = BanType:WaitForChild("Types")
local ExploitCheck = BanType:WaitForChild("ExploitCheck")

local ExploitingChecked = false
local GetDuration, DurationButtons, SetDurationButton = GroupSelection(DurationFrame)

local function CheckPermBanInteractable()
	if ExploitingChecked then
		PermBanButton.Interactable = true
		PermBanButton.TextColor3 = Color3.fromRGB(255, 255, 255)
	else
		if GetDuration() == PermBanButton then
			SetDurationButton(DurationButtons[1])
		end
		
		PermBanButton.Interactable = false
		PermBanButton.TextColor3 = Color3.fromRGB(91, 91, 91)
	end
end

ExploitCheck.Activated:Connect(function()
	ExploitingChecked = not ExploitingChecked
	
	if ExploitingChecked then
		ExploitCheck.Check.Image = "rbxassetid://12690727184"
	else
		ExploitCheck.Check.Image = ""
	end
	
	CheckPermBanInteractable()
end)

CheckPermBanInteractable()


-- final methods
-- exploiting checked
-- CurrentPlayer
-- IsUserId
local ReasonFrame = Frame:WaitForChild("Reason")
local ReasonContainer = ReasonFrame:WaitForChild("Frame")
local PrivateReasonFrame = ReasonContainer:WaitForChild("Private")
local PublicReasonFrame = ReasonContainer:WaitForChild("Public")
local PrivateReasonContent = PrivateReasonFrame:WaitForChild("Content")
local PublicReasonContent = PublicReasonFrame:WaitForChild("Content")

local GetBanType = GroupSelection(TypesFrame, function(Type)
	if Type.Name == "Kick" or Type.Name == "Unban" then
		PrivateReasonFrame.Visible = false
		DurationFrame.Visible = false
	elseif Type.Name == "Ban" then
		DurationFrame.Visible = true
		PrivateReasonFrame.Visible = true
	end
end, true)

local SubmitButton = ControlsFrame:WaitForChild("Submit")

local function IsEmptyOrWhitespace(str)
	if str == "" then
		return true
	end
	
	if str:match("^%s+$") then
		return true
	end
	
	return false
end

SubmitButton.Activated:Connect(function()
	local BanType = GetBanType()
	if not BanType then
		ShowMessage("Please select a ban type")
		return
	end
	
	if not CurrentPlayer then
		ShowMessage("Please select a player")
		return
	end
	
	if BanType.Name == "Ban" then
		local Duration = GetDuration()
		if not Duration then
			ShowMessage("Please select a ban duration")
			return
		end
		
		if IsEmptyOrWhitespace(PublicReasonContent.Text) or IsEmptyOrWhitespace(PrivateReasonContent.Text) then
			ShowMessage("Please verify both public and private reasons have been filled out")
			return
		end
		
		local Success = RequestData:InvokeServer("Moderate", {
			Type = "Ban",
			TargetPlayer = CurrentPlayer,
			IsUserId = IsUserId,
			Duration = Duration.Name,
			PublicReason = PublicReasonContent.Text,
			PrivateReason = PrivateReasonContent.Text,
			IsExploiting = ExploitingChecked,
		})
		if Success then
			ShowMessage("Success")
		else
			ShowMessage("Error")
		end
	elseif BanType.Name == "Kick" then
		if IsUserId then
			ShowMessage("Cannot kick a player by user id")
			return
		end
		
		if IsEmptyOrWhitespace(PublicReasonContent.Text) then
			ShowMessage("Please provide a valid kick reason")
			return
		end
		
		local Success = RequestData:InvokeServer("Moderate", {
			Type = "Kick",
			TargetPlayer = CurrentPlayer,
			Reason = PublicReasonContent.Text
		})
		
		if Success then
			ShowMessage("Success")
		else
			ShowMessage("Error")
		end
	elseif BanType.Name == "Unban" then
		if not IsUserId then
			ShowMessage("You can't unban a player that is in game 🤦")
			return
		end
		
		if IsEmptyOrWhitespace(PublicReasonContent.Text) then
			ShowMessage("Please provide a valid unban reason")
			return
		end
		
		local Success = RequestData:InvokeServer("Moderate", {
			Type = "Unban",
			TargetPlayer = CurrentPlayer,
			Reason = PublicReasonContent.Text
		})
		
		if Success then
			ShowMessage("Success")
		else
			ShowMessage("Error")
		end
	end
end)