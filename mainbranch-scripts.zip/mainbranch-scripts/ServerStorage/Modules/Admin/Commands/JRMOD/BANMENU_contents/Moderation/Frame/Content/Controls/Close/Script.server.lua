--[[
    Script (Script)
    Path: ServerStorage → Modules → Admin → Commands → JRMOD → BANMENU → Moderation → Frame → Content → Controls → Close
    Parent: Close
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:25
]]

script.Parent.MouseButton1Down:Connect(function()
	local Gui = script:FindFirstAncestorOfClass("ScreenGui")
	if Gui then
		Gui:Destroy()
	end
end)