--[[
    ADMIN (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions")

local GetPlayer = require(Functions:WaitForChild("GetPlayer"))
local Config = require(Admin:WaitForChild("Config"))

return function(Player, PlayerName)
	if PlayerName then
		local Players = GetPlayer(Player, PlayerName)
		if Players then
			for _, v in pairs(Players) do
				table.insert(Config.Ranks.Admins.Users, v.UserId)
			end
		end
	end
end