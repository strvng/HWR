--[[
    STARTERTOOL (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]


local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))

return function(Player, PlayerName, ToolName)
	if PlayerName and ToolName then
		local Players = CommandHelper.Util.GetPlayer(Player, PlayerName)
		local Tool = CommandHelper.Util.GetToolFromStorage(ToolName)
		if Players and Tool then
			for _, v in pairs(Players) do
				local StarterGear = v:FindFirstChild("StarterGear")
				local Backpack = v:FindFirstChild("Backpack")
				if StarterGear and Backpack then
					local NewTool = Tool:Clone()
					NewTool.Parent = StarterGear
					
					local NewBackpackTool = Tool:Clone()
					NewBackpackTool.Parent = Backpack
				end
			end
		end
	end
end