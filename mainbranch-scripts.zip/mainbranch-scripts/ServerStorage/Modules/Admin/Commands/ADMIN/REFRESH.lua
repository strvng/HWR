--[[
    REFRESH (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]

local Commands = script.Parent

local Respawn = require(Commands:WaitForChild("RESPAWN"))

return Respawn