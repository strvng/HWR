--[[
    ENDROUND (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]

local Teams = game:GetService("Teams")

return function(Player)
	local TeamObjects = Teams:GetTeams()
	if TeamObjects then
		local First = TeamObjects[1]
		if First then
			First:SetAttribute("Score", 50)
		end
	end
end