--[[
    UNGIVE (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))

return function(Player, PlayerName, ToolName)
	if PlayerName and ToolName then
		local Players = CommandHelper.Util.GetPlayer(Player, PlayerName)
		if Players then
			for _, v in pairs(Players) do
				local Backpack = v:FindFirstChild("Backpack")
				local Character = v.Character
				if Backpack then
					local Tool = CommandHelper.Util.AutocompleteChildren(Backpack, ToolName)
					if Tool then
						Tool:Destroy()
					end
				end
				
				if Character then
					local Tool = Character:FindFirstChildOfClass("Tool")
					if Tool and CommandHelper.Util.Autocomplete(string.lower(ToolName), string.lower(Tool.Name)) then
						Tool:Destroy()
					end
				end
			end
		end
	end
end