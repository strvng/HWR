--[[
    SETTEAM (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Teams = game:GetService("Teams")

local Modules = ServerStorage:WaitForChild("Modules")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions")

local Marketplace = require(GamepassFolder:WaitForChild("Marketplace"))
local Settings = require(Modules:WaitForChild("Settings"))
local GetPlayer = require(Functions:WaitForChild("GetPlayer"))
local AutocompleteChildren = require(Functions:WaitForChild("AutocompleteChildren"))

return function(Player, PlayerName, Team)
	if PlayerName then
		local FoundTeam = AutocompleteChildren(Teams, Team)
		if FoundTeam then
			local Players = GetPlayer(Player, PlayerName)
			if Players then
				for _, v in pairs(Players) do
					v.Team = FoundTeam
				end
			end
		end
	end
end