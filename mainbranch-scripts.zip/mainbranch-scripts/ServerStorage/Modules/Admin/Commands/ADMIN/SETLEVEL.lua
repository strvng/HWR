--[[
    SETLEVEL (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local DataHandler = Modules:WaitForChild("DataHandler")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))
local Data = require(DataHandler:WaitForChild("Data"))

return function(Player, PlayerName, Amount)
	if PlayerName and Amount then
		local Players = CommandHelper.Util.GetPlayer(Player, PlayerName)
		if Players then
			for _, v in pairs(Players) do
				local PlayerData = Data:GetPlayer(v)
				if PlayerData then
					local Amount = tonumber(Amount)
					if Amount then
						PlayerData.Level:Set(Amount)
					end
				end
				--local Data = v:FindFirstChild("Data")
				--if Data then
				--	local LevelFolder = Data:WaitForChild("LevelFolder")
				--	if LevelFolder then
				--		local Level = LevelFolder:FindFirstChild("Level")
				--		if Level then
				--			Level.Value = tonumber(Amount) or 0
				--		end
				--	end
				--end
			end
		end
	end
end