--[[
    UNSTARTERTOOL (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → ADMIN
    Parent: ADMIN
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Storage = ServerStorage:WaitForChild("Storage")
local Admin = Modules:WaitForChild("Admin")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))

return function(Player, PlayerName, ToolName)
	if PlayerName and ToolName then
		local Players = CommandHelper.Util.GetPlayer(Player, PlayerName)
		if Players then
			for _, v in pairs(Players) do
				local StarterGear = v:FindFirstChild("StarterGear")
				if StarterGear then
					local Tool = CommandHelper.Util.AutocompleteChildren(StarterGear, ToolName)
					if Tool then
						Tool:Destroy()
					end
				end
			end
		end
	end
end