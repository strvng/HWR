--[[
    FF (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions")

local GetPlayer = require(Functions:WaitForChild("GetPlayer"))

return function(Player, PlayerName)
	if PlayerName then
		local Players = GetPlayer(Player, PlayerName)
		if Players then
			for _, v in pairs(Players) do
				local Character = v.Character
				if Character then
					local ForceField = Instance.new("ForceField")
					ForceField.Parent = Character
				end
			end
		end
	end
end