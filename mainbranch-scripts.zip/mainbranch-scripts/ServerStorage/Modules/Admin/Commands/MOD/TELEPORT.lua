--[[
    TELEPORT (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))

return function(Player, PlayerName1, PlayerName2)
	if PlayerName1 and PlayerName2 then
		local Player1 = CommandHelper.Util.AutocompletePlayers(PlayerName1)
		local Player2 = CommandHelper.Util.AutocompletePlayers(PlayerName2)
		if Player1 and Player2 then
			CommandHelper.Util.Teleport(Player1, Player2)
		end
	end
end