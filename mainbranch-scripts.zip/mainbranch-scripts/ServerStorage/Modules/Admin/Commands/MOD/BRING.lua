--[[
    BRING (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))

return function(Player, PlayerName)
	if PlayerName then
		local Players = CommandHelper.Util.GetPlayer(Player, PlayerName)
		if Players then
			for _, v in pairs(Players) do
				CommandHelper.Util.Teleport(v, Player)
			end
		end
	end
end