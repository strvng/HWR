--[[
    TO (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))

return function(AdminPlayer, PlayerName)
	if PlayerName then
		local Player = CommandHelper.Util.AutocompletePlayers(PlayerName)
		if Players then
			CommandHelper.Util.Teleport(AdminPlayer, Player)
		end
	end
end