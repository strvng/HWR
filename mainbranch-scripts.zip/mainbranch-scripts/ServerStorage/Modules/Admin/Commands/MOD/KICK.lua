--[[
    KICK (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local PhysicsService = game:GetService("PhysicsService")
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions")

local GetPlayer = require(Functions:WaitForChild("GetPlayer"))

return function(Player, PlayerName, Reason)
	if PlayerName and Reason then
		local Kicked = GetPlayer(Player, PlayerName)
		if Kicked then
			for _, v in pairs(Kicked) do
				v:Kick(Reason)
			end
		end
	end
end