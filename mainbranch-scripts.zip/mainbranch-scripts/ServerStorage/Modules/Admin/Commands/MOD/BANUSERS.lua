--[[
    BANUSERS (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")

local Webhook = require(General:WaitForChild("Webhook"))

return function(Player, ...)
	local UserIds = {}
	local EndPosition = 1
	
	local Parameters = table.pack(...)
	
	for i, v in pairs(Parameters) do
		local IsNumber = tonumber(v)
		if IsNumber then
			table.insert(UserIds, IsNumber)
			EndPosition = i
		else
			break
		end
	end
	
	local PublicReason = Parameters[EndPosition+1]
	local PrivateReason = Parameters[EndPosition+2]
	local Duration = tonumber(Parameters[EndPosition+3])
	if UserIds and #UserIds > 0 and PublicReason and PrivateReason and Duration then
		local NumberDuration = tonumber(Duration)
		local Config = {
			UserIds = UserIds,
			Duration = NumberDuration,
			DisplayReason = PublicReason,
			PrivateReason = string.format("Banned by %s: %s", Player.Name, PrivateReason),
			ExcludeAltAccounts = false,
			ApplyToUniverse = true
		}
		
		local BanMessage = Webhook.ComposeBanMessage({
			AdminId = Player.UserId,
			PublicReason = PublicReason,
			PrivateReason = PrivateReason,
			Duration = NumberDuration,
			UserIds = UserIds
		})
		
		local Success = Webhook.PostMessage(BanMessage)
		if Success then
			Players:BanAsync(
				Config
			)
		end
	end
	--local Config = {
	--	UserIds = {BannedPlayer.UserId},
	--	Duration = tonumber(Duration),
	--	DisplayReason = PublicReason,
	--	PrivateReason = PrivateReason,
	--	ExcludeAltAccounts = false,
	--	ApplyToUniverse = true
	--}

	--local Message = ComposeMessage(
	--	string.format("%s banned %s (%s)", Player.DisplayName, BannedPlayer.DisplayName, BannedPlayer.UserId),
	--	string.format("Public Reason: %s, Private Reason: %s, Duration: %s", PublicReason, PrivateReason, Duration)
	--)
	--local Response

	--local Success, _ = pcall(function()
	--	Response = HttpService:PostAsync(Settings.Feedback.WebhookURL, Message, Enum.HttpContentType.ApplicationJson)
	--end)

	--if Success then
	--	Players:BanAsync(
	--		Config
	--	)
	--	BannedPlayer:Kick(string.format("You are banned for %s days: %s", Duration, PublicReason))
	--end
end