--[[
    BAN (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local General = Modules:WaitForChild("General")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))
local Settings = require(Modules:WaitForChild("Settings"))
local Webhook = require(General:WaitForChild("Webhook"))

return function(Player, PlayerName, PublicReason, PrivateReason, Duration)
	if PlayerName and PublicReason and PrivateReason and Duration then
		local BannedPlayer = CommandHelper.Util.AutocompletePlayers(PlayerName)
		if BannedPlayer and not CommandHelper.IsUserStaff(BannedPlayer.UserId) then
			local NumberDuration = tonumber(Duration)
			local Config = {
				UserIds = {BannedPlayer.UserId},
				Duration = NumberDuration,
				DisplayReason = PublicReason,
				PrivateReason = string.format("Banned by %s: %s", Player.Name, PrivateReason),
				ExcludeAltAccounts = false,
				ApplyToUniverse = true
			}
			
			local BanMessage = Webhook.ComposeBanMessage({
				AdminId = Player.UserId,
				PublicReason = PublicReason,
				PrivateReason = PrivateReason,
				Duration = NumberDuration,
				UserIds = {BannedPlayer.UserId}
			})
			
			local Success = Webhook.PostMessage(BanMessage)
			if Success then
				Players:BanAsync(
					Config
				)
				
				BannedPlayer:Kick(string.format("You are banned. Duration: %s, Reason: %s", Webhook.FormatDuration(NumberDuration), PublicReason))
			end
		end
	end
end