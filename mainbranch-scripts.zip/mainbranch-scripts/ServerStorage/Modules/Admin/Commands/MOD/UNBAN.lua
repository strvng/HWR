--[[
    UNBAN (ModuleScript)
    Path: ServerStorage → Modules → Admin → Commands → MOD
    Parent: MOD
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local General = Modules:WaitForChild("General")
local Functions = Admin:WaitForChild("Functions")

local Webhook = require(General:WaitForChild("Webhook"))
local Autocomplete = require(Functions:WaitForChild("Autocomplete"))
local GetPlayer = require(Functions:WaitForChild("GetPlayer"))
local Settings = require(Modules:WaitForChild("Settings"))

return function(Player, ...)
	local Ids = table.pack(...)
	if Ids then
		local UserIds = {}
		
		for k, v in pairs(Ids) do
			if k ~= "n" then
				table.insert(UserIds, tonumber(v))
			end
		end
		
		local Config = {
			UserIds = UserIds,
			ApplyToUniverse = true,
		}
		
		local Message = Webhook.ComposeUnbanMessage({
			AdminId = Player.UserId,
			UserIds = UserIds
		})
		
		local Success = Webhook.PostMessage(Message)
		if Success then
			Players:UnbanAsync(Config)
		end
	end
end