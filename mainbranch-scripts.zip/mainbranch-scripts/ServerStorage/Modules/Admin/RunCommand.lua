--[[
    RunCommand (ModuleScript)
    Path: ServerStorage → Modules → Admin
    Parent: Admin
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Commands = Admin:WaitForChild("Commands")

local CommandHelper = require(Admin:WaitForChild("CommandHelper"))
local Config = require(Admin:WaitForChild("Config"))

return function(Player, Message)
	local Level = CommandHelper.GetLevel(Player)
	if Level and string.sub(Message, 1, 1) == Config.Prefix then
		local AvailableCommands = CommandHelper.GetAvailableCommands(Level)
		if AvailableCommands then
			local Command = string.sub(Message, 2, string.len(Message))
			local Parameters = string.split(Command, " ")
			local CommandName = Parameters[1]
			if CommandName then
				local CommandModule = AvailableCommands[string.upper(CommandName)]
				if CommandName and CommandModule then
					table.remove(Parameters, 1)
					CommandModule(Player, table.unpack(Parameters))
				end
			end
		end
	end
end