--[[
    GetPlayer (ModuleScript)
    Path: ServerStorage → Modules → Admin → Functions
    Parent: Functions
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions")

local Autocomplete = require(Functions:WaitForChild("Autocomplete"))

local lower = string.lower

return function(Player, Name)
	Name = lower(Name)
	
	if Name == "all" then
		return Players:GetPlayers()
	elseif Name == "others" then
		local Found = {}
		
		for _, v in pairs(Players:GetPlayers()) do
			if v ~= Player then
				table.insert(Found, v)
			end
		end
		
		return Found
	elseif Name == "me" then
		return {Player}
	else
		for _, v in pairs(Players:GetPlayers()) do
			if Autocomplete(Name, lower(v.Name)) or Autocomplete(Name, lower(v.DisplayName)) then
				return {v}
			end
		end
	end
end