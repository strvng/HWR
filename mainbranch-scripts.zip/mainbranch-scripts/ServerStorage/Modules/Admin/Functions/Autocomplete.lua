--[[
    Autocomplete (ModuleScript)
    Path: ServerStorage → Modules → Admin → Functions
    Parent: Functions
    Exported: 2026-09-21 11:23:25
]]

return function(Short, Base)
	return string.sub(Base, 1, string.len(Short)) == Short
end