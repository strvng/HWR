--[[
    AutocompletePlayers (ModuleScript)
    Path: ServerStorage → Modules → Admin → Functions
    Parent: Functions
    Exported: 2026-09-21 11:23:25
]]
local ServerStorage = game:GetService("ServerStorage")
local Players = game:GetService("Players")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions") 

local Autocomplete = require(Functions:WaitForChild("Autocomplete"))

return function(Name)
	for _, v in pairs(Players:GetPlayers()) do
		if Autocomplete(string.lower(Name), string.lower(v.Name)) or Autocomplete(string.lower(Name), string.lower(v.DisplayName)) then
			return v
		end
	end
end