--[[
    Teleport (ModuleScript)
    Path: ServerStorage → Modules → Admin → Functions
    Parent: Functions
    Exported: 2026-09-21 11:23:25
]]

return function(Player1, Player2)
	local Player1Character = Player1.Character
	local Player2Character = Player2.Character
	if Player1Character and Player2Character then
		local Player1RootPart = Player1Character:FindFirstChild("HumanoidRootPart")
		local Player2RootPart = Player2Character:FindFirstChild("HumanoidRootPart")
		if Player1RootPart and Player2RootPart then
			Player1RootPart.CFrame = Player2RootPart.CFrame * CFrame.new(0, 0, -4)
		end
	end
end