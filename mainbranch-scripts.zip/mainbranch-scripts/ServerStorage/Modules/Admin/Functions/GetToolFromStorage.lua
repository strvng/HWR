--[[
    GetToolFromStorage (ModuleScript)
    Path: ServerStorage → Modules → Admin → Functions
    Parent: Functions
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions")
local Autocomplete = require(Functions:WaitForChild("Autocomplete"))
local Storage = ServerStorage:WaitForChild("Storage")

local StorageFolders = {
	Storage:WaitForChild("Tools", 5),
	Storage:WaitForChild("VipItems", 5),
	Storage:WaitForChild("StarterPack", 5)
}

return function(Name)
	for _, v in pairs(StorageFolders) do
		if v then
			for _, Tool in pairs(v:GetChildren()) do
				if Autocomplete(string.lower(Name), string.lower(Tool.Name)) then
					return Tool
				end
			end
		end
	end
end