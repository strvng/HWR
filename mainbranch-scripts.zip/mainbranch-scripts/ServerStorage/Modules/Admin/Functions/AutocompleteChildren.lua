--[[
    AutocompleteChildren (ModuleScript)
    Path: ServerStorage → Modules → Admin → Functions
    Parent: Functions
    Exported: 2026-09-21 11:23:25
]]
local ServerStorage = game:GetService("ServerStorage")

local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions") 

local Autocomplete = require(Functions:WaitForChild("Autocomplete"))

return function(Parent, Name)
	for _, v in pairs(Parent:GetChildren()) do
		if Autocomplete(string.lower(Name), string.lower(v.Name)) then
			return v
		end
	end
end