--[[
    CommandHelper (ModuleScript)
    Path: ServerStorage → Modules → Admin
    Parent: Admin
    Exported: 2026-09-21 11:23:25
]]

local ServerStorage = game:GetService("ServerStorage")
local Modules = ServerStorage:WaitForChild("Modules")
local Admin = Modules:WaitForChild("Admin")
local Functions = Admin:WaitForChild("Functions")
local Commands = Admin:WaitForChild("Commands")

local GetPlayer = require(Functions:WaitForChild("GetPlayer"))
local Autocomplete = require(Functions:WaitForChild("Autocomplete"))
local GetToolFromStorage = require(Functions:WaitForChild("GetToolFromStorage"))
local AutocompleteChildren = require(Functions:WaitForChild("AutocompleteChildren"))
local Teleport = require(Functions:WaitForChild("Teleport"))
local AutocompletePlayers = require(Functions:WaitForChild("AutocompletePlayers"))
local Config = require(Admin:WaitForChild("Config"))

local CommandHelper = {}

CommandHelper.Util = {
	GetPlayer = GetPlayer,
	Autocomplete = Autocomplete,
	GetToolFromStorage = GetToolFromStorage,
	AutocompleteChildren = AutocompleteChildren,
	AutocompletePlayers = AutocompletePlayers,
	Teleport = Teleport
}

function CommandHelper.GetAvailableCommands(Level)
	local Available = {}
	
	for _, v in pairs(Commands:GetChildren()) do
		local FolderLevel = v:GetAttribute("Level")
		if FolderLevel and FolderLevel <= Level then
			for _, v in pairs(v:GetChildren()) do
				Available[v.Name] = require(v)
			end
		end
	end
	
	return Available
end

function CommandHelper.IsUserStaff(UserId)
	for _, v in pairs(Config.Ranks) do
		local Users = v.Users
		if Users and table.find(Users, UserId) then
			return true
		end
	end
end

function CommandHelper.GetLevel(Player)
	for _, v in pairs(Config.Ranks) do
		local Users = v.Users
		if Users and table.find(Users, Player.UserId) then
			return v.Level
		end
	end
end

return CommandHelper