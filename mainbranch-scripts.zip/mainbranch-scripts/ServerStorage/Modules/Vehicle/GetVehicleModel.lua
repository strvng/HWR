--[[
    GetVehicleModel (ModuleScript)
    Path: ServerStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:28
]]

local ServerStorage = game:GetService("ServerStorage")

local Storage = ServerStorage:WaitForChild("Storage")
local Regen = Storage:WaitForChild("Regen")
local Vehicles = Regen:WaitForChild("Vehicles")

return function(Name)
	return Vehicles:FindFirstChild(Name)
end