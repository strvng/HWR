--[[
    Vehicle (ModuleScript)
    Path: ServerStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local ReplicatedModules = ReplicatedStorage:WaitForChild("Modules")
local Modules = ServerStorage:WaitForChild("Modules")
local General = Modules:WaitForChild("General")
local RegenFolder = Modules:WaitForChild("Regen")
local VehicleFolder = Modules:WaitForChild("Vehicle")
local Utilities = ReplicatedModules:WaitForChild("Utilities")
local Gamepass = Modules:WaitForChild("Gamepass")

local Dictionaries = require(General:WaitForChild("Dictionaries"))
local VehiclesToCheck = require(RegenFolder:WaitForChild("VehiclesToCheck"))
local Destroyed = require(Utilities:WaitForChild("Destroyed"))
local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local Settings = require(Modules:WaitForChild("Settings"))
local SetupSeats = require(VehicleFolder:WaitForChild("SetupSeats"))
local Marketplace = require(Gamepass:WaitForChild("Marketplace"))

local DebrisFolder = workspace:WaitForChild("Debris")
local VehicleFolder = DebrisFolder:WaitForChild("Vehicles")

local Vehicle = {}
Vehicle.__index = Vehicle

function Vehicle.new(Model, RegenButton)
	local self = setmetatable({}, Vehicle)
	
	self.Vehicle = Model
	self.Regen = RegenButton
	self.Occupant = nil
	self.FirstSeat = true
	
	Destroyed(Model, function()
		self:Destroy()
	end)
	
	local Seat = Model:FindFirstChild("Seat")
	if Seat then
		local Joints = Seat:GetJoints()
		
		SetupSeats(self, Seat)
		
		for i, v in pairs(Joints) do
			Destroyed(v, function()
				task.wait(Settings.Vehicles.CrashRemovalTime)
				
				self:Destroy()
			end)
		end
	end
	
	return self
end

function Vehicle.GetColorParts(Model)
	local Parts = {}
	
	for _, v in pairs(Model:GetDescendants()) do
		if v:HasTag("Color") then
			table.insert(Parts, v)
		end
	end
	
	return Parts
end

function Vehicle.CanPilotVehicle(Model, Player)
	if Model then
		if not Model:GetAttribute("VipVehicle") or Model:GetAttribute("VipVehicle") and Marketplace:UserOwnsGamepass(Player, Settings.Vip.VIPGamepassId) then
			return true
		end
	end
end

function Vehicle:PlayerSeated(Player)
	local Model = self.Vehicle
	local Regen = self.Regen
	local Parent = VehicleFolder
	
	if not Vehicle.CanPilotVehicle(Model, Player) then
		return
	end
	
	ReceiveIncoming:FireAllClients("StopControlling", Player, Model)
	ReceiveIncoming:FireClient(Player, "SetVehicle", Model)
	
	if self.FirstSeat then
		VehiclesToCheck:AddToList(Model, function()
			local New = Regen:NewBackup()
			self.Regen.Regenerated(nil, New)
		end)
		
		self.FirstSeat = false
	end
	
	for i, v in pairs(Model:GetDescendants()) do
		if v:IsA("BasePart") then
			v:SetNetworkOwner(Player)
		end
	end
	
	Model.Parent = VehicleFolder
end

function Vehicle:PlayerUnseated(Player)
	local Model = self.Vehicle
	
	ReceiveIncoming:FireClient(Player, "SetVehicle", nil)
	ReceiveIncoming:FireAllClients("StopControlling", Player, Model)
end

function Vehicle:Destroy()
	local Model = self.Vehicle
	
	if Model then
		Model:Destroy()
	end
end

function Vehicle:SetColor(Color)
	local Model = self.Vehicle
	if Model then
		local Parts = Vehicle.GetColorParts(Model)
		
		for _, v in pairs(Parts) do
			v.Color = Color
		end
	end
end

function Vehicle:MoveTo(CFramePosition)
	local Model = self.Vehicle
	if Model then
		Model:PivotTo(CFramePosition)
	end
end

return Vehicle