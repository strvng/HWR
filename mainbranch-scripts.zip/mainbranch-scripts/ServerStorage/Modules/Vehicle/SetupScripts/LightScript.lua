--[[
    LightScript (ModuleScript)
    Path: ServerStorage → Modules → Vehicle → SetupScripts
    Parent: SetupScripts
    Exported: 2026-09-21 11:23:28
]]

local Time = 0.1

return function(Light)
	local function Main()
		Light.Reflectance = 1
		task.wait(0.1)
		Light.Reflectance = 0
		task.wait(5)
		Main()
	end
	
	Main()
end