--[[
    VehicleRegistry (ModuleScript)
    Path: ServerStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:28
]]

local VehicleRegistry = {
	Vehicles = {}
}

function VehicleRegistry:Set(Player, Vehicle)
	self.Vehicles[Player] = Vehicle
end

function VehicleRegistry:Get(Player)
	return self.Vehicles[Player]
end

return VehicleRegistry