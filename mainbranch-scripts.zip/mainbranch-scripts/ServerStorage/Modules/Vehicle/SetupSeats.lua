--[[
    SetupSeats (ModuleScript)
    Path: ServerStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:28
]]

local Players = game:GetService("Players")

return function(Module, Seat)
	local Occupant
	
	Seat:GetPropertyChangedSignal("Occupant"):Connect(function()
		local Occupant = Seat.Occupant
		if Occupant then
			local Player = Players:GetPlayerFromCharacter(Occupant.Parent)
			if Player then
				Module:PlayerSeated(Player)
				Module.Occupant = Player
			end
		else
			local OldOccupant = Module.Occupant
			
			if OldOccupant then
				Module:PlayerUnseated(OldOccupant)
			end
			
			Module.Occupant = nil
		end
	end)
end