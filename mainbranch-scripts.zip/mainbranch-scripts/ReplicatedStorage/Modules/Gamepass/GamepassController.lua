--[[
    GamepassController (ModuleScript)
    Path: ReplicatedStorage → Modules → Gamepass
    Parent: Gamepass
    Exported: 2026-09-21 11:23:24
]]

local MarketplaceService = game:GetService("MarketplaceService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Utilities = Modules:WaitForChild("Utilities")

local Signal = require(Utilities:WaitForChild("Signal"))

local Player = Players.LocalPlayer

local GamepassHandler = {
	Cache = {},
	GamepassPurchased = Signal.new()
}

function GamepassHandler:IsGamepassOwned(Id)
	local Cached = table.find(self.Cache, Id)
	
	if Cached then
		return true
	else
		local success, result = pcall(function()
			return MarketplaceService:UserOwnsGamePassAsync(Player.UserId, Id)
		end)
		
		if success and result then
			return result
		end
	end
end

function GamepassHandler:SetGamepassOwned(Id)
	table.insert(self.Cache, Id)
	
	GamepassHandler.GamepassPurchased:Fire(Id)
end

return GamepassHandler