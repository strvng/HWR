--[[
    Gamepasses (ModuleScript)
    Path: ReplicatedStorage → Modules → Gamepass
    Parent: Gamepass
    Exported: 2026-09-21 11:23:24
]]
return {
	{
		Name = "Heli-Wars VIP",
		Price = 500,
		ImageId = "rbxassetid://6573756471",
		Id = 16210289,
		LayoutOrder = 1,
	},
	{
		Name = "Double XP",
		Price = 300,
		ImageId = "rbxassetid://8613660667",
		Id = 25244382,
		LayoutOrder = 2,
	},
	{
		Name = "Sort Inventory",
		Price = 200,
		ImageId = "rbxassetid://8613678054",
		Id = 25272794,
		LayoutOrder = 3,
	},
	{
		Name = "5k XP",
		Price = 250,
		ImageId = "https://www.roblox.com/thumbs/asset.ashx?assetid=8613809905&x=100&y=100&format=png",
		Id = 1234009423,
		LayoutOrder = 5,
		IsDevProduct = true,
	},
	{
		Name = "2.5k XP",
		Price = 125,
		ImageId = "https://www.roblox.com/thumbs/asset.ashx?assetid=8613808403&x=100&y=100&format=png",
		Id = 1234009451,
		LayoutOrder = 6,
		IsDevProduct = true,
	},
	{
		Name = "10k XP",
		Price = 500,
		ImageId = "https://www.roblox.com/thumbs/asset.ashx?assetid=8613803711&x=100&y=100&format=png",
		Id = 1234009487,
		LayoutOrder = 7,
		IsDevProduct = true,
	}
}