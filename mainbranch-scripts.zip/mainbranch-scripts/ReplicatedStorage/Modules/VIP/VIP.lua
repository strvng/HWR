--[[
    VIP (ModuleScript)
    Path: ReplicatedStorage → Modules → VIP
    Parent: VIP
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local MarketplaceService = game:GetService("MarketplaceService")
local StarterGui = game:GetService("StarterGui")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local SettingsFolder = Modules:WaitForChild("Settings")
local VIPFolder = Modules:WaitForChild("VIP")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local GeneralFolder = VIPFolder:WaitForChild("General")

local VipSettings = require(SettingsFolder:WaitForChild("Vip"))
local PromptPurchase = require(VIPFolder:WaitForChild("PromptPurchase"))
--local GetDoors = require(GeneralFolder:WaitForChild("GetDoors"))
--local GetTeleporters = require(GeneralFolder:WaitForChild("GetTeleporters"))
local SetupTeleporter = require(GeneralFolder:WaitForChild("SetupTeleporter"))

local Player = Players.LocalPlayer

local VIP = {
	Enabled = false,
}

local TeleportConnections = {}

local function DisconnectTeleporters()
	for _, v in pairs(TeleportConnections) do
		for _, j in pairs(v) do
			j:Disconnect()
			j = nil
		end
	end
	
	table.clear(TeleportConnections)
end

local function HandleDoors(Doors)
	for _, v in pairs(Doors) do
		v.CanCollide = false
	end
end

local function HandleTeleporters(Teleporters)
	DisconnectTeleporters()
	
	local AllConnections = {}
	for _, v in pairs(Teleporters) do
		local Connections = SetupTeleporter(v, VIP)
		
		table.insert(AllConnections, Connections)
	end
	
	TeleportConnections = AllConnections
end

function VIP:SetDoors(Doors)
	self.Doors = Doors
	
	if self.Enabled then
		HandleDoors(Doors)
	end
end

function VIP:SetTeleporters(Teleporters)
	self.Teleporters = Teleporters
	
	HandleTeleporters(Teleporters)
end

function VIP:Enable()
	local Doors = self.Doors
	local Teleporters = self.Teleporters
	self.Enabled = true
	
	if Doors then
		HandleDoors(Doors)
	end
	
	if Teleporters then
		self:SetTeleporters(Teleporters)
	end
end

function VIP:Disable()
	self.Enabled = false
	
	table.clear(self.TouchConnections)
end

VIP.PromptPurchase = PromptPurchase

return VIP