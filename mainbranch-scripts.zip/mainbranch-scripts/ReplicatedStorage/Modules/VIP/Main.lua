--[[
    Main (ModuleScript)
    Path: ReplicatedStorage → Modules → VIP
    Parent: VIP
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local SettingsFolder = Modules:WaitForChild("Settings")
local VIPFolder = Modules:WaitForChild("VIP")
local GamepassFolder = Modules:WaitForChild("Gamepass")
--local GeneralFolder = VIPFolder:WaitForChild("General")

local VipSettings = require(SettingsFolder:WaitForChild("Vip"))
--local GetDoors = require(GeneralFolder:WaitForChild("GetDoors"))
--local GetTeleporters = require(GeneralFolder:WaitForChild("GetTeleporters"))
--local SetupTeleporter = require(GeneralFolder:WaitForChild("SetupTeleporter"))
local GamepassController = require(GamepassFolder:WaitForChild("GamepassController"))
local VIP = require(VIPFolder:WaitForChild("VIP"))

local Player = Players.LocalPlayer

--for _, v in pairs(GetTeleporters()) do
--	SetupTeleporter(v, VIP)
--end

GamepassController.GamepassPurchased:Connect(function(Id)
	if Id == VipSettings.VIPGamepassID then
		VIP:Enable()
	end
end)

local Character = Player.Character or Player.CharacterAdded:Wait()

local IsVip = GamepassController:IsGamepassOwned(VipSettings.VIPGamepassID)
if IsVip then
	VIP:Enable()
end

return nil