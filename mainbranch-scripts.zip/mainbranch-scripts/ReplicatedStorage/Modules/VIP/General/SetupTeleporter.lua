--[[
    SetupTeleporter (ModuleScript)
    Path: ReplicatedStorage → Modules → VIP → General
    Parent: General
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local SettingsFolder = Modules:WaitForChild("Settings")
local VIPFolder = Modules:WaitForChild("VIP")
local VIPGeneral = VIPFolder:WaitForChild("General")

local Player = Players.LocalPlayer

local GetPlayerFromTouch = require(VIPGeneral:WaitForChild("GetPlayerFromTouch"))
local VipSettings = require(SettingsFolder:WaitForChild("Vip"))
local TeleportTo = require(VIPGeneral:WaitForChild("TeleportTo"))

local LastTeleport = tick()
local LastPrompt = tick()

local function CanTeleport()
	if tick() - LastTeleport >= VipSettings.TeleportDebounceTime then
		LastTeleport = tick()
		
		return true
	end
end

local function CanPrompt()
	if tick() - LastPrompt >= VipSettings.PromptDebounceTime then
		LastPrompt = tick()
		
		return true
	end
end

local function CreateTouchFunction(ToPart, VipModule)
	return function(Hit)
		local HitPlayer = GetPlayerFromTouch(Hit)
		if HitPlayer == Player then
			if VipModule.Enabled then
				if CanTeleport() then
					TeleportTo(ToPart)
				end
			else
				if CanPrompt() then
					VipModule:PromptPurchase()
				end
			end
		end
	end
end

return function(Teleporter, VipModule)
	local First = Teleporter:WaitForChild("First")
	local Second = Teleporter:WaitForChild("Second")
	local Connections = {}
	
	if First and Second then
		local FirstTouched = First.Touched:Connect(CreateTouchFunction(Second, VipModule))
		local SecondTouched = Second.Touched:Connect(CreateTouchFunction(First, VipModule))
		
		Connections = {
			FirstTouched,
			SecondTouched
		}
	end
	
	return Connections
end