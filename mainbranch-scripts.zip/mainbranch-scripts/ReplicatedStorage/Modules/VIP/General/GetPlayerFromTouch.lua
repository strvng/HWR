--[[
    GetPlayerFromTouch (ModuleScript)
    Path: ReplicatedStorage → Modules → VIP → General
    Parent: General
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

return function(Hit)
	local Character = Hit.Parent
	if Character then
		return Players:GetPlayerFromCharacter(Character)
	end
end