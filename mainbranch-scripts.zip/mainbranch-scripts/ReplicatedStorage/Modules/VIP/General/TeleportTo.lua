--[[
    TeleportTo (ModuleScript)
    Path: ReplicatedStorage → Modules → VIP → General
    Parent: General
    Exported: 2026-09-21 11:23:24
]]
local Players = game:GetService("Players")

local Player = Players.LocalPlayer

return function(Part)
	local Character = Player.Character
	if Character then
		local HumanoidRootPart = Character:FindFirstChild("HumanoidRootPart")
		if HumanoidRootPart then
			HumanoidRootPart.CFrame = Part.CFrame * CFrame.new(0, (HumanoidRootPart.Size.Y + (Part.Size.Y / 2)) + 2, 0)
		end
	end
end