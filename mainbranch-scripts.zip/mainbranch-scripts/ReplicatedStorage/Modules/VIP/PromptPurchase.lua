--[[
    PromptPurchase (ModuleScript)
    Path: ReplicatedStorage → Modules → VIP
    Parent: VIP
    Exported: 2026-09-21 11:23:24
]]

local MarketplaceService = game:GetService("MarketplaceService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local StarterGui = game:GetService("StarterGui")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")

local VipSettings = require(Settings:WaitForChild("Vip"))

local PromptPurchase = Instance.new("BindableFunction")
local Player = Players.LocalPlayer

PromptPurchase.OnInvoke = function(Option)
	if Option == "Yes" then
		MarketplaceService:PromptGamePassPurchase(Player, VipSettings.VIPGamepassID)
	end
end

return function()
	StarterGui:SetCore("SendNotification", {
		Title = "Notification",
		Text = "You don't own the VIP gamepass. Would you like to purchase it now?",
		Duration = 5,
		Button1 = "Yes",
		Button2 = "No",
		Icon = "rbxassetid://6573756471",
		Callback = PromptPurchase
	})
end