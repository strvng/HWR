--[[
    new system layout (Script)
    Path: ReplicatedStorage → Modules → Customization → future/old
    Parent: future/old
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

--[[

Trails:

Data:
{
	Name
	Unlock Requirements (any number of args)
}

LockedButton:
	IsVisible: if its a level trail, true, else false
	Refresh: runs IsUnlocked on the trail set in the constructor and refreshes the text
	what is the text?
	if it's a level then show the level, otherwise just hide it


do we have separate modules for each class?
yes in order for maximum customization

Customization:
Name
Type
IsUnlocked: method
Display: texture


]]