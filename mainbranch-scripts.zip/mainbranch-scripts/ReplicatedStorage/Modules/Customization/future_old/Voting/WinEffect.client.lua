--[[
    WinEffect (LocalScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Voting
    Parent: Voting
    Properties:
        Disabled: true
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Frame = script.Parent
local ContentFrame = Frame:WaitForChild("Content")

local Forest = ContentFrame:WaitForChild("Forest")
local Desert = ContentFrame:WaitForChild("Desert")
local Winter = ContentFrame:WaitForChild("Winter")

local ListLayout = ContentFrame:WaitForChild("UIListLayout")

local function GetButtons()
	local Buttons = {}
	
	for _, v in pairs(ContentFrame:GetChildren()) do
		if v:IsA("TextButton") then
			table.insert(Buttons, v)
		end
	end
	
	return Buttons
end

local function ConvertToScale(Parent)
	local Positions = {}
	for _, v in pairs(GetButtons()) do
		local ParentAbsolutePosition = Parent.AbsolutePosition
		local AbsolutePosition = v.AbsolutePosition
		local AbsoluteSize = v.AbsoluteSize
		local ParentAbsoluteSize = Parent.AbsoluteSize
		local Anchor = v.AnchorPoint
		
		local NormalizedPosition = AbsolutePosition - ParentAbsolutePosition
		
		local Convert = UDim2.fromScale(
			((NormalizedPosition.X + (AbsoluteSize.X * Anchor.X)) / ParentAbsoluteSize.X),
			((NormalizedPosition.Y + (AbsoluteSize.Y * Anchor.Y)) / ParentAbsoluteSize.Y)
		)
		
		Positions[v] = Convert
		
	end
	
	ListLayout.Parent = nil
	
	for _, v in pairs(GetButtons()) do
		local Position = Positions[v]
		if Position then
			v.Position = Position
		end
	end
end

local function PlayWinEffect(Map)
	-- take absolute positions, convert to scale, parent list layout to nil, set positions, tween outer frames to inner frame, scale inside frame
	ConvertToScale(ContentFrame)
	Desert.ZIndex = 2
	Forest:TweenPosition(
		Desert.Position,
		Enum.EasingDirection.InOut,
		Enum.EasingStyle.Quad,
		0.5
	)
	Winter:TweenPosition(
		Desert.Position,
		Enum.EasingDirection.InOut,
		Enum.EasingStyle.Quad,
		0.5
	)
	task.wait(0.5)
	Desert.Title.Text.Text = Map
	Desert:TweenSize(
		UDim2.fromScale(0.428, 0.937),
		Enum.EasingDirection.Out,
		Enum.EasingStyle.Bounce,
		0.5
	)
	-- todo make less ghetto
end

--task.wait(3)
--PlayWinEffect("Winter")