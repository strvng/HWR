--[[
    BaseCustomization(old) (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old
    Parent: future/old
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local CustomizationFolder = Modules:WaitForChild("Customization")
--local ContentFolder = CustomizationFolder:WaitForChild("Content")

local BaseCustomization = {}
BaseCustomization.__index = BaseCustomization

local ViewportPrefab = script:WaitForChild("Viewport")
local PartPrefab = script:WaitForChild("Part")

BaseCustomization.PartPrefab = PartPrefab
BaseCustomization.ViewportPrefab = ViewportPrefab
BaseCustomization.HAT_DIRECTION = Vector3.new(-1, 0.6, -2)
BaseCustomization.CHUTE_DIRECTION = Vector3.new(-0.625, 0.6, -1)

function BaseCustomization.new(Name, Level, ContentFolder)
	local self = setmetatable({}, BaseCustomization)
	
	self.Name = Name
	self.Level = Level
	self.ContentFolder = ContentFolder
	
	return self
end

function BaseCustomization:Apply()
	
end

function BaseCustomization:Display()
	-- override
end

function BaseCustomization:IsVisible()
	return true
end

--function BaseCustomization.GetContentFolder(Category, Name)
--	local CategoryFolder = ContentFolder:FindFirstChild(Category)
--	if CategoryFolder then
--		local Content = CategoryFolder:FindFirstChild(Name)
--		if Content then
--			return Content
--		end
--	end
--end

function BaseCustomization.CreateViewport(Texture)
	local NewPrefab = BaseCustomization.ViewportPrefab:Clone()
	
	return NewPrefab
end

function BaseCustomization.CreatePart()
	local NewPrefab = PartPrefab:Clone()
	
	return NewPrefab
end

function BaseCustomization.HatRender(Texture, Hat, Zoom)
	local Viewport = BaseCustomization.CreateViewport()
	local NewHat = Hat:Clone()
	Viewport.Parent = Texture
	
	BaseCustomization.DistanceRender(Viewport, NewHat, BaseCustomization.HAT_DIRECTION * Zoom)
end

function BaseCustomization.ChuteRender(Texture, Chute, Zoom)
	local Viewport = BaseCustomization.CreateViewport()
	local NewChute = Chute:Clone()
	Viewport.Parent = Texture
	
	BaseCustomization.DistanceRender(Viewport, NewChute, BaseCustomization.CHUTE_DIRECTION * Zoom)
end

function BaseCustomization.DistanceRender(Viewport, Object, Offset)
	local Camera = Instance.new("Camera")
	Camera.Parent = Viewport
	
	Object.CFrame = CFrame.new()
	Object.Parent = Viewport
	
	Camera.CFrame = CFrame.new(Offset, Object.Position)
	Viewport.CurrentCamera = Camera
end

function BaseCustomization.NewTexturePart()
	local Part = Instance.new("Part")
	Part.TopSurface = Enum.SurfaceType.Smooth
	Part.BottomSurface = Enum.SurfaceType.Smooth
	Part.Size = Vector3.new(10, 10, 1)
	Part.Anchored = true
	
	return Part
end

function BaseCustomization.TextureRender(Texture, Part, Zoom)
	local Viewport = BaseCustomization.CreateViewport()
	
	Part.Parent = Viewport
	Viewport.Parent = Texture
	
	local Camera = Instance.new("Camera")
	Camera.Parent = Viewport
	
	Part.CFrame = CFrame.new()
	
	Camera.CFrame = CFrame.new(Vector3.new(0, 0, Zoom), Part.Position)
	Viewport.CurrentCamera = Camera
end

return BaseCustomization