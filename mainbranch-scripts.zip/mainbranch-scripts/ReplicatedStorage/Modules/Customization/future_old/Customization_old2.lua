--[[
    Customization(old2) (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old
    Parent: future/old
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local CustomizationFolder = Modules:WaitForChild("Customization")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local Data = Modules:WaitForChild("Data")
local SettingsFolder = Modules:WaitForChild("Settings")
--local CustomizationGeneral = General:WaitForChild("Customization")
--local CreateFolder = CustomizationGeneral:WaitForChild("Create")

local CustomizationController = require(CustomizationFolder:WaitForChild("CustomizationController"))
local LevelController = require(CustomizationFolder:WaitForChild("LevelController"))
local DataController = require(Data:WaitForChild("DataController"))
local Selection = require(script:WaitForChild("Selection"))
local LockedButton = require(script:WaitForChild("LockedButton"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
--local BaseMenu = require(Menus:WaitForChild("Menu"))
local AnimatedMenu = require(Menus:WaitForChild("AnimatedMenu"))
local UI = require(SettingsFolder:WaitForChild("UI"))
--local TrailList = require(SettingsFolder:WaitForChild("Trails"))

local Player = Players.LocalPlayer

local CustomizationFrame = MenuUtil:GetFrame("Customization")
local ContentFrame = CustomizationFrame:WaitForChild("Content")
local ProfileIcon = ContentFrame:WaitForChild("ProfileIcon")
local ProfileName = ProfileIcon:WaitForChild("Name")
local LevelLabel = ContentFrame:WaitForChild("Level")
local XPLabel = ContentFrame:WaitForChild("XP")
local PercentLabel = ContentFrame:WaitForChild("Percentage")
local PercentContainer = ContentFrame:WaitForChild("Bar")
local PercentProgress = PercentContainer:WaitForChild("Progress")
local Customization = ContentFrame:WaitForChild("Customization")
local Pages = Customization:WaitForChild("Pages")
local Tabs = Customization:WaitForChild("Tabs")
local Items = Pages:WaitForChild("Items")

local Customization = setmetatable({}, AnimatedMenu)
Customization.__index = Customization

function Customization.new(Frame)
	local self = setmetatable(AnimatedMenu.new(Frame), Customization)
	
	self.CategoryButtons = {}
	self.LastCategory = ""
	self.LastButton = nil
	task.defer(self.LoadUser)
	
	DataController.XPChanged:Connect(function()
		self:RefreshLevel()
	end)
	
	DataController.LevelChanged:Connect(function()
		self:RefreshLevel()
		self:RefreshLocked()
	end)
	
	self:RefreshLevel()
	
	
	-- change this code
	-- just have a :Render() on the trail
	for CategoryName, CustomizationItems in pairs(CustomizationController.GetAllItems()) do
		local CurrentCustomization = DataController:GetCustomization(CategoryName)
		for ItemName, Data in pairs(CustomizationItems) do
			local NewButton = LockedButton.new(
				Data,
				CategoryName
			)
			NewButton:CreateRender()
			
			if ItemName == CurrentCustomization then
				Selection:Equip(NewButton, CategoryName, true)
			end
			
			if self.CategoryButtons[CategoryName] then
				table.insert(self.CategoryButtons[CategoryName], NewButton)
			else
				self.CategoryButtons[CategoryName] = {NewButton}
			end
		end
	end
	
	for _, v in pairs(Tabs:GetChildren()) do
		if v:IsA("TextButton") then
			v.Activated:Connect(function()
				if self.LastButton ~= v then
					self:DisplayCategory(v.Name)
				end
			end)
			
			v.MouseEnter:Connect(function()
				self.SetCategorySelected(v, true)
			end)
			
			v.MouseLeave:Connect(function()
				if v ~= self.LastButton then
					self.SetCategorySelected(v, false)
				end
			end)
		end
	end

	self:DisplayCategory(UI.Customization.DefaultCategory)
	--for Name, _ in pairs(TrailList) do
	--	local Button = TrailButton.new(Name)
	--	Button:SetParent(Scroll)

	--	local CreateFunction = CreateFolder:FindFirstChild(Name)
	--	if CreateFunction then
	--		require(CreateFunction)(Button.Texture)
	--	end

	--	if Button.Trail == DataController:GetTrail() then
	--		TrailController:Equip(Button)
	--	end

	--	table.insert(self.Buttons, Button)
	--end

	self:RefreshLocked()
	
	return self
end

function Customization:LoadUser()
	ProfileName.Text = Player.DisplayName
	ProfileIcon.Image = Players:GetUserThumbnailAsync(
		Player.UserId,
		Enum.ThumbnailType.HeadShot,
		Enum.ThumbnailSize.Size352x352
	)
end

function Customization:IsMaxLevel()
	return DataController:GetLevel() >= LevelController:GetMaxLevel()
end

function Customization:RefreshLevel()
	local Level = DataController:GetLevel()
	local XP = DataController:GetXP()
	local XPToLevel = LevelController:GetXPToLevel(DataController:GetLevel())
	
	local Percent = math.clamp(XP / XPToLevel, 0, 1)
	
	if self:IsMaxLevel() then
		Percent = 1
		XPLabel.Text = "MAX LVL"
	else
		XPLabel.Text = string.format("%s/%s", XP, XPToLevel)
	end
	
	LevelLabel.Text = string.format("LVL %s", Level)
	PercentLabel.Text = string.format("%s%%", math.floor(Percent * 100))
	PercentProgress.Size = UDim2.fromScale(Percent, 1)
end

--function Customization:IsTrailUnlocked(Name)
--	local TrailData = TrailList[Name]
--	if TrailData then
--		local Level = DataController:GetLevel()
		
--		return Level >= TrailData.Level
--	end
--end

function Customization:RefreshLocked()
	local Level = DataController:GetLevel()
	for Category, Buttons in pairs(self.CategoryButtons) do
		for _, Button in pairs(Buttons) do
			Button:SetLocked(Button.Level > Level)
		end
	end
end

function Customization.SetCategorySelected(Button, Selected)
	if Button then
		local Color = UI.Customization.CategoryUnselected
		
		if Selected then
			Color = UI.Customization.CategorySelected
		end
		
		Button.BackgroundColor3 = Color
		
		for _, v in pairs(Button:GetChildren()) do
			if v:IsA("Frame") and v.Name == "Color" then
				v.BackgroundColor3 = Color
			end
		end
	end
end

function Customization:DisplayCategory(Category)
	local CategoryButton = Tabs:FindFirstChild(Category)
	if CategoryButton then
		if self.LastButton then
			self.SetCategorySelected(self.LastButton, false)
		end
		
		self.SetCategorySelected(CategoryButton, true)
		
		Items.CanvasPosition = Vector2.zero
		
		local LastButtons = self.CategoryButtons[self.LastCategory]
		if LastButtons then
			for _, v in pairs(LastButtons) do
				v:SetParent(nil)
			end
		end
		
		local CurrentButtons = self.CategoryButtons[Category]
		if CurrentButtons then
			for _, v in pairs(CurrentButtons) do
				v:SetParent(Items)
			end
		end
		
		self.LastCategory = Category
		self.LastButton = CategoryButton
	end
end

local singleton

singleton = Customization.new(CustomizationFrame)

return singleton