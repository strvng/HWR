--[[
    LockedButton (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old)
    Parent: Customization(old)
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local General = MenuFolder:WaitForChild("General")
--local TrailsGeneral = General:WaitForChild("Trails")
--local CreateFolder = TrailsGeneral:WaitForChild("Create")
local Menus = MenuFolder:WaitForChild("Menus")
--local Trails = Menus:WaitForChild("Trails")
local SettingsFolder = Modules:WaitForChild("Settings")
local Customization = Modules:WaitForChild("Customization")
local CustomizationModule = Menus:WaitForChild("Customization")

local CustomizationController = require(Customization:WaitForChild("CustomizationController"))
local Selection = require(CustomizationModule:WaitForChild("Selection"))
--local TrailList = require(Customization:WaitForChild("Trails"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))

local LockedTemplate = MenuUtil:GetTemplate("LockedTemplate")

local LockedButton = {}
LockedButton.__index = LockedButton

function LockedButton.new(Item, Category, Level)
	local self = setmetatable({}, LockedButton)
	
	local NewTemplate = LockedTemplate:Clone()
	local Texture = NewTemplate:WaitForChild("Texture")
	local EquippedLabel = Texture:WaitForChild("Equipped")
	local LockedLabel = Texture:WaitForChild("Locked")
	local NameLabel = Texture:WaitForChild("Name")
	local LevelRequirement = Texture:WaitForChild("LevelRequirement")
	local UIStroke = Texture:WaitForChild("UIStroke")
	
	self.EquippedLabel = EquippedLabel
	self.LockedLabel = LockedLabel
	self.LevelRequirement = LevelRequirement
	self.NameLabel = NameLabel
	self.Texture = Texture
	self.UIStroke = UIStroke
	self.Button = NewTemplate
	self.Item = Item
	self.Category = Category
	self.Unlocked = false
	
	--local TrailData = GetTrailData(Trail)
	if Item and Level then
		self.Level = Level
		
		NewTemplate.LayoutOrder = Level
		NameLabel.Text = Item
		LevelRequirement.Text = string.format("Level %s", Level)
	end
	
	NewTemplate.Activated:Connect(function()
		if self.Unlocked then
			Selection:Equip(self, Category)
			--CustomizationController:Equip(self, Category)
		end
	end)
	
	return self
end

function LockedButton:SetLocked(Locked)
	if Locked then
		self.LockedLabel.Visible = true
		self.EquippedLabel.Visible = false
		self.LevelRequirement.Visible = true
		self.Unlocked = false
	else
		self.LevelRequirement.Visible = false
		self.LockedLabel.Visible = false
		self.Unlocked = true
	end
end

function LockedButton:SetEquipped(Equipped)
	if Equipped then
		self.EquippedLabel.Visible = true
		self.UIStroke.Color = Color3.fromRGB(255, 255, 255)
	else
		self.EquippedLabel.Visible = false
		self.UIStroke.Color = Color3.fromRGB(0, 0, 0)
	end
end

function LockedButton:CreateRender()
	local Content = CustomizationController.GetCustomization(self.Category, self.Item)
	if Content then
		Content.Viewport.Display(self.Texture)
	end
	--local CategoryFolder = CreateFolder:FindFirstChild(self.Category)
	--print(self.Category)
	--if CategoryFolder then
	--	local CreateFunction = CategoryFolder:FindFirstChild(self.Item)
	--	if CreateFunction then
	--		require(CreateFunction)(self.Texture)
	--	end
	--end
end

function LockedButton:SetParent(Parent)
	self.Button.Parent = Parent
end

return LockedButton