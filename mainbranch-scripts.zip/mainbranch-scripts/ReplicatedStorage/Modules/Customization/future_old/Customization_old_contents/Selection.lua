--[[
    Selection (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old)
    Parent: Customization(old)
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Data = Modules:WaitForChild("Data")

local DataController = require(Data:WaitForChild("DataController"))

local singleton

local Selection = {}
Selection.__index = Selection

function Selection.new()
	local self = setmetatable({}, Selection)
	
	self.Last = {}
	
	return self
end

function Selection:GetLastEquipped(Category)
	return self.Last[Category]
end

function Selection:SetEquipped(Button, Category)
	self.Last[Category] = Button
end

function Selection:Equip(Button, Category, InitialSet)
	local Equipped = self:GetLastEquipped(Category)
	if Equipped then
		if Equipped ~= Button then
			Equipped:SetEquipped(false)
		else
			return
		end
	end
	
	Button:SetEquipped(true)
	self:SetEquipped(Button, Category)
	if not InitialSet then
		DataController:SetCustomization(Category, Button.Item)
	end
	--DataController:SetTrail(Button.Item)
end

singleton = Selection.new()
return singleton