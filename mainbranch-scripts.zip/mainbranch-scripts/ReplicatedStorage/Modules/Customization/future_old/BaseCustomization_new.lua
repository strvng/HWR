--[[
    BaseCustomization(new) (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old
    Parent: future/old
    Exported: 2026-09-21 11:23:24
]]

local Customization = {}
Customization.__index = Customization

local ViewportPrefab = script:WaitForChild("Viewport")
local PartPrefab = script:WaitForChild("Part")

Customization.PartPrefab = PartPrefab
Customization.ViewportPrefab = ViewportPrefab
Customization.HAT_DIRECTION = Vector3.new(-1, 0.6, -2)
Customization.CHUTE_DIRECTION = Vector3.new(-0.625, 0.6, -1)

function Customization.new(Name, Level)
	local self = setmetatable({}, Customization)
	
	self.Name = Name
	self.Level = Level
	
	return self
end

function Customization:GetName()
	return self.Name
end

function Customization:Render()
	
end

function Customization:IsVisible()
	return true
end

function Customization:IsUnlocked()
	
end

function Customization.CreateViewport(Texture)
	local NewPrefab = Customization.ViewportPrefab:Clone()
	
	return NewPrefab
end

function Customization.CreatePart()
	local NewPrefab = PartPrefab:Clone()
	
	return NewPrefab
end

function Customization.HatRender(Texture, Hat, Zoom)
	local Viewport = Customization.CreateViewport()
	local NewHat = Hat:Clone()
	Viewport.Parent = Texture
	
	Customization.DistanceRender(Viewport, NewHat, Customization.HAT_DIRECTION * Zoom)
end

function Customization.ChuteRender(Texture, Chute, Zoom)
	local Viewport = Customization.CreateViewport()
	local NewChute = Chute:Clone()
	Viewport.Parent = Texture
	
	Customization.DistanceRender(Viewport, NewChute, Customization.CHUTE_DIRECTION * Zoom)
end

function Customization.DistanceRender(Viewport, Object, Offset)
	local Camera = Instance.new("Camera")
	Camera.Parent = Viewport
	
	Object.CFrame = CFrame.new()
	Object.Parent = Viewport
	
	Camera.CFrame = CFrame.new(Offset, Object.Position)
	Viewport.CurrentCamera = Camera
end

function Customization.NewTexturePart()
	local Part = Instance.new("Part")
	Part.TopSurface = Enum.SurfaceType.Smooth
	Part.BottomSurface = Enum.SurfaceType.Smooth
	Part.Size = Vector3.new(10, 10, 1)
	Part.Anchored = true
	
	return Part
end

function Customization.TextureRender(Texture, Part, Zoom)
	local Viewport = Customization.CreateViewport()
	
	Part.Parent = Viewport
	Viewport.Parent = Texture
	
	local Camera = Instance.new("Camera")
	Camera.Parent = Viewport
	
	Part.CFrame = CFrame.new()
	
	Camera.CFrame = CFrame.new(Vector3.new(0, 0, Zoom), Part.Position)
	Viewport.CurrentCamera = Camera
end

return Customization