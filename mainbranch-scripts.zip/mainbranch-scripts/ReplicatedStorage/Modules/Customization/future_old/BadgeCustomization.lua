--[[
    BadgeCustomization (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old
    Parent: future/old
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Data = Modules:WaitForChild("Data")

local DataController = require(Data:WaitForChild("DataController"))
local Customzation = require("./Customization")

local BadgeCustomization = {}
BadgeCustomization.__index = setmetatable(BadgeCustomization, Customzation)

function BadgeCustomization.new(Name, BadgeId)
	local self = setmetatable(Customzation.new(Name), BadgeCustomization)
	
	assert(BadgeId)
	
	self.BadgeId = BadgeId
	self.Type = "Badge"
	
	return self
end

function BadgeCustomization:IsUnlocked()
	
end

return BadgeCustomization