--[[
    Badge(old) (Script)
    Path: ReplicatedStorage → Modules → Customization → future/old
    Parent: future/old
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local Platform = script.Parent
local FormatText = "%s won DrewsomeB's \"The Caves of Heli-Wars\" award!"
local Debounce = {}

Platform.Touched:Connect(function(Hit)
	local Player = Players:GetPlayerFromCharacter(Hit.Parent)
	if Player and not Debounce[Player] then
		Debounce[Player] = true
		ReceiveIncoming:FireClient(Player, "SendMessage", "Default", {
			Icon = "rbxassetid://206410289",
			Title = "Badge Awarded",
			Text = string.format(FormatText, Player.Name),
			Duration = 5,
		})
	end
end)