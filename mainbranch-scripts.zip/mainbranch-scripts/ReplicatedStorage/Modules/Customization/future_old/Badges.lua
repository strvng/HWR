--[[
    Badges (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old
    Parent: future/old
    Exported: 2026-09-21 11:23:24
]]

local BadgeService = game:GetService("BadgeService")

local Badges = {
	BadgeIds = {
		AprilFools = 1553094315188753
	}
}

function Badges.GetAwardedBadges(UserId)
	
end

return Badges