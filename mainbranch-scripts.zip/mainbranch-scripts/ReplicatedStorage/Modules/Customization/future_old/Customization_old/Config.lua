--[[
    Config (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old)
    Parent: Customization(old)
    Exported: 2026-09-21 11:23:24
]]

return {
	XPToLevel = 10000,
	MaxLevel = 1000
}