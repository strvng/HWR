--[[
    CustomizationController (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old)
    Parent: Customization(old)
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local CustomizationFolder = Modules:WaitForChild("Customization")
--local ContentFolder = CustomizationFolder:WaitForChild("Content")
local CategoriesFolder = CustomizationFolder:WaitForChild("Categories")

local CustomizationController = {}
CustomizationController.__index = CustomizationController

function CustomizationController.GetCustomization(Category, Name)
	local CategoryFolder = CategoriesFolder:FindFirstChild(Category)
	if CategoryFolder then
		local Customization = CategoryFolder:FindFirstChild(Name)
		if Customization then
			return require(Customization)
		end
	end
end

function CustomizationController.GetAllItems()
	local Categories = {}
	
	for _, CategoryFolder in pairs(CategoriesFolder:GetChildren()) do
		Categories[CategoryFolder.Name] = {}
		
		for _, Button in pairs(CategoryFolder:GetChildren()) do
			if Button:IsA("ModuleScript") then
				Categories[CategoryFolder.Name][Button.Name] = require(Button)
			end
		end
	end
	
	return Categories
end

return CustomizationController