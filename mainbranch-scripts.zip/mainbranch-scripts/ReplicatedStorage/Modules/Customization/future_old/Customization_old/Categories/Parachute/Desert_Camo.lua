--[[
    Desert Camo (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Parachute
    Parent: Parachute
    Exported: 2026-09-21 11:23:24
]]

local Viewport = require(script:WaitForChild("Viewport"))

local Level = 15
local Name = script.Name

local Trail = {
	Data = {
		Level = Level,
		Name = Name
	},
	Viewport = Viewport,
}

return Trail