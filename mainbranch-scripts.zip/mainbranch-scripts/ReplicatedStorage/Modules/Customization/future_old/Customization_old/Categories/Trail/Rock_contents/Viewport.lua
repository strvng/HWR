--[[
    Viewport (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Trail → Rock
    Parent: Rock
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local BaseCustomization = require(Customization:WaitForChild("BaseCustomization"))

local Viewport = BaseCustomization.new()

function Viewport.Display(Texture)
	local Part = BaseCustomization.NewTexturePart()

	Part.Material = Enum.Material.Slate
	Part.BrickColor = BrickColor.new("Smoky grey")

	BaseCustomization.TextureRender(Texture, Part, 3)
end

return Viewport