--[[
    Application (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Trail → Classic
    Parent: Classic
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local ContentFolder = Module:WaitForChild("Content")
local Projectiles = Modules:WaitForChild("Projectiles")

local BaseTrail = require(Projectiles:WaitForChild("BaseTrail"))

local Application = BaseTrail.new()
local StudTexture = ContentFolder:WaitForChild("Studs")
local WeldTexture = ContentFolder:WaitForChild("Weld")

local function ApplyDefault(ProjectileModel)
	ProjectileModel.Material = Enum.Material.SmoothPlastic
end

Application:AddApplyCallback("Default", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ApplyDefault(ProjectileModel)
	end
end)

Application:AddHitCallback("Pistol", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ApplyDefault(ProjectileModel)
		BaseTrail.TrailHelper.ApplyTexture(ProjectileModel, WeldTexture)
	end
end)

Application:AddHitCallback("MultiRocket", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ApplyDefault(ProjectileModel)
		BaseTrail.TrailHelper.ApplyTexture(ProjectileModel, StudTexture)
	end
end)

Application:AddHitCallback("FastRocket", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ApplyDefault(ProjectileModel)
		BaseTrail.TrailHelper.ApplyTexture(ProjectileModel, StudTexture)
	end
end)

Application:AddHitCallback("PlaneMissile", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ApplyDefault(ProjectileModel)
		BaseTrail.TrailHelper.ApplyTexture(ProjectileModel, StudTexture)
	end
end)

return Application