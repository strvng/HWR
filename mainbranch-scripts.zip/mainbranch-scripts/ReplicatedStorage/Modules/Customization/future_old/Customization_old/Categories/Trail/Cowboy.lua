--[[
    Cowboy (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Trail
    Parent: Trail
    Exported: 2026-09-21 11:23:24
]]

local Viewport = require(script:WaitForChild("Viewport"))
local Application = require(script:WaitForChild("Application"))

local Level = 100
local Name = script.Name

local Trail = {
	Data = {
		Level = Level,
		Name = Name
	},
	Viewport = Viewport,
	Application = Application,
}

return Trail