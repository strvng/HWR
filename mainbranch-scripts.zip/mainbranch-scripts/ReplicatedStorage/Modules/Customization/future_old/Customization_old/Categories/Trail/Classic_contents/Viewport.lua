--[[
    Viewport (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Trail → Classic
    Parent: Classic
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")
local ContentFolder = Module:WaitForChild("Content")

local BaseCustomization = require(Customization:WaitForChild("BaseCustomization"))

local Viewport = BaseCustomization.new()

local ClassicTexture = ContentFolder:WaitForChild("Studs")

function Viewport.Display(Texture)
	local Part = BaseCustomization.NewTexturePart()
	
	local NewTexture = ClassicTexture:Clone()
	NewTexture.Face = Enum.NormalId.Back
	NewTexture.StudsPerTileV = 3.8
	NewTexture.Parent = Part
	
	Texture.BackgroundColor3 = Color3.fromRGB(57, 59, 61)
	Part.Material = Enum.Material.SmoothPlastic
	Part.BrickColor = BrickColor.new("Bright yellow")
	
	BaseCustomization.TextureRender(Texture, Part, 3)
end

return Viewport