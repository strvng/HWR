--[[
    Viewport (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Trail → Camo
    Parent: Camo
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")
local ContentFolder = Module:WaitForChild("Content")

local BaseCustomization = require(Customization:WaitForChild("BaseCustomization"))

local Viewport = BaseCustomization.new()

function Viewport.Display(Texture)
	Texture.Image = "rbxassetid://105985413"
end

return Viewport