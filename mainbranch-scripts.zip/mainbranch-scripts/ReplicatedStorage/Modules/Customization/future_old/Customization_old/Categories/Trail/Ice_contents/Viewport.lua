--[[
    Viewport (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Trail → Ice
    Parent: Ice
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")
local ContentFolder = Module:WaitForChild("Content")

local BaseCustomization = require(Customization:WaitForChild("BaseCustomization"))

local Viewport = BaseCustomization.new()

local Gradient = ContentFolder:WaitForChild("UIGradient")

function Viewport.Display(Texture)
	local NewGradient = Gradient:Clone()

	Texture.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	NewGradient.Parent = Texture
end

return Viewport