--[[
    Application (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old) → Categories → Trail → Sombrero
    Parent: Sombrero
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")
local ContentFolder = Module:WaitForChild("Content")
local Projectiles = Modules:WaitForChild("Projectiles")

local BaseTrail = require(Projectiles:WaitForChild("BaseTrail"))

local Application = BaseTrail.new()

Application:AddApplyCallback("Default", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		local SombreroHat = ContentFolder:WaitForChild("Sombrero")
		
		local Hat = SombreroHat:Clone()
		
		BaseTrail.TrailHelper.ApplyHat(ProjectileModel, Hat, 0.2)
	end
end)

return Application