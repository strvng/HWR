--[[
    LevelController (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → future/old → Customization(old)
    Parent: Customization(old)
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local Config = require(Customization:WaitForChild("Config"))

local LevelData = {}

local LevelController = {}
LevelController.__index = LevelController

function LevelController.new()
	local self = setmetatable({}, LevelController)
	
	return self
end

function LevelController:GetXPToLevel(Level)
	if Level == 999 then
		return 1_000_000
	end
	
	return Config.XPToLevel
end

function LevelController:GetLevelData()
	return LevelData
end

function LevelController:GetMaxLevel()
	return Config.MaxLevel
end

return LevelController