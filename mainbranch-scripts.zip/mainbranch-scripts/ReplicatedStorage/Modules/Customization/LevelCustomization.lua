--[[
    LevelCustomization (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization
    Parent: Customization
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Data = Modules:WaitForChild("Data")

local Customization = require("./Customization")
local GetPlayerLevel = require(Data:WaitForChild("GetPlayerLevel"))

local LevelCustomization = {}
LevelCustomization.__index = setmetatable(LevelCustomization, Customization)

function LevelCustomization.FromScriptAttributes(Script)
	return LevelCustomization.new(
		Script:GetAttribute("Name"),
		Script:GetAttribute("Level")
	)
end

function LevelCustomization.new(Name, Level)
	local self = setmetatable(Customization.new(Name), LevelCustomization)
	
	assert(Level)
	
	self.Level = Level
	self.Type = "Level"
	
	return self
end

function LevelCustomization:IsUnlocked(Player)
	return GetPlayerLevel(Player) >= self.Level
end

return LevelCustomization