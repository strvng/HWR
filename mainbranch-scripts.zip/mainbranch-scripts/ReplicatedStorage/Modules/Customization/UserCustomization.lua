--[[
    UserCustomization (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization
    Parent: Customization
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Data = Modules:WaitForChild("Data")

local DefaultUsers = require("./DefaultUsers")
local Customization = require("./Customization")

local UserCustomization = {}
UserCustomization.__index = setmetatable(UserCustomization, Customization)
UserCustomization.DefaultUsers = DefaultUsers

function UserCustomization.FromScriptAttributes(Script)
	return UserCustomization.new(
		Script:GetAttribute("Name")
	)
end

function UserCustomization.new(Name)
	local self = setmetatable(Customization.new(Name), UserCustomization)
	
	self.Type = "User"
	self.AllowedUsers = {}
	
	return self
end

function UserCustomization:AddUsers(Users)
	for _, v in pairs(Users) do
		table.insert(self.AllowedUsers, v)
	end
end

function UserCustomization:IsUnlocked(Player)
	local Default = table.find(UserCustomization.DefaultUsers, Player.UserId)
	local User = table.find(self.AllowedUsers, Player.UserId)
	return User or Default
end

function UserCustomization:IsVisible(Player)
	return self:IsUnlocked(Player)
end

return UserCustomization