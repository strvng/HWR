--[[
    DefaultUsers (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization
    Parent: Customization
    Exported: 2026-09-21 11:23:24
]]

return {
	82288569,
	190046
}