--[[
    RenderUtils (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization
    Parent: Customization
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local CustomizationFolder = Modules:WaitForChild("Customization")

local RenderUtils = {}

local ViewportPrefab = script:WaitForChild("Viewport")
local PartPrefab = script:WaitForChild("Part")

RenderUtils.PartPrefab = PartPrefab
RenderUtils.ViewportPrefab = ViewportPrefab
RenderUtils.HAT_DIRECTION = Vector3.new(-1, 0.6, -2)
RenderUtils.CHUTE_DIRECTION = Vector3.new(-0.625, 0.6, -1)

function RenderUtils.HatRenderFromContent(Container, ContentFolder, Zoom)
	local Hat = ContentFolder:WaitForChild("Hat")
	local NewHat = Hat:Clone()
	
	RenderUtils.HatRender(Container, NewHat, Zoom)
end

function RenderUtils.CreateViewport(Texture)
	local NewPrefab = RenderUtils.ViewportPrefab:Clone()
	
	return NewPrefab
end

function RenderUtils.CreatePart()
	local NewPrefab = PartPrefab:Clone()
	
	return NewPrefab
end

function RenderUtils.HatRender(Texture, Hat, Zoom)
	local Viewport = RenderUtils.CreateViewport()
	local NewHat = Hat:Clone()
	Viewport.Parent = Texture
	
	RenderUtils.DistanceRender(Viewport, NewHat, RenderUtils.HAT_DIRECTION * Zoom)
end

function RenderUtils.ChuteRender(Texture, Chute, Zoom)
	local Viewport = RenderUtils.CreateViewport()
	local NewChute = Chute:Clone()
	Viewport.Parent = Texture
	
	RenderUtils.DistanceRender(Viewport, NewChute, RenderUtils.CHUTE_DIRECTION * Zoom)
end

function RenderUtils.DistanceRender(Viewport, Object, Offset)
	local Camera = Instance.new("Camera")
	Camera.Parent = Viewport
	
	Object.CFrame = CFrame.new()
	Object.Parent = Viewport
	
	Camera.CFrame = CFrame.new(Offset, Object.Position)
	Viewport.CurrentCamera = Camera
end

function RenderUtils.NewTexturePart()
	local Part = Instance.new("Part")
	Part.TopSurface = Enum.SurfaceType.Smooth
	Part.BottomSurface = Enum.SurfaceType.Smooth
	Part.Size = Vector3.new(10, 10, 1)
	Part.Anchored = true
	
	return Part
end

function RenderUtils.TextureRender(Texture, Part, Zoom)
	local Viewport = RenderUtils.CreateViewport()
	
	Part.Parent = Viewport
	Viewport.Parent = Texture
	
	local Camera = Instance.new("Camera")
	Camera.Parent = Viewport
	
	Part.CFrame = CFrame.new()
	
	Camera.CFrame = CFrame.new(Vector3.new(0, 0, Zoom), Part.Position)
	Viewport.CurrentCamera = Camera
end

return RenderUtils