--[[
    Customization (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization
    Parent: Customization
    Exported: 2026-09-21 11:23:24
]]

local RenderUtils = require("./RenderUtils")

local Customization = {}
Customization.__index = Customization
Customization.RenderUtils = RenderUtils

function Customization.FromScriptAttributes(Script)
	return Customization.new(
		Script:GetAttribute("Name")
	)
end

function Customization.new(Name)
	local self = setmetatable({}, Customization)
	
	assert(Name)
	
	-- Render is a function?
	-- self.Renderer(Container)
	
	self.Name = Name
	self.Type = "Base"
	
	return self
end

function Customization:SetApplication(Application)
	self.Application = Application
end

function Customization:GetName()
	return self.DisplayName or self.Name
end

function Customization:IsVisible(Player)
	return true
end

function Customization:IsUnlocked(Player)
	return false
end

return Customization