--[[
    Application (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail → Camo
    Parent: Camo
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local ContentFolder = Module:WaitForChild("Content")
local Projectiles = Modules:WaitForChild("Projectiles")

local BaseTrail = require(Projectiles:WaitForChild("BaseTrail"))

local Application = BaseTrail.new()
local PartFaces = Enum.NormalId:GetEnumItems()
local CamoTexture = ContentFolder:WaitForChild("Decal")

Application:AddApplyCallback("Default", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		for i, v in pairs(PartFaces) do
			local Texture = CamoTexture:Clone()
			Texture.Face = v
			Texture.Parent = ProjectileModel
		end
	end
end)

return Application