--[[
    Classic (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail
    Parent: Trail
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local LevelCustomization = require(Customization:WaitForChild("LevelCustomization"))
local Application = require(script:WaitForChild("Application"))

local Trail = LevelCustomization.FromScriptAttributes(script)

local ContentFolder = script:WaitForChild("Content")
local ClassicTexture = ContentFolder:WaitForChild("Studs")

function Trail:Render(Container)
	local Part = Trail.RenderUtils.NewTexturePart()
	
	local NewTexture = ClassicTexture:Clone()
	NewTexture.Face = Enum.NormalId.Back
	NewTexture.StudsPerTileV = 3.8
	NewTexture.Parent = Part
	
	Container.BackgroundColor3 = Color3.fromRGB(57, 59, 61)
	Part.Material = Enum.Material.SmoothPlastic
	Part.BrickColor = BrickColor.new("Bright yellow")
	
	Trail.RenderUtils.TextureRender(Container, Part, 3)
end

Trail:SetApplication(Application)

return Trail