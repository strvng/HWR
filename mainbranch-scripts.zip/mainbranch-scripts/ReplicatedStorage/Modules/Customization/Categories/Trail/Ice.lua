--[[
    Ice (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail
    Parent: Trail
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local LevelCustomization = require(Customization:WaitForChild("LevelCustomization"))
local Application = require(script:WaitForChild("Application"))

local Trail = LevelCustomization.FromScriptAttributes(script)

local ContentFolder = script:WaitForChild("Content")
local Gradient = ContentFolder:WaitForChild("UIGradient")

function Trail:Render(Container)
	local NewGradient = Gradient:Clone()
	
	Container.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	NewGradient.Parent = Container
end

Trail:SetApplication(Application)

return Trail