--[[
    Application (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail → Rock
    Parent: Rock
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ContentFolder = Module:WaitForChild("Content")

local BaseTrail = require(Projectiles:WaitForChild("BaseTrail"))

local Application = BaseTrail.new()

local Particle = ContentFolder:WaitForChild("Particle")

local function CreateParticle(Position, Count)
	BaseTrail.TrailHelper.PaintballParticle(Particle, Position, {
		DebrisTimer = 5,
		SpawnCount = Count,
		VelocityMultiplier = 25,
		AngularVelocityMultiplier = 100
	})
end

Application:AddApplyCallback("Default", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ProjectileModel.Material = Enum.Material.Slate
		ProjectileModel.BrickColor = BrickColor.new("Smoky grey")
	end
end)

Application:AddHitCallback("Default", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		local ParticleCount = BaseTrail.TrailHelper.IsProjectileExplosive(Projectile) and 20 or 5
		
		CreateParticle(
			ProjectileModel.CFrame,
			ParticleCount
		)
	end
end)

return Application