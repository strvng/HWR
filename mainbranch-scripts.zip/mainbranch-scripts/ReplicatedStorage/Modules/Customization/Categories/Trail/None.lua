--[[
    None (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail
    Parent: Trail
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local LevelCustomization = require(Customization:WaitForChild("LevelCustomization"))
local Application = require(script:WaitForChild("Application"))

local Trail = LevelCustomization.FromScriptAttributes(script)

function Trail:Render(Container)
	
end

Trail:SetApplication(Application)

return Trail