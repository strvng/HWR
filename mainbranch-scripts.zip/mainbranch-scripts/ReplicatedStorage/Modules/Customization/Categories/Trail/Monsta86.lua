--[[
    Monsta86 (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail
    Parent: Trail
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")
local Projectiles = Modules:WaitForChild("Projectiles")

local UserCustomization = require(Customization:WaitForChild("UserCustomization"))
local Application = require(script:WaitForChild("Application"))

local Trail = UserCustomization.FromScriptAttributes(script)

local ContentFolder = script:WaitForChild("Content")
local Gradient = ContentFolder:WaitForChild("Gradient")

local Zoom = script:GetAttribute("Zoom")

function Trail:Render(Container)
	local NewGradient = Gradient:Clone()
	
	Container.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	NewGradient.Parent = Container
end

local AllowedUsers = {
	222563845
}

Trail:SetApplication(Application)
Trail:AddUsers(AllowedUsers)

return Trail