--[[
    Rock (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail
    Parent: Trail
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local LevelCustomization = require(Customization:WaitForChild("LevelCustomization"))
local Application = require(script:WaitForChild("Application"))

local Trail = LevelCustomization.FromScriptAttributes(script)

function Trail:Render(Container)
	local Part = Trail.RenderUtils.NewTexturePart()

	Part.Material = Enum.Material.Slate
	Part.BrickColor = BrickColor.new("Smoky grey")

	Trail.RenderUtils.TextureRender(Container, Part, 3)
end

Trail:SetApplication(Application)

return Trail