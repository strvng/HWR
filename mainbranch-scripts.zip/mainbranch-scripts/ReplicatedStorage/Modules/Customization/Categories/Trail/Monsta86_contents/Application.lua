--[[
    Application (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail → Monsta86
    Parent: Monsta86
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")

local Module = script.Parent
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")
local ContentFolder = Module:WaitForChild("Content")
local Projectiles = Modules:WaitForChild("Projectiles")
local Utilities = Modules:WaitForChild("Utilities")

local BaseTrail = require(Projectiles:WaitForChild("BaseTrail"))
local DebrisFolder = require(Utilities:WaitForChild("DebrisFolder"))

local Application = BaseTrail.new()

local Particles = ContentFolder:WaitForChild("Particles")
local ExplosionFolder = ContentFolder:WaitForChild("Explosion")

local function ApplyParticles(Model, Position)
	local NewParticles = Particles:Clone()
	
	local Velocity = Model.AssemblyLinearVelocity
	local SquaredVelocity = math.sqrt(Velocity.X + Velocity.Z)
	
	--for _, v in pairs(NewParticles:GetDescendants()) do
	--	if v:IsA("ParticleEmitter") then
	--		v.Rate = 
	--	end
	--end
	
	NewParticles.Parent = Model
end

local function ApplyParticlesByVelocity(Model)
	local NewParticles = Particles:Clone()
	
	local Velocity = Model.AssemblyLinearVelocity
	local Unit = Velocity.Unit
	
	NewParticles.CFrame = CFrame.new(Vector3.zero, Unit)
	
	NewParticles.Parent = Model
end

Application:AddApplyCallback("Default", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		-- find the back of the model
		-- on the z axis?
		local Size = ProjectileModel.Size
		
		ApplyParticles(ProjectileModel, Vector3.zAxis * (Size.Z / 2) * -1)
	end
end)

Application:AddApplyCallback("Pistol", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ApplyParticlesByVelocity(ProjectileModel)
	end
end)

Application:AddApplyCallback("AK47", function(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ApplyParticlesByVelocity(ProjectileModel)
	end
end)

function Application.ExplodeEffect(Position)
	local Part = Instance.new("Part")
	Part.Size = Vector3.one
	Part.Anchored = true
	Part.CanCollide = false
	Part.CanQuery = false
	Part.CanTouch = false
	Part.Transparency = 1
	Part.CFrame = CFrame.new(Position)
	Part.Parent = DebrisFolder.Other
	
	for _, v in pairs(ExplosionFolder:GetChildren()) do
		local Particle = v:Clone()
		Particle.Parent = Part
	end
	
	Debris:AddItem(Part, 2)
	
	task.delay(0.5, function()
		for _, v in pairs(Part:GetChildren()) do
			if v:IsA("ParticleEmitter") then
				v.Enabled = false
			end
		end
	end)
end

return Application