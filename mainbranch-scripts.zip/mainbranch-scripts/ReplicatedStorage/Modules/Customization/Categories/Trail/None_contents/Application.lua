--[[
    Application (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Trail → None
    Parent: None
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")

local BaseTrail = require(Projectiles:WaitForChild("BaseTrail"))

local Application = BaseTrail.new()

Application:AddApplyCallback("Default", function(Projectile)

end)

Application:AddHitCallback("Default", function(Projectile)
	
end)

return Application