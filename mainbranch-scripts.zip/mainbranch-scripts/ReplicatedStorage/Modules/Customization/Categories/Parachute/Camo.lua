--[[
    Camo (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Parachute
    Parent: Parachute
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local LevelCustomization = require(Customization:WaitForChild("LevelCustomization"))

local Parachute = LevelCustomization.FromScriptAttributes(script)

local Zoom = script:GetAttribute("Zoom")

local ContentFolder = script:WaitForChild("Content")
local Handle = ContentFolder:WaitForChild("Handle")

function Parachute:Render(Container)
	local NewHandle = Handle:Clone()
	
	Parachute.RenderUtils.ChuteRender(Container, NewHandle, Zoom)
end

return Parachute