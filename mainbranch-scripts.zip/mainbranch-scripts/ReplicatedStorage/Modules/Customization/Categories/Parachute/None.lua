--[[
    None (ModuleScript)
    Path: ReplicatedStorage → Modules → Customization → Categories → Parachute
    Parent: Parachute
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")

local LevelCustomization = require(Customization:WaitForChild("LevelCustomization"))

local Parachute = LevelCustomization.FromScriptAttributes(script)

function Parachute:Render(Container)
	
end

return Parachute