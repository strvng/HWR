--[[
    BackpackController (ModuleScript)
    Path: ReplicatedStorage → Modules → Tools
    Parent: Tools
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")

local Satchel = require(Tools:WaitForChild("Satchel"))

local Player = Players.LocalPlayer

local BackpackController = {}

local function GetHumanoid()
	local Character = Player.Character
	if Character then
		return Character:FindFirstChildOfClass("Humanoid")
	end
end

function BackpackController:Open()
	Satchel.OpenClose(true)
end

function BackpackController:Close()
	Satchel.OpenClose(false)
end

function BackpackController:Enable()
	Satchel:SetBackpackEnabled(true)
end

function BackpackController:Disable()
	Satchel:SetBackpackEnabled(false)
end

function BackpackController:IsEnabled()
	return Satchel:GetBackpackEnabled()
end

function BackpackController:EquipTool(Tool)
	local Humanoid = GetHumanoid()
	if Humanoid then
		Humanoid:EquipTool(Tool)
	end
end

function BackpackController:UnequipTools()
	local Humanoid = GetHumanoid()
	if Humanoid then
		Humanoid:UnequipTools()
	end
end

return BackpackController