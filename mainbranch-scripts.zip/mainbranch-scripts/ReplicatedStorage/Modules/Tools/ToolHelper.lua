--[[
    ToolHelper (ModuleScript)
    Path: ReplicatedStorage → Modules → Tools
    Parent: Tools
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local ToolHelper = {}

-- Takes in a Player or a Character and checks if the Tool instance that is passed is the one that is equipped
function ToolHelper.IsEquipped(Character: Player, Tool: Tool)
	if Character then
		if Character:IsA("Model") then
			return Character:FindFirstChildOfClass("Tool") == Tool
		elseif Character:IsA("Player") then
			local NewCharacter = Character.Character
			if NewCharacter then
				return NewCharacter:FindFirstChildOfClass("Tool") == Tool
			end
		end
	end
end

-- Gets the equipped tool from the Player
function ToolHelper.GetEquipped(Player: Player)
	local Character = Player.Character
	if Character then
		return Character:FindFirstChildOfClass("Tool")
	end
end

-- Get all the tools from a Player's backpack
function ToolHelper.GetBackpackTools(Player: Player): {Tool}
	local Backpack = Player:FindFirstChild("Backpack")
	if Backpack then
		return Backpack:GetChildren()
	end
end

-- Returns all the tools that a Player has
function ToolHelper.GetAllTools(Player: Player): {Tool}
	local Tools = {}
	
	local BackpackTools = ToolHelper.GetBackpackTools(Player)
	if BackpackTools then
		Tools = BackpackTools
	end
	
	local Equipped = ToolHelper.GetEquipped(Player)
	if Equipped then
		table.insert(Tools, Equipped)
	end
	
	return Tools
end

-- Checks if a Tool object with the Name argument can be found in the Player's Backpack or Character
function ToolHelper.FindTool(Player: Player, Name: string): Tool
	local Backpack = Player:FindFirstChild("Backpack")
	if Backpack then
		local Found = Backpack:FindFirstChild(Name)
		if Found then
			return Found
		end
	end
	
	local Equipped = ToolHelper.GetEquipped(Player)
	if Equipped and Equipped.Name == Name then
		return Equipped
	end
end

return ToolHelper