--[[
    LocalToolHelper (ModuleScript)
    Path: ReplicatedStorage → Modules → Tools
    Parent: Tools
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")

local ToolHelper = require(Tools:WaitForChild("ToolHelper"))

local Player = Players.LocalPlayer

local LocalToolHelper = {}

function LocalToolHelper.IsEquipped(Tool)
	return ToolHelper.IsEquipped(Player.Character, Tool)
end

function LocalToolHelper.CanActivate()
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		if Humanoid and Humanoid.Health > 0 then
			return true
		end
	end
end

return LocalToolHelper