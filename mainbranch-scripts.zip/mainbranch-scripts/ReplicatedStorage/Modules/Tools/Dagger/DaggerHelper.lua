--[[
    DaggerHelper (ModuleScript)
    Path: ReplicatedStorage → Modules → Tools → Dagger
    Parent: Dagger
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local Debris = game:GetService("Debris")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")
local Dagger = Tools:WaitForChild("Dagger")
local Projectiles = Modules:WaitForChild("Projectiles")

local WeaponSettings = require(Projectiles:WaitForChild("Settings"))
local SwordController = require(Dagger:WaitForChild("SwordController"))

local Player = Players.LocalPlayer

local DaggerHelper = {}

function DaggerHelper.PlayAnimation(Tool, Type)
	local Anim = Instance.new("StringValue")
	Anim.Value = Type
	Anim.Name = "toolanim"
	Anim.Parent = Tool
	
	Debris:AddItem(Anim, 1)
end

function DaggerHelper.ServerLungeAnimation(Player, Tool)
	local Character = Player.Character
	if Character then
		local RightArm = Character:FindFirstChild("Right Arm")
		if RightArm then
			local RightGrip = RightArm:FindFirstChild("RightGrip")
			if RightGrip then
				DaggerHelper.PlaySound(Tool, "Lunge")
				RightGrip.C1 = CFrame.new(0, 0, -1.5) * CFrame.Angles(0, math.rad(-180), math.rad(-90))
				task.delay(WeaponSettings.Dagger.LungeTime, function()
					RightGrip.C1 = CFrame.new(0, 0, -1.5) * CFrame.Angles(0, math.rad(90), math.rad(90))
				end)
			end
		end
	end
end

function DaggerHelper.SlashAnimation(Tool)
	local Handle = Tool:FindFirstChild("Handle")
	if Handle then
		local SlashSound = Handle:FindFirstChild("Slash")
		if SlashSound then
			SlashSound:Play()
		end
	end
end

function DaggerHelper.LungeAnimation(Tool, Local)
	local Handle = Tool:FindFirstChild("Handle")
	if Handle then
		local LungeSound = Handle:FindFirstChild("Lunge")
		if LungeSound then
			SwordController:Lunge(Tool, Local)
			LungeSound:Play()
			
			task.delay(WeaponSettings.Dagger.LungeTime, function()
				SwordController:Normal(Tool, Local)
			end)
		end
	end
end

function DaggerHelper.Float()
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChild("Humanoid")
		if Humanoid then
			local RootPart = Humanoid.RootPart
			if RootPart then
				local BodyVelocity = Instance.new("BodyVelocity")
				BodyVelocity.MaxForce = WeaponSettings.Dagger.MaxForce
				BodyVelocity.Velocity = Vector3.new(0, 10, 0)
				BodyVelocity.Parent = RootPart
				
				Debris:AddItem(BodyVelocity, WeaponSettings.Dagger.ForceDebris)
			end
		end
	end
end

function DaggerHelper.PlaySound(Tool, Name)
	local Handle = Tool:FindFirstChild("Handle")
	if Handle then
		local Sound = Handle:FindFirstChild(Name)
		if Sound then
			Sound:Play()
		end
	end
end

return DaggerHelper