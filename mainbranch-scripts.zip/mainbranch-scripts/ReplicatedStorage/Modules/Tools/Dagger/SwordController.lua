--[[
    SwordController (ModuleScript)
    Path: ReplicatedStorage → Modules → Tools → Dagger
    Parent: Dagger
    Exported: 2026-09-21 11:23:24
]]

local Controller = {
	IsLunged = false
}

function Controller:Lunge(Tool, IsBind)
	Tool.GripForward = Vector3.new(0, 0, 1)
	Tool.GripRight = Vector3.new(0, -1, 0)
	Tool.GripUp = Vector3.new(-1, 0, 0)
	
	if IsBind then
		self.IsLunged = true
	end
end

function Controller:Normal(Tool, IsBind)
	Tool.GripForward = Vector3.new(-1, 0, 0)
	Tool.GripRight = Vector3.new(0, 1, 0)
	Tool.GripUp = Vector3.new(0, 0, 1)
	
	if IsBind then
		self.IsLunged = false
	end
end

return Controller