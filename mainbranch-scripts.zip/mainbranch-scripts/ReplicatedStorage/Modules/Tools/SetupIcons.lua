--[[
    SetupIcons (ModuleScript)
    Path: ReplicatedStorage → Modules → Tools
    Parent: Tools
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")

local LocalToolHelper = require(Tools:WaitForChild("LocalToolHelper"))

local Player = Players.LocalPlayer
local Mouse = Player:GetMouse()

local function ShouldSetIcon(Tool)
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChildOfClass("Humanoid")
		if Humanoid then
			return LocalToolHelper.IsEquipped(Tool) and Humanoid.Health > 0
		end
	end
end

return function(Tool, Enabled, Disabled)
	local CurrentIcon = Enabled
	
	Tool:GetPropertyChangedSignal("Enabled"):Connect(function()
		CurrentIcon = (Tool.Enabled and Enabled) or Disabled
		
		if ShouldSetIcon(Tool) then
			Mouse.Icon = CurrentIcon
		end
	end)
	
	Tool.Equipped:Connect(function()
		Mouse.Icon = CurrentIcon
	end)
	
	Tool.Unequipped:Connect(function()
		Mouse.Icon = ""
	end)
end