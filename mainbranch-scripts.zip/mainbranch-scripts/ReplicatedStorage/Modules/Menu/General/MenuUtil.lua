--[[
    MenuUtil (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General
    Parent: General
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Templates = MenuFolder:WaitForChild("Templates")

local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

local Menu = PlayerGui:WaitForChild("Menu")

local Util = {}

function Util:GetMenu()
	return Menu
end

function Util:GetFrame(Name)
	return Menu:WaitForChild(Name)
end

function Util:GetTemplate(Name)
	return Templates:WaitForChild(Name)
end

return Util