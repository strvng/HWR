--[[
    ZoomController (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General
    Parent: General
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")

local UI = require(Settings:WaitForChild("UI"))

local Player = Players.LocalPlayer
local Camera = workspace.CurrentCamera

local Controller = {
	IsEnabled = false,
	IsZoomed = false,
	LastFOV = 15,
	ZoomTrack = nil,
	BeganConnection = nil,
	EndedConnection = nil,
	ScrollConnection = nil,
}

local OldDistance = Player.CameraMaxZoomDistance
local DefaultFOV = Camera.FieldOfView

local function TweenFOV(FOV, EasingDirection)
	local ZoomTrack = Controller.ZoomTrack
	if ZoomTrack then
		ZoomTrack:Cancel()
		Controller.ZoomTrack = nil
	end
	
	ZoomTrack = TweenService:Create(
		Camera,
		TweenInfo.new(0.25, Enum.EasingStyle.Quart, EasingDirection, 0, false, 0),
		{
			FieldOfView = FOV
		}
	)
	ZoomTrack:Play()
	
	Controller.ZoomTrack = ZoomTrack
end

local function IncrementFOV(Amount)
	Controller.LastFOV = math.clamp(Controller.LastFOV + Amount, 1, DefaultFOV-10)
end

local function SetFOV(FOV)
	
end

local function IsTyping()
	return UserInputService:GetFocusedTextBox()
end

local function Began(InputObject)
	if InputObject.KeyCode == UI.Zoom.ZoomKey and not IsTyping() then
		Controller.IsZoomed = true
		Player.CameraMaxZoomDistance = 0
		TweenFOV(Controller.LastFOV, Enum.EasingDirection.Out)
		UserInputService.MouseDeltaSensitivity = Controller.LastFOV / 100
	end
end

local function Ended(InputObject)
	if InputObject.KeyCode == UI.Zoom.ZoomKey then
		Controller.IsZoomed = false
		Player.CameraMaxZoomDistance = OldDistance
		TweenFOV(DefaultFOV, Enum.EasingDirection.In)
		UserInputService.MouseDeltaSensitivity = 1
	end
end

local function Scrolling(InputObject)
	if InputObject.UserInputType == Enum.UserInputType.MouseWheel and Controller.IsZoomed then
		local Up = InputObject.Position.Z == 1
		
		if Up then
			IncrementFOV(-5)
			TweenFOV(Controller.LastFOV, Enum.EasingDirection.Out)
		else
			IncrementFOV(5)
			TweenFOV(Controller.LastFOV, Enum.EasingDirection.Out)
		end
		
		UserInputService.MouseDeltaSensitivity = Controller.LastFOV / 120
	end
end

local function Disconnect()
	local BeganConnection = Controller.BeganConnection
	local EndedConnection = Controller.EndedConnection
	local ScrollConnection = Controller.ScrollConnection
	if BeganConnection and EndedConnection and ScrollConnection then
		BeganConnection:Disconnect()
		EndedConnection:Disconnect()
		ScrollConnection:Disconnect()
		Controller.BeganConnection = nil
		Controller.EndedConnection = nil
		Controller.ScrollConnection = nil
	end
end

local function Connect()
	if not Controller.IsEnabled and not Controller.BeganConnection and not Controller.EndedConnection and not Controller.ScrollConnection then
		Controller.BeganConnection = UserInputService.InputBegan:Connect(Began)
		Controller.EndedConnection = UserInputService.InputEnded:Connect(Ended)
		Controller.ScrollConnection = UserInputService.InputChanged:Connect(Scrolling)
	end
end

function Controller:Enable()
	Connect()
	
	Controller.IsEnabled = true
end

function Controller:Disable()
	Disconnect()

	Controller.IsEnabled = false
end

return Controller