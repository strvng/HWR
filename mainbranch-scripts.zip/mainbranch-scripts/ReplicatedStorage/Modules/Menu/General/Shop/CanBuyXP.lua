--[[
    CanBuyXP (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General → Shop
    Parent: Shop
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Customization = Modules:WaitForChild("Customization")
local Data = Modules:WaitForChild("Data")

local DataController = require(Data:WaitForChild("DataController"))
local Levels = require(Customization:WaitForChild("LevelController"))

local LevelCap = Levels:GetMaxLevel()

return function()
	return DataController:GetLevel() < LevelCap
end