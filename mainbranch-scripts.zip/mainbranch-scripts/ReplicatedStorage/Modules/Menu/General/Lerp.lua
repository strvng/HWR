--[[
    Lerp (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General
    Parent: General
    Exported: 2026-09-21 11:23:24
]]

return function(a, b, t)
	return a + (b - a) * t
end