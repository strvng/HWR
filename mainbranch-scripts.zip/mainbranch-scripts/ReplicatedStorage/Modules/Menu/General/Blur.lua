--[[
    Blur (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General
    Parent: General
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Lighting = game:GetService("Lighting")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")

local UI = require(Settings:WaitForChild("UI"))

local BlurEffect = Instance.new("BlurEffect")
BlurEffect.Parent = Lighting
BlurEffect.Enabled = false
BlurEffect.Size = 0

local BlurOnTween = TweenService:Create(
	BlurEffect,
	UI.WinnerText.BlurShowing,
	{
		Size = 18,
	}
)

local BlurOffTween = TweenService:Create(
	BlurEffect,
	UI.WinnerText.BlurHidden,
	{
		Size = 0,
	}
)

BlurOffTween.Completed:Connect(function()
	BlurEffect.Enabled = false
end)

local Blur = {
	BlurEffect = BlurEffect,
}

function Blur:Show()
	BlurEffect.Enabled = true
	BlurOnTween:Play()
end

function Blur:Hide()
	BlurOffTween:Play()
end

return Blur