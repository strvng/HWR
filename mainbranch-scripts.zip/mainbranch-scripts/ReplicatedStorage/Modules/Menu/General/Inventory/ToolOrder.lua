--[[
    ToolOrder (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General → Inventory
    Parent: Inventory
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

local VipTools = require(Settings:WaitForChild("VipTools"))
local DefaultTools = require(Settings:WaitForChild("DefaultTools"))

local ToolOrder = {
	VipTools = VipTools,
	DefaultTools = DefaultTools
}

-- Returns FULL COPY of default tools
-- using table.clone alone caused all the inventory items to be set to -1
-- and ruin the inventory for everyone else
function ToolOrder.GetDefaultTools()
	local Base = {}
	
	for _, v in pairs(DefaultTools) do
		table.insert(
			Base,
			table.clone(v)
		)
	end
	
	return Base
end

function ToolOrder.GetToolFromSort(Sort, Name)
	for _, v in pairs(Sort) do
		if v.Name == Name then
			return v
		end
	end
end

function ToolOrder.GetToolsToSave(IsVip)
	local Sort = ToolOrder.GetDefaultTools()
	
	if IsVip then
		for ToolName, _ in pairs(VipTools) do
			table.insert(Sort, {
				Name = ToolName,
				Slot = #Sort + 1
			})
		end
	end
	
	return Sort
end

return ToolOrder