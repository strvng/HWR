--[[
    ApplySetting (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]

return function(Type, Enabled)
	local Module = script:FindFirstChild(Type)
	if Module then
		Module = require(Module)
		Module(Enabled)
	end
end