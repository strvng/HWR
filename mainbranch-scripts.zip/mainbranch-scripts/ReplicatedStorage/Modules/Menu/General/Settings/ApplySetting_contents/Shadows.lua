--[[
    Shadows (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General → Settings → ApplySetting
    Parent: ApplySetting
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local Lighting = game:GetService("Lighting")

return function(Enabled)
	Lighting.GlobalShadows = Enabled
end