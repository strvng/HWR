--[[
    Lighting (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General → Settings → ApplySetting
    Parent: ApplySetting
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local Lighting = game:GetService("Lighting")

local ColorCorrection = Lighting:WaitForChild("ColorCorrection")
local ColorGrading = Lighting:WaitForChild("ColorGrading")

return function(Enabled)
	if Enabled then
		ColorGrading.Enabled = false
		ColorCorrection.Enabled = false
		--Lighting.Ambient = Color3.fromRGB(255, 255, 255)
		Lighting.Brightness = 1.5
		Lighting.EnvironmentSpecularScale = 1
		Lighting.EnvironmentDiffuseScale = 1
	else
		ColorGrading.Enabled = true
		ColorCorrection.Enabled = true
		--Lighting.Ambient = Color3.fromRGB(181, 181, 181)
		Lighting.Brightness = 1.5
		Lighting.EnvironmentSpecularScale = 0
		Lighting.EnvironmentDiffuseScale = 0
	end
end