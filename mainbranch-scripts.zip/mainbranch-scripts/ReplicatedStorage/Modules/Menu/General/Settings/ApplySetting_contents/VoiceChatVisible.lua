--[[
    VoiceChatVisible (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General → Settings → ApplySetting
    Parent: ApplySetting
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

local VoiceChat = PlayerGui:WaitForChild("VoiceChat")

return function(Enabled)
	VoiceChat.Enabled = Enabled
end