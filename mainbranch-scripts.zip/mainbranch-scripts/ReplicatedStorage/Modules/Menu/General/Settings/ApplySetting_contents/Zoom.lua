--[[
    Zoom (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → General → Settings → ApplySetting
    Parent: ApplySetting
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Menu = Modules:WaitForChild("Menu")
local General = Menu:WaitForChild("General")

local ZoomController = require(General:WaitForChild("ZoomController"))

return function(Enabled)
	if Enabled then
		ZoomController:Enable()
	else
		ZoomController:Disable()
	end
end