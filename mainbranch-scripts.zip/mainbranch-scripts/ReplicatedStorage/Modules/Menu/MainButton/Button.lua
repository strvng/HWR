--[[
    Button (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → MainButton
    Parent: MainButton
    Exported: 2026-09-21 11:23:24
]]


local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")

local MenuController = require(MenuFolder:WaitForChild("MenuController"))

local Button = {}
Button.__index = Button

function Button.new(ButtonObject, Module)
	local self = setmetatable({}, Button)
	
	local StateOverlay = ButtonObject:WaitForChild("StateOverlay")
	local Icon = ButtonObject:WaitForChild("Icon")
	local CloseIcon = ButtonObject:WaitForChild("Close")
	
	self.ButtonObject = ButtonObject
	self.CloseIcon = CloseIcon
	self.StateOverlay = StateOverlay
	self.Icon = Icon
	self.DefaultIcon = Icon.Image
	self.Menu = Module
	self.Hovered = false
	
	task.defer(function()
		--Module:Setup()
		
		ButtonObject.Activated:Connect(function()
			self:Activated()
		end)
		
		ButtonObject.MouseEnter:Connect(function()
			self:SetHover(true)
		end)
		
		ButtonObject.MouseLeave:Connect(function()
			self:SetHover(false)
		end)
	end)
	
	return self
end

function Button:Activated()
	local Module = self.Menu
	if Module then
		if MenuController.ActiveMenu == Module then
			MenuController:HideActiveMenu()
		else
			MenuController:ShowMenu(Module)
			MenuController.ActiveButton = self
			self:SetOpen(true)
		end
	end
end

function Button:SetHover(Hovered)
	if Hovered then
		self.StateOverlay.ImageTransparency = 0.9
	else
		self.StateOverlay.ImageTransparency = 1
	end
	
	self.Hovered = Hovered
end

function Button:SetOpen(Opened)
	if Opened then
		self.CloseIcon.Visible = true
		self.Icon.Visible = false
		self.ButtonObject.ImageTransparency = 1
	else
		self.CloseIcon.Visible = false
		self.Icon.Visible = true
		self.ButtonObject.ImageTransparency = 0
	end
end

function Button:IsOpen()
	local Icon = self.Icon
	if Icon then
		return not Icon.Visible
	end
end

return Button