--[[
    Results (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local Settings = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local GetDictionaryLength = require(Utilities:WaitForChild("GetDictionaryLength"))
local AnimatedMenu = require(Menus:WaitForChild("AnimatedMenu"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local UI = require(Settings:WaitForChild("UI"))

local ResultsFrame = MenuUtil:GetFrame("Results")
local CloseButton = ResultsFrame:WaitForChild("Close")
local TeamsFrame = ResultsFrame:WaitForChild("Teams")

local RowTemplate = MenuUtil:GetTemplate("NameTemplate")
local ResultTeamTemplate = MenuUtil:GetTemplate("ResultTeam")
local StatExample = MenuUtil:GetTemplate("StatExample")

local Results = setmetatable({}, AnimatedMenu)
Results.__index = Results

local function ClearContainer(Container)
	for _, v in pairs(Container:GetChildren()) do
		if v:IsA("Frame") then
			v:Destroy()
		end
	end
end

function Results.new(Frame)
	local self = setmetatable(AnimatedMenu.new(Frame), Results)
	
	self.FullyClosed:Connect(function()
		ClearContainer(TeamsFrame)
	end)

	CloseButton.Activated:Connect(function()
		self:Hide()
	end)
	
	return self
end

local function TruncateStat(StatName)
	if #StatName > 3 then
		return string.sub(string.upper(StatName), 1, 3)
	else
		return StatName
	end
end

function Results.TruncateTeam(Team)
	return string.split(Team, " ")[1]
end

local function GetOrderedStats(Data)
	local StatData = {}
	
	for _, Data in pairs(Data) do
		StatData[Data.Order] = Data
	end
	
	return StatData
end

local function LoadStats(Container, Data)
	local XPadding = UI.Results.TeamXPadding
	local SizePerStat = (1 - XPadding) / GetDictionaryLength(Data)
	local Index = 1
	
	local StatData = GetOrderedStats(Data)
	
	for i, v in pairs(StatData) do
		local NewStat = StatExample:Clone()
		NewStat.Name = v.Name
		NewStat.Text = TruncateStat(tostring(v.Value))
		NewStat.Size = UDim2.fromScale(SizePerStat, 1)
		NewStat.Visible = true
		NewStat.Parent = Container
		
		Index += 1
	end
end

local function GetUserIdFromDisplayName(Name)
	for _, v in pairs(Players:GetPlayers()) do
		if v.DisplayName == Name then
			return v.UserId
		end
	end
end

local function NewRow(Name, Data, Number)
	local Row = RowTemplate:Clone()
	local NameLabel = Row:WaitForChild("Name")
	--local PlayerIcon = Row:WaitForChild("PlayerIcon")
	local StatContainer = Row:WaitForChild("StatContainer")
	
	NameLabel.Text = Name
	
	local IsEven = Number % 2 == 0
	
	Row.BackgroundColor3 = IsEven and UI.Results.EvenColor or UI.Results.OddColor
	--local UserId = GetUserIdFromDisplayName(Name)
	--if UserId then
	--	task.defer(function()
	--		PlayerIcon.Image = Players:GetUserThumbnailAsync(
	--			UserId,
	--			Enum.ThumbnailType.HeadShot,
	--			Enum.ThumbnailSize.Size48x48
	--		)
	--	end)
	--end
	
	return Row, StatContainer
end

local function NewTeam(Name, PrimaryColor)
	local Team = ResultTeamTemplate:Clone()
	local NameCard = Team:WaitForChild("Name")
	local Players = Team:WaitForChild("Players")
	local StatContainer = NameCard:WaitForChild("StatContainer")
	local TeamName = NameCard:WaitForChild("Team")
	
	NameCard.BackgroundColor3 = PrimaryColor
	TeamName.Text = Name
	
	return Team, StatContainer, Players
end

local function LoadTeamData(Team, Container)
	for _, v in pairs(Team) do
		local Row = NewRow(v.Name, v.KOs, v.WOs, v.CAP)
		Row.Parent = Container
	end
end

function Results.FormatStats(CurrentStats)
	local New = {}
	
	for _, v in ipairs(CurrentStats) do
		New[v.Name] = {
			Name = v.Name,
			Value = v.Name,
			Order = v.Order
		}
	end
	
	return New
end

function Results.FormatPlayerStats(PlayerStats, StatOrder)
	local NewStats = {}
	
	for i, v in pairs(PlayerStats) do
		local Data = StatOrder[v.Name]
		
		NewStats[Data.Order] = {
			Name = v.Name,
			Value = v.Value,
			Order = Data.Order
		}
	end
	
	return NewStats
end

local function GetFirstStat(FormattedStats)
	for _, v in pairs(FormattedStats) do
		if v.Order == 1 then
			return v
		end
	end
end

local function ReformatPlayerData(Player)
	local Reformatted = {}
	
	for _, v in pairs(Player) do
		Reformatted[v.Name] = v.Value
	end
	
	return Reformatted
end

local function GetOrderedPlayers(Players, FormattedStats)
	local FirstStat = GetFirstStat(FormattedStats)
	if FirstStat then
		local NewData = {}
		
		for Name, StatData in pairs(Players) do
			local PlayerData = {
				Name = Name
			}
			
			for _, v in pairs(StatData) do
				PlayerData[v.Name] = v.Value
			end
			
			table.insert(NewData, PlayerData)
		end
		
		table.sort(NewData, function(a, b)
			return a[FirstStat.Name] > b[FirstStat.Name]
		end)
		
		return NewData
	end
end

function Results:DisplayResults(Data, TeamData, CurrentStats)
	local TeamCount = GetDictionaryLength(Data)
	local SizePerTeam = 1 / TeamCount
	
	for _, v in pairs(Data) do
		local NewTeamCol, TeamStats, TeamPlayers = NewTeam(self.TruncateTeam(v.Name), v.TeamColor.Color)
		NewTeamCol.Size = UDim2.fromScale(SizePerTeam, 1)
		local FormattedStats = self.FormatStats(CurrentStats)
		
		LoadStats(TeamStats, FormattedStats)
		
		for i, Data in pairs(GetOrderedPlayers(v.Players, FormattedStats)) do
			local PlayerName = Data.Name
			local Player, StatContainer = NewRow(PlayerName, Data, i)
			
			LoadStats(
				StatContainer,
				self.FormatPlayerStats(v.Players[PlayerName], FormattedStats)
			)
			
			Player.Parent = TeamPlayers
		end
		
		NewTeamCol.Parent = TeamsFrame
	end
end

--function Results:Setup()
	
--end

--Results:Setup()

local singleton

singleton = Results.new(ResultsFrame)

return singleton