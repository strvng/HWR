--[[
    Shop (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local GamepassFolder = Modules:WaitForChild("Gamepass")

local GamepassController = require(GamepassFolder:WaitForChild("GamepassController"))
local Gamepasses = require(GamepassFolder:WaitForChild("Gamepasses"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local AnimatedMenu = require(Menus:WaitForChild("AnimatedMenu"))
local ShopItem = require(script:WaitForChild("Item"))

local ShopFrame = MenuUtil:GetFrame("Shop")
local ContentFrame = ShopFrame:WaitForChild("Content")
local ItemFrame = ContentFrame:WaitForChild("Items")

local Shop = setmetatable({}, AnimatedMenu)
Shop.__index = Shop
--setmetatable(Shop, BaseMenu)

function Shop.new(Frame)
	local self = setmetatable(AnimatedMenu.new(Frame), Shop)
	
	for _, v in pairs(Gamepasses) do
		self:ListItem(v)
	end
	
	return self
end

function Shop:ListItem(Item)
	local NewItem = ShopItem.new(
		Item.Name,
		Item.Price,
		Item.ImageId,
		Item.Id,
		Item.LayoutOrder,
		Item.IsDevProduct
	)
	
	NewItem:SetParent(ItemFrame)
end

local singleton

singleton = Shop.new(ShopFrame)

return singleton