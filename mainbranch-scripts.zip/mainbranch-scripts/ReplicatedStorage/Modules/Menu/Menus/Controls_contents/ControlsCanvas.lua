--[[
    ControlsCanvas (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → Controls
    Parent: Controls
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Menu = Modules:WaitForChild("Menu")
local Menus = Menu:WaitForChild("Menus")
local Settings = Modules:WaitForChild("Settings")

local BaseMenu = require(Menus:WaitForChild("Menu"))
local UI = require(Settings:WaitForChild("UI"))

local ControlsCanvas = setmetatable({}, BaseMenu)
ControlsCanvas.__index = ControlsCanvas

function ControlsCanvas.new(Frame)
	local self = setmetatable(BaseMenu.new(Frame), ControlsCanvas)
	
	self.ActiveTween = nil
	
	--self.CloseTween.Completed:Connect(function(PlaybackState)
	--	if PlaybackState == Enum.PlaybackState.Completed then
	--		BaseMenu.Hide(self)
	--	end
	--end)
	
	return self
end

function ControlsCanvas:CancelTween()
	local ActiveTween = self.ActiveTween
	if ActiveTween then
		ActiveTween:Cancel()
		self.ActiveTween = nil
	end
end

function ControlsCanvas:PlayTween(Tween)
	self:CancelTween()
	
	Tween:Play()
	self.ActiveTween = Tween
end

function ControlsCanvas:Show()
	BaseMenu.Show(self)
	
	local Frame = self.Frame
	if Frame then
		local OpenTween = TweenService:Create(
			Frame,
			UI.Controls.ControlsOpen,
			{
				Position = UI.Controls.OpenPosition
			}
		)
		
		self:PlayTween(OpenTween)
	end
end

function ControlsCanvas:Hide()
	local Frame = self.Frame
	if Frame then
		local CloseTween = TweenService:Create(
			Frame,
			UI.Controls.ControlsClosed,
			{
				Position = UI.Controls.ClosedPosition
			}
		)
		
		CloseTween.Completed:Once(function(PlaybackState)
			if PlaybackState == Enum.PlaybackState.Completed then
				BaseMenu.Hide(self)
			end
		end)
		
		self:PlayTween(CloseTween)
	end
end

return ControlsCanvas