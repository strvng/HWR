--[[
    Controls (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

local ControlsGui = PlayerGui:WaitForChild("Controls")

local ControlsCanvas = require(script:WaitForChild("ControlsCanvas"))

local singleton

local Controls = {}
Controls.__index = Controls

function Controls.new()
	local self = setmetatable({}, Controls)
	
	self.Controllers = {}
	self.ActiveCanvas = nil
	
	for _, v in pairs(ControlsGui:GetChildren()) do
		if v:IsA("CanvasGroup") then
			self.Controllers[v.Name] = ControlsCanvas.new(v)
		end
	end
	
	return self
end

function Controls:Display(ControllerType)
	self:Hide()
	
	local Canvas = self:GetController(ControllerType)
	if Canvas then
		Canvas:Show()
		self.ActiveCanvas = Canvas
	end
end

function Controls:Hide()
	local ActiveCanvas = self.ActiveCanvas
	if ActiveCanvas then
		ActiveCanvas:Hide()
		self.ActiveCanvas = nil
	end
end

function Controls:GetController(ControllerType)
	return self.Controllers[ControllerType]
end

singleton = Controls.new()

return singleton