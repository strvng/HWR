--[[
    Switch (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → Settings
    Parent: Settings
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local General = MenuFolder:WaitForChild("General")
local Data = Modules:WaitForChild("Data")
local SettingsFolder = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

local DataController = require(Data:WaitForChild("DataController"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local UI = require(SettingsFolder:WaitForChild("UI"))
local Signal = require(Utilities:WaitForChild("Signal"))

local SwitchTemplate = MenuUtil:GetTemplate("Switch")

local Switch = {}
Switch.__index = Switch

function Switch.new(Name)
	local self = setmetatable({}, Switch)
	
	local Frame = SwitchTemplate:Clone()
	local SwitchButton = Frame:WaitForChild("Switch")
	
	self.Name = Name
	self.SwitchFrame = Frame
	self.SwitchButton = SwitchButton
	self.Checked = false
	self.ActiveTrack = nil
	self.Switched = Signal.new()
	
	SwitchButton.Activated:Connect(function()
		self:Toggle()
	end)
	
	return self
end

function Switch:Toggle()
	local Checked = not self.Checked
	self:SetChecked(Checked)
	self.Switched:Fire(Checked)
end

function Switch:SetChecked(Checked)
	self.Checked = Checked
	
	DataController.Settings[self.Name] = self.Checked
	
	if self.ActiveTrack then
		self.ActiveTrack:Cancel()
		self.ActiveTrack = nil
	end
	
	if Checked then
		local Track = TweenService:Create(
			self.SwitchFrame,
			UI.Settings.SettingsOpen,
			{
				BackgroundColor3 = UI.Settings.SwitchOnColor
			}
		)
		self.ActiveTrack = Track
		
		Track:Play()
		
		self.SwitchButton:TweenPosition(UI.Settings.SwitchOn, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.5, true)
	else
		local Track = TweenService:Create(
			self.SwitchFrame,
			UI.Settings.SettingsClosed,
			{
				BackgroundColor3 = UI.Settings.SwitchOffColor
			}
		)
		self.ActiveTrack = Track
		
		Track:Play()
		
		self.SwitchButton:TweenPosition(UI.Settings.SwitchOff, Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.5, true)
	end
end

function Switch:SetParent(Frame)
	self.SwitchFrame.Parent = Frame
end

return Switch