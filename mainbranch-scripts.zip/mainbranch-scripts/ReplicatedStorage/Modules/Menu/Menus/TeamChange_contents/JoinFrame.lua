--[[
    JoinFrame (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → TeamChange
    Parent: TeamChange
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local General = MenuFolder:WaitForChild("General")
local Menus = MenuFolder:WaitForChild("Menus")
local SettingsFolder = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

--local TeamColor = require(SettingsFolder:WaitForChild("TeamColor"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local Signal = require(Utilities:WaitForChild("Signal"))

local JoinFramePrefab = MenuUtil:GetTemplate("JoinFrame")

local JoinFrame = {}
JoinFrame.__index = JoinFrame

function JoinFrame.new()
	local self = setmetatable({}, JoinFrame)
	
	local NewPrefab = JoinFramePrefab:Clone()
	local JoinButton = NewPrefab:WaitForChild("Join")
	local TeamTitle = NewPrefab:WaitForChild("Team")
	local PlayerCount = TeamTitle:WaitForChild("Count")
	local IconContainer = NewPrefab:WaitForChild("IconContainer")
	local HelicopterViewport = IconContainer:WaitForChild("Helicopter")
	local HelicopterModel = HelicopterViewport:WaitForChild("Model")
	local Stroke = NewPrefab:WaitForChild("UIStroke")
	
	self.Prefab = NewPrefab
	self.Stroke = Stroke
	self.JoinButton = JoinButton
	self.TeamTitle = TeamTitle
	self.PlayerCountLabel = PlayerCount
	self.IconContainer = IconContainer
	self.HelicopterViewport = HelicopterViewport
	self.HelicopterModel = HelicopterModel
	--self.GradientContainer = GradientContainer
	--self.Gradient = Gradient
	self.Activated = Signal.new()
	
	JoinButton.Activated:Connect(function()
		self.Activated:Fire()
	end)
	
	self.PlayerCount = 0
	self.MaxPlayers = 0
	
	return self
end

function JoinFrame:SetLayoutOrder(LayoutOrder)
	local Prefab = self.Prefab
	if Prefab then
		Prefab.LayoutOrder = LayoutOrder
	end
end

function JoinFrame:ShowStatus(Status)
	local JoinButton = self.JoinButton
	if JoinButton then
		JoinButton.Text = Status
		task.delay(2, function()
			JoinButton.Text = "Join"
		end)
	end
end

function JoinFrame:SetTeamColor(Color)
	local Prefab = self.Prefab
	local JoinButton = self.JoinButton
	local Stroke = self.Stroke
	if Prefab and JoinButton and Stroke then
		Prefab.BackgroundColor3 = Color
		JoinButton.BackgroundColor3 = Color
		Stroke.Color = Color
	end
end

function JoinFrame:SetTeamName(Name)
	local TeamTitle = self.TeamTitle
	if TeamTitle then
		TeamTitle.Text = Name
	end
end

function JoinFrame:SetVehicleColor(Color)
	local HelicopterModel = self.HelicopterModel
	if HelicopterModel then
		for _, v in pairs(HelicopterModel:GetDescendants()) do
			if v:IsA("BasePart") and v:HasTag("Color") then
				v.Color = Color
			end
		end
	end
end

function JoinFrame:PlayersChanged()
	local PlayerCountLabel = self.PlayerCountLabel
	local PlayerCount = self.PlayerCount
	local MaxPlayers = self.MaxPlayers
	if PlayerCountLabel and PlayerCount and MaxPlayers then
		PlayerCountLabel.Text = string.format(
			"%s/%s", PlayerCount, MaxPlayers
		)
	end
end

function JoinFrame:SetPlayerCount(Players)
	self.PlayerCount = Players
	self:PlayersChanged()
end

function JoinFrame:SetPlayerCountMax(Max)
	self.MaxPlayers = Max
	self:PlayersChanged()
end

function JoinFrame:SetXSize(Scale)
	local Prefab = self.Prefab
	if Prefab then
		Prefab.Size = UDim2.fromScale(Scale, 1)
	end
end

function JoinFrame:SetParent(Parent)
	local Prefab = self.Prefab
	if Prefab then
		Prefab.Parent = Parent
	end
end

function JoinFrame:Destroy()
	local Prefab = self.Prefab
	if Prefab then
		Prefab:Destroy()
	end
end

return JoinFrame