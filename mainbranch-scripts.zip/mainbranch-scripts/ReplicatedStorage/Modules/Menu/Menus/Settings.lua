--[[
    Settings (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local Data = Modules:WaitForChild("Data")
local SettingsFolder = General:WaitForChild("Settings")

local DataController = require(Data:WaitForChild("DataController"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local AnimatedMenu = require(Menus:WaitForChild("AnimatedMenu"))
local Switch = require(script:WaitForChild("Switch"))
local ApplySetting = require(SettingsFolder:WaitForChild("ApplySetting"))

local SettingsFrame = MenuUtil:GetFrame("Settings")
local Content = SettingsFrame:WaitForChild("Content")
local Scroll = Content:WaitForChild("Scroll")

local Settings = setmetatable({}, AnimatedMenu)
Settings.__index = Settings

function Settings.new(Frame)
	local self = setmetatable(AnimatedMenu.new(Frame), Settings)
	
	self.Switches = {}
	
	for _, v in pairs(Scroll:GetChildren()) do
		if CollectionService:HasTag(v, "Setting") then
			local NewSwitch = Switch.new(v.Name)
			NewSwitch:SetParent(v)
			
			local Default = DataController.Settings[v.Name]
			
			if Default then
				NewSwitch:SetChecked(Default)
			end
			
			NewSwitch.Switched:Connect(function(Enabled)
				ApplySetting(NewSwitch.Name, Enabled)
			end)
			
			self.Switches[v.Name] = NewSwitch
		end
	end
	
	task.defer(function()
		local LoadedSettings = DataController:LoadSettings()
		if LoadedSettings then
			for Setting, Value in pairs(LoadedSettings) do
				local Switch = self.Switches[Setting]
				if Switch then
					Switch:SetChecked(Value)
				end
				
				ApplySetting(Setting, Value)
			end
		end
	end)
	
	return self
end

function Settings:Hide()
	AnimatedMenu.Hide(self)
	
	DataController:SaveSettings()
end

local singleton

singleton = Settings.new(SettingsFrame)

return singleton