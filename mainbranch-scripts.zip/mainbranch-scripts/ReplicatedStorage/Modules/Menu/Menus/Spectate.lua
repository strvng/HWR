--[[
    Spectate (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")
local Debris = game:GetService("Debris")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Menu = Modules:WaitForChild("Menu")
local General = Menu:WaitForChild("General")
local Settings = Modules:WaitForChild("Settings")
local Sound = Modules:WaitForChild("Sound")

local PlaySound = require(Sound:WaitForChild("PlaySound"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local UI = require(Settings:WaitForChild("UI"))

local Camera = workspace.CurrentCamera
local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

local KillList = PlayerGui:WaitForChild("KillList")
local KillContainer = KillList:WaitForChild("Frame")
local KillExample = KillList:WaitForChild("Example")

local SpectateMenu = PlayerGui:WaitForChild("Spectate")
local SpectateFrame = SpectateMenu:WaitForChild("Frame")
local SpectatePlayerName = SpectateFrame:WaitForChild("Name")
local SpectatePlayerIcon = SpectateFrame:WaitForChild("Player")
local SpectateWeapon = SpectatePlayerName:WaitForChild("Weapon")

local FlagCapturedText = "<stroke color='rgb(0, 0, 0)' joins='round' thickness='1'>Flag Captured <font color='rgb(150, 29, 21)'> [%s XP]</font></stroke>"
local KillText = "<stroke color='rgb(0, 0, 0)' joins='round' thickness='1'>Killed <font color='rgb(150, 29, 21)'>%s</font> [%s XP]</stroke>"

local Spectate = {}

function Spectate:_CancelSlideTracks()
	if self.SlideTracks then
		for _, v in pairs(self.SlideTracks) do
			v:Cancel()
			v:Destroy()
		end
		
		table.clear(self.SlideTracks)
	end
end

function Spectate:SlideDown()
	self:_CancelSlideTracks()
	
	local SlideTracks = {}
	
	for i, v in pairs(KillContainer:GetChildren()) do
		if v:IsA("TextLabel") then
			v.LayoutOrder += 1
			
			local Connection;
			local Track;
			
			Track = TweenService:Create(
				v,
				UI.Spectate.PositionTweenInfo,
				{
					Position = UDim2.new(0.5, 0, v.LayoutOrder * KillExample.Size.Y.Scale, 0)
				}
			)
			
			Track:Play()
			
			Connection = Track.Completed:Connect(function()
				Track = nil
				Connection:Disconnect()
				Connection = nil
			end)
		end
	end
	
	self.SlideTracks = SlideTracks
end

function Spectate.NewTag()
	local Tag = KillExample:Clone()
	Tag.Visible = true
	
	local TransparencyTrack = TweenService:Create(
		Tag,
		UI.Spectate.TransparencyTweenInfo,
		{
			TextTransparency = 0
		}
	)
	
	TransparencyTrack.Completed:Once(function()
		TransparencyTrack:Destroy()
	end)
	
	return Tag, TransparencyTrack
end

function Spectate:FlagCaptured(XPAmount)
	self:SlideDown()
	
	local Tag, DisplayTag = Spectate.NewTag()
	
	Tag.Text = string.format(
		FlagCapturedText,
		tostring(XPAmount)
	)
	DisplayTag:Play()
	
	Debris:AddItem(Tag, UI.Spectate.MessageDisplayTime)
	
	Tag.Parent = KillContainer
end

function Spectate:DisplayKill(Killed, XPAmount)
	self:SlideDown()
	
	local Tag, DisplayTag = Spectate.NewTag()
	
	Tag.Text = string.format(
		KillText,
		Killed.DisplayName,
		tostring(XPAmount)
	)
	DisplayTag:Play()
	
	Debris:AddItem(Tag, UI.Spectate.MessageDisplayTime)
	PlaySound("KillEffect")
	
	Tag.Parent = KillContainer
end

function Spectate.GetWeaponName(Weapon)
	return UI.Spectate.WeaponMap[Weapon] or Weapon
end

function Spectate:DisplayKiller(Attacker, Weapon)
	local Humanoid = Spectate.GetHumanoid(Attacker)
	
	KillContainer:TweenPosition(UI.Spectate.HiddenPosition, table.unpack(UI.Spectate.DownTweenInfo))
	SpectatePlayerIcon.Image = Players:GetUserThumbnailAsync(Attacker.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100)
	SpectatePlayerName.Text = Attacker.Name
	
	if Attacker.UserId == Player.UserId then
		SpectateWeapon.Text = string.format("You killed yourself with your %s", Spectate.GetWeaponName(Weapon))
	else
		SpectateWeapon.Text = string.format("Killed you with their %s", Spectate.GetWeaponName(Weapon))
	end
	
	SpectateMenu.Enabled = true
	
	if Humanoid then
		SpectatePlayerName.Text = string.format("%s [%s]", Attacker.Name, math.floor(Humanoid.Health))
	end
end

function Spectate.GetHumanoid(Player)
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChild("Humanoid")
		if Humanoid then
			return Humanoid, Character
		end
	end
end

function Spectate.SpectatePlayer(Player)
	local Humanoid = Spectate.GetHumanoid(Player)
	if Humanoid then
		Camera.CameraSubject = Humanoid
	end
end

return Spectate