--[[
    WinnerText (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local Settings = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

local BaseMenu = require(Menus:WaitForChild("Menu"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local Signal = require(Utilities:WaitForChild("Signal"))
local UI = require(Settings:WaitForChild("UI"))

local WinnerTextLabel = MenuUtil:GetFrame("WinnerText")
local Stroke = WinnerTextLabel:WaitForChild("UIStroke")
local TadaSound = script:WaitForChild("Tada")

local WinnerText = setmetatable({}, BaseMenu)
WinnerText.__index = WinnerText

function WinnerText.new(Frame)
	local self = setmetatable(BaseMenu.new(Frame), WinnerText)
	
	local TextShowing = TweenService:Create(
		WinnerTextLabel,
		UI.WinnerText.Showing,
		{
			TextTransparency = 0
		}
	)
	
	local StrokeShowing = TweenService:Create(
		Stroke,
		UI.WinnerText.Showing,
		{
			Transparency = 0
		}
	)
	
	local TextHidden = TweenService:Create(
		WinnerTextLabel,
		UI.WinnerText.Hidden,
		{
			TextTransparency = 1
		}
	)
	
	local StrokeHidden = TweenService:Create(
		Stroke,
		UI.WinnerText.Hidden,
		{
			Transparency = 1
		}
	)
	
	TextShowing.Completed:Connect(function(PlaybackState)
		if PlaybackState == Enum.PlaybackState.Completed then
			self.FullyOpened:Fire()
		end
	end)
	
	TextHidden.Completed:Connect(function(PlaybackState)
		if PlaybackState == Enum.PlaybackState.Completed then
			self.FullyClosed:Fire()
			self:SetTeam(nil)
			BaseMenu.Hide(self)
			--self:Hide(self)
		end
	end)
	
	self.TextShowingTween = TextShowing
	self.TextHiddenTween = TextHidden
	self.StrokeShowingTween = StrokeShowing
	self.StrokeHiddenTween = StrokeHidden
	self.FullyOpened = Signal.new()
	self.FullyClosed = Signal.new()
	
	return self
end

function WinnerText:SetTeam(Team)
	if Team then
		WinnerTextLabel.Text = string.format("%s Wins!", Team.Name)
		WinnerTextLabel.TextColor3 = Team.TeamColor
		WinnerTextLabel.Visible = true
	else
		WinnerTextLabel.Visible = false
		WinnerTextLabel.Text = ""
	end
end

function WinnerText:Show()
	BaseMenu.Show(self)
	self.TextShowingTween:Play()
	self.StrokeShowingTween:Play()
end

function WinnerText:Hide()
	self.TextHiddenTween:Play()
	self.StrokeHiddenTween:Play()
end

function WinnerText:PlayTada()
	SoundService:PlayLocalSound(TadaSound)
end

function WinnerText:FullShow()
	self:Show()
	self:PlayTada()
	--task.wait(UI.WinnerText.BlurDelay)
	task.wait(UI.WinnerText.DisplayTime)
	self:Hide()
	task.wait(UI.WinnerText.WinnersHiddenTime)
end

local singleton

singleton = WinnerText.new(WinnerTextLabel)

return singleton