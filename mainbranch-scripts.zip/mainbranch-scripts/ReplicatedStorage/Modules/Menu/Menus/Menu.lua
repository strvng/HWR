--[[
    Menu (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Utilities = Modules:WaitForChild("Utilities")

local Signal = require(Utilities:WaitForChild("Signal"))

local Menu = {}
Menu.__index = Menu

function Menu.new(Frame)
	local self = setmetatable({}, Menu)
	
	self.Frame = Frame
	self.Visible = false
	self.Opened = Signal.new()
	self.Closed = Signal.new()
	
	return self
end

function Menu:Show()
	self.Opened:Fire()
	self.Frame.Visible = true
	self.Visible = true
end

function Menu:Hide()
	self.Closed:Fire()
	self.Frame.Visible = false
	self.Visible = false
end

return Menu