--[[
    AnimatedMenu (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Menu = Modules:WaitForChild("Menu")
local Menus = Menu:WaitForChild("Menus")
local Settings = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

local BaseMenu = require(Menus:WaitForChild("Menu"))
local Signal = require(Utilities:WaitForChild("Signal"))
local UI = require(Settings:WaitForChild("UI"))

local AnimatedMenu = setmetatable({}, BaseMenu)
AnimatedMenu.__index = AnimatedMenu

function AnimatedMenu._CancelTrack(self)
	local ActiveTrack = self.ActiveTrack
	if ActiveTrack then
		ActiveTrack.Track:Cancel()
		ActiveTrack.Connection:Disconnect()
		ActiveTrack.Connection = nil
	end
end

function AnimatedMenu.new(Frame)
	local self = setmetatable(BaseMenu.new(Frame), AnimatedMenu)
	
	local UIScale = Frame:WaitForChild("UIScale")
	
	self.UIScale = UIScale
	self.OpenTweenInfo = UI.Default.Open
	self.ClosedTweenInfo = UI.Default.Closed
	self.ActiveTrack = nil
	
	self.FullyOpened = Signal.new()
	self.FullyClosed = Signal.new()
	
	return self
end

function AnimatedMenu:Show()
	AnimatedMenu._CancelTrack(self)
	
	local OpenTween = TweenService:Create(
		self.UIScale,
		self.OpenTweenInfo,
		{
			Scale = UI.ActiveUIScale
		}
	)
	
	local CompletedConnection
	
	CompletedConnection = OpenTween.Completed:Connect(function(PlaybackState)
		if PlaybackState == Enum.PlaybackState.Completed then
			self.FullyOpened:Fire()
		end
	end)
	
	self.ActiveTrack = {
		Track = OpenTween,
		Connection = CompletedConnection
	}
	
	OpenTween:Play()
	
	self.Frame.Visible = true
	self.Opened:Fire()
	self.Visible = true
end

function AnimatedMenu:Hide()
	AnimatedMenu._CancelTrack(self)
	
	local ClosedTween = TweenService:Create(
		self.UIScale,
		self.ClosedTweenInfo,
		{
			Scale = 0
		}
	)
	
	local CompletedConnection
	
	CompletedConnection = ClosedTween.Completed:Connect(function(PlaybackState)
		if PlaybackState == Enum.PlaybackState.Completed then
			self.FullyClosed:Fire()
			self.Frame.Visible = false
		end
	end)
	
	self.ActiveTrack = {
		Track = ClosedTween,
		Connection = CompletedConnection
	}
	
	ClosedTween:Play()
	
	self.Closed:Fire()
	self.Visible = false
end

return AnimatedMenu