--[[
    Customization (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local CustomizationFolder = Modules:WaitForChild("Customization")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local Data = Modules:WaitForChild("Data")
local SettingsFolder = Modules:WaitForChild("Settings")
--local CustomizationGeneral = General:WaitForChild("Customization")
--local CreateFolder = CustomizationGeneral:WaitForChild("Create")

local CustomizationController = require(CustomizationFolder:WaitForChild("CustomizationController"))
local LevelController = require(CustomizationFolder:WaitForChild("LevelController"))
local DataController = require(Data:WaitForChild("DataController"))
local LockedButton = require(script:WaitForChild("LockedButton"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
--local BaseMenu = require(Menus:WaitForChild("Menu"))
local AnimatedMenu = require(Menus:WaitForChild("AnimatedMenu"))
local UI = require(SettingsFolder:WaitForChild("UI"))
--local TrailList = require(SettingsFolder:WaitForChild("Trails"))

local Player = Players.LocalPlayer

local CustomizationFrame = MenuUtil:GetFrame("Customization")
local ContentFrame = CustomizationFrame:WaitForChild("Content")
local ProfileIcon = ContentFrame:WaitForChild("ProfileIcon")
local ProfileName = ProfileIcon:WaitForChild("Name")
local LevelLabel = ContentFrame:WaitForChild("Level")
local XPLabel = ContentFrame:WaitForChild("XP")
local PercentLabel = ContentFrame:WaitForChild("Percentage")
local PercentContainer = ContentFrame:WaitForChild("Bar")
local PercentProgress = PercentContainer:WaitForChild("Progress")
local Customization = ContentFrame:WaitForChild("Customization")
local Pages = Customization:WaitForChild("Pages")
local Tabs = Customization:WaitForChild("Tabs")
local Items = Pages:WaitForChild("Items")

local TypeToButton = {
	Level = "LevelButton",
	User = "UserButton"
}

local function GetButtonClass(Type)
	local Module = TypeToButton[Type]
	if Module then
		local Object = script:FindFirstChild(Module)
		if Object then
			return require(Object)
		end
	end
end

local Customization = setmetatable({}, AnimatedMenu)
Customization.__index = Customization

function Customization.new(Frame)
	local self = setmetatable(AnimatedMenu.new(Frame), Customization)
	
	self.CategoryButtons = {}
	self.LastCategory = ""
	self.LastCategoryButton = nil
	self.LastButton = nil
	self.CategoryEquipped = {}
	task.defer(self.LoadUser)
	
	DataController.XPChanged:Connect(function()
		self:RefreshLevel()
	end)
	
	DataController.LevelChanged:Connect(function()
		self:RefreshLevel()
		self:RefreshButtons()
	end)
	
	for CategoryName, CustomizationItems in pairs(CustomizationController.GetAllItems()) do
		local CurrentCustomization = DataController:GetCustomization(CategoryName)
		local ItemCount = 0
		for ItemName, Data in pairs(CustomizationItems) do
			local ButtonClass = GetButtonClass(Data.Type)
			if ButtonClass then
				ItemCount += 1
				
				local NewButton = ButtonClass.new(Data)
				NewButton:LoadItem()
				NewButton:CreateRender()
				
				NewButton:SetLayoutOrder(
					NewButton:GetLayoutOrder(ItemCount)
				)
				
				if CurrentCustomization == Data.Name then
					self:Equip(NewButton, CategoryName, true)
				end
				
				NewButton.Activated:Connect(function()
					if Data:IsUnlocked(Player) and DataController:GetCustomization(CategoryName) ~= Data.Name then
						self:Equip(NewButton, CategoryName)
					end
				end)
				
				if self.CategoryButtons[CategoryName] then
					table.insert(self.CategoryButtons[CategoryName], NewButton)
				else
					self.CategoryButtons[CategoryName] = {NewButton}
				end
			end
		end
	end
	
	for _, v in pairs(Tabs:GetChildren()) do
		if v:IsA("TextButton") then
			v.Activated:Connect(function()
				if self.LastCategoryButton ~= v then
					self:DisplayCategory(v.Name)
				end
			end)
			
			v.MouseEnter:Connect(function()
				self.SetCategorySelected(v, true)
			end)
			
			v.MouseLeave:Connect(function()
				if v ~= self.LastCategoryButton then
					self.SetCategorySelected(v, false)
				end
			end)
		end
	end
	
	self:DisplayCategory(UI.Customization.DefaultCategory)
	self:RefreshLevel()
	self:RefreshButtons()
	--for Name, _ in pairs(TrailList) do
	--	local Button = TrailButton.new(Name)
	--	Button:SetParent(Scroll)

	--	local CreateFunction = CreateFolder:FindFirstChild(Name)
	--	if CreateFunction then
	--		require(CreateFunction)(Button.Texture)
	--	end

	--	if Button.Trail == DataController:GetTrail() then
	--		TrailController:Equip(Button)
	--	end

	--	table.insert(self.Buttons, Button)
	--end
	
	return self
end

function Customization:RefreshButtons()
	for _, v in pairs(self.CategoryButtons) do
		for _, Button in pairs(v) do
			local Item = Button.Item
			if Item then
				local Unlocked = Item:IsUnlocked(Player)
				
				Button:SetLocked(not Unlocked)
			end
		end
	end
end

function Customization:Equip(Button, Category, InitialSet)
	local Item = Button.Item
	if Item and Category then
		local LastButton = self.CategoryEquipped[Category]
		if LastButton then
			LastButton:SetEquipped(false)
		end
		
		if not InitialSet then
			DataController:SetCustomization(Category, Item.Name)
		end
		
		Button:SetEquipped(true)
		
		self.CategoryEquipped[Category] = Button
	end
end

function Customization:DisplayCategory(Category)
	local LastCategory = self.CategoryButtons[self.LastCategory]
	if LastCategory then
		for _, v in pairs(LastCategory) do
			v:SetParent(nil)
		end
	end
	
	Items.CanvasPosition = Vector2.zero
	
	local Buttons = self.CategoryButtons[Category]
	if Buttons then
		for _, v in pairs(Buttons) do
			local Item = v.Item
			if Item and not Item:IsVisible(Player) then
				continue
			end
			
			v:SetParent(Items)
		end
		
		self.LastCategory = Category
	end
	
	local TabButton = Tabs:FindFirstChild(Category)
	if TabButton then
		self.SetCategorySelected(TabButton, true)
		
		if self.LastCategoryButton then
			self.SetCategorySelected(self.LastCategoryButton, false)
		end
		
		self.LastCategoryButton = TabButton
	end
end

function Customization:LoadUser()
	ProfileName.Text = Player.DisplayName
	ProfileIcon.Image = Players:GetUserThumbnailAsync(
		Player.UserId,
		Enum.ThumbnailType.HeadShot,
		Enum.ThumbnailSize.Size352x352
	)
end

function Customization.SetCategorySelected(Button, Selected)
	if Button then
		local Color = UI.Customization.CategoryUnselected
		
		if Selected then
			Color = UI.Customization.CategorySelected
		end
		
		Button.BackgroundColor3 = Color
		
		for _, v in pairs(Button:GetChildren()) do
			if v:IsA("Frame") and v.Name == "Color" then
				v.BackgroundColor3 = Color
			end
		end
	end
end

function Customization:IsMaxLevel()
	return DataController:GetLevel() >= LevelController:GetMaxLevel()
end

function Customization:RefreshLevel()
	local Level = DataController:GetLevel()
	local XP = DataController:GetXP()
	local XPToLevel = LevelController:GetXPToLevel(DataController:GetLevel())
	
	local Percent = math.clamp(XP / XPToLevel, 0, 1)
	
	if self:IsMaxLevel() then
		Percent = 1
		XPLabel.Text = "MAX LVL"
	else
		XPLabel.Text = string.format("%s/%s", XP, XPToLevel)
	end
	
	LevelLabel.Text = string.format("LVL %s", Level)
	PercentLabel.Text = string.format("%s%%", math.floor(Percent * 100))
	PercentProgress.Size = UDim2.fromScale(Percent, 1)
end

--function Customization:IsTrailUnlocked(Name)
--	local TrailData = TrailList[Name]
--	if TrailData then
--		local Level = DataController:GetLevel()
		
--		return Level >= TrailData.Level
--	end
--end

--function Customization:DisplayCategory(Category)
--	local CategoryButton = Tabs:FindFirstChild(Category)
--	if CategoryButton then
--		if self.LastButton then
--			self.SetCategorySelected(self.LastButton, false)
--		end
		
--		self.SetCategorySelected(CategoryButton, true)
		
--		Items.CanvasPosition = Vector2.zero
		
--		local LastButtons = self.CategoryButtons[self.LastCategory]
--		if LastButtons then
--			for _, v in pairs(LastButtons) do
--				v:SetParent(nil)
--			end
--		end
		
--		local CurrentButtons = self.CategoryButtons[Category]
--		if CurrentButtons then
--			for _, v in pairs(CurrentButtons) do
--				v:SetParent(Items)
--			end
--		end
		
--		self.LastCategory = Category
--		self.LastButton = CategoryButton
--	end
--end

local singleton

singleton = Customization.new(CustomizationFrame)

return singleton