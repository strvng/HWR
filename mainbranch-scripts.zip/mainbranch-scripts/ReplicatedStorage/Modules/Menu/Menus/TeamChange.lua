--[[
    TeamChange (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local Teams = game:GetService("Teams")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local Settings = Modules:WaitForChild("Settings")
local Utilities = Modules:WaitForChild("Utilities")

local MenuUtil = require(General:WaitForChild("MenuUtil"))
local AnimatedMenu = require(Menus:WaitForChild("AnimatedMenu"))
local TeamColor = require(Settings:WaitForChild("TeamColor"))
local JoinFrame = require(script:WaitForChild("JoinFrame"))
local GetDictionaryLength = require(Utilities:WaitForChild("GetDictionaryLength"))
local RequestData = Remotes:WaitForChild("RequestData")
local UI = require(Settings:WaitForChild("UI"))
local MenuController = require(MenuFolder:WaitForChild("MenuController"))

local TeamChangeFrame = MenuUtil:GetFrame("TeamChange")
local ContentFrame = TeamChangeFrame:WaitForChild("Content")
local TeamContainer = ContentFrame:WaitForChild("TeamContainer")
local NoTeams = ContentFrame:WaitForChild("NoTeams")

local StatusCodes = UI.TeamChange.StatusCodes

local TeamChange = setmetatable({}, AnimatedMenu)
TeamChange.__index = TeamChange

function TeamChange.new(Frame)
	local self = setmetatable(AnimatedMenu.new(Frame), TeamChange)
	
	self.JoinFrames = {}
	
	for _, v in pairs(Teams:GetTeams()) do
		self:TeamAdded(v)
	end
	
	Teams.ChildAdded:Connect(function(Team)
		if Team:IsA("Team") then
			self:TeamAdded(Team)
		end
	end)
	
	Teams.ChildRemoved:Connect(function(Team)
		if Team:IsA("Team") then
			self:TeamRemoved(Team)
		end
	end)
	
	return self
end

function TeamChange:GetFrameCount()
	return GetDictionaryLength(self.JoinFrames)
end

function TeamChange:TeamsChanged()
	local FrameCount = self:GetFrameCount()
	if FrameCount<= 0 then
		NoTeams.Visible = true
	else
		NoTeams.Visible = false
		
		for _, v in pairs(self.JoinFrames) do
			v.Frame:SetXSize(1 / FrameCount)
		end
	end
end

function TeamChange:TeamAdded(Team)
	local NewJoinFrame = JoinFrame.new()
	local TeamName = Team.Name
	local Colors = TeamColor[TeamName]
	
	if Colors then
		NewJoinFrame:SetTeamColor(Colors.Primary)
		NewJoinFrame:SetVehicleColor(Colors.VehicleColor)
	end
	
	-- NewJoinFrame.Activated
	-- connect teams and update player count
	local MaxPlayers = Players.MaxPlayers
	
	NewJoinFrame:SetPlayerCountMax(MaxPlayers)
	NewJoinFrame:SetTeamName(TeamName)
	
	local Activated
	local PlayerAdded
	local PlayerRemoved
	
	local function PlayerCountChanged(Player)
		if Team.Parent == Teams then
			NewJoinFrame:SetPlayerCount(
				#Team:GetPlayers()
			)
		end
	end
	
	Activated = NewJoinFrame.Activated:Connect(function()
		local Status = RequestData:InvokeServer("JoinTeam", TeamName)
		if Status == StatusCodes.Success then
			NewJoinFrame:ShowStatus("Success!")
			
			if MenuController.ActiveMenu == self then
				MenuController:HideActiveMenu()
			end
		elseif Status == StatusCodes.Unbalanced then
			NewJoinFrame:ShowStatus("Full!")
		elseif Status == StatusCodes.Full then
			NewJoinFrame:ShowStatus("Full!")
		end
	end)
	
	PlayerAdded = Team.PlayerAdded:Connect(PlayerCountChanged)
	PlayerRemoved = Team.PlayerRemoved:Connect(PlayerCountChanged)
	
	self.JoinFrames[Team] = {
		Frame = NewJoinFrame,
		PlayerAdded = PlayerAdded,
		PlayerRemoved = PlayerRemoved
	}
	--table.insert(self.JoinFrames, NewJoinFrame)
	
	self:TeamsChanged()
	PlayerCountChanged()
	
	local LayoutOrder = Team:GetAttribute("LayoutOrder")
	if LayoutOrder then
		NewJoinFrame:SetLayoutOrder(LayoutOrder)
	end
	
	NewJoinFrame:SetParent(TeamContainer)
end

function TeamChange:TeamRemoved(Team)
	local Frame = self.JoinFrames[Team]
	if Frame then
		Frame.PlayerAdded:Disconnect()
		Frame.PlayerRemoved:Disconnect()
		
		if Frame.Frame then
			Frame.Frame:Destroy()
		end
		
		table.clear(Frame)
	end
	
	self.JoinFrames[Team] = nil
	
	self:TeamsChanged()
end

local singleton

singleton = TeamChange.new(TeamChangeFrame)

return singleton