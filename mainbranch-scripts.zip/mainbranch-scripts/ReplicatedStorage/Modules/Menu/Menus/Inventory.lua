--[[
    Inventory (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Utilities = Modules:WaitForChild("Utilities")
local Tools = Modules:WaitForChild("Tools")
local Menu = Modules:WaitForChild("Menu")
local Settings = Modules:WaitForChild("Settings")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local General = Menu:WaitForChild("General")
local InventoryGeneral  = General:WaitForChild("Inventory")

local UploadData = Remotes:WaitForChild("UploadData")
local GamepassController = require(GamepassFolder:WaitForChild("GamepassController"))
local MenuController = require(Menu:WaitForChild("MenuController"))
local Satchel = require(Tools:WaitForChild("Satchel"))
local Signal = require(Utilities:WaitForChild("Signal"))
local ToolOrder = require(InventoryGeneral:WaitForChild("ToolOrder"))
--local DefaultTools = require(Settings:WaitForChild("DefaultTools"))
--local VipTools = require(Settings:WaitForChild("VipTools"))
local Vip = require(Settings:WaitForChild("Vip"))

local InputConnection

local Inventory = {}
Inventory.__index = Inventory

local function IsSaveable(Tool, IsVip)
	local ToolName = Tool.Name
	
	if not Tool:GetAttribute("LayoutOrder") then
		return false
	end
	
	if IsVip and ToolOrder.VipTools[ToolName] then
		return true
	end
	
	for _, v in pairs(ToolOrder.DefaultTools) do
		if v.Name == ToolName then
			return true
		end
	end
end

function Inventory.ParseSlotData(Slots)
	local IsVip = GamepassController:IsGamepassOwned(Vip.VIPGamepassID)
	local Data = {}
	local HotbarSlots = Satchel:GetNumberOfHotbarSlots()
	local ToolsToSave = ToolOrder.GetToolsToSave(IsVip)
	
	for _, v in pairs(Slots) do
		local Tool = v.Tool
		local Index = v.Index
		if Tool and Index and IsSaveable(Tool, IsVip) and ToolOrder.GetToolFromSort(ToolsToSave, Tool.Name) and not ToolOrder.GetToolFromSort(Data, Tool.Name) then
			local Slot = Tool:GetAttribute("LayoutOrder")
			if Slot > HotbarSlots then
				Slot = -1
			end
			
			table.insert(
				Data,
				{
					Name = Tool.Name,
					Slot = Slot
				}
			)
		end
	end
	
	return Data
end

Satchel.InventoryOrderChanged.Event:Connect(function(Slots)
	local OwnsSortGamepass = GamepassController:IsGamepassOwned(Vip.SortGamepassId)
	if Slots and OwnsSortGamepass then
		local SaveData = Inventory.ParseSlotData(Slots)
		if SaveData then
			UploadData:FireServer("SetInventory", SaveData)
		end
	end
end)

Satchel.ResetOrder.Event:Connect(function()
	local OwnsSortGamepass = GamepassController:IsGamepassOwned(Vip.SortGamepassId)
	if OwnsSortGamepass then
		local IsVip = GamepassController:IsGamepassOwned(Vip.VIPGamepassID)
		local ToolsToSave = ToolOrder.GetToolsToSave(IsVip)
		if ToolsToSave then
			UploadData:FireServer("SetInventory", ToolsToSave)
			Satchel.DoResetAnimation()
		end
	end
end)

function Inventory.new()
	local self = setmetatable({}, Inventory)
	
	self.Visible = false
	self.Opened = Signal.new()
	self.Closed = Signal.new()
	
	return self
end

function Inventory:Show()
	if not Satchel:IsOpened() then
		Satchel.OpenClose()
	end
	
	local OwnsSortGamepass = GamepassController:IsGamepassOwned(Vip.SortGamepassId)
	if OwnsSortGamepass then
		Satchel.SetResetButtonVisible(true)
	end
	
	self.Opened:Fire()
	self.Visible = true
end

function Inventory:Hide()
	if Satchel:IsOpened() then
		Satchel.OpenClose()
	end
	
	self.Closed:Fire()
	self.Visible = false
end

return Inventory.new()