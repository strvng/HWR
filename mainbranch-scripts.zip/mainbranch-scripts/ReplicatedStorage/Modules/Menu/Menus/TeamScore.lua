--[[
    TeamScore (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Teams = game:GetService("Teams")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local SettingsFolder = Modules:WaitForChild("Settings")
local Menu = Modules:WaitForChild("Menu")
local Menus = Menu:WaitForChild("Menus")
local General = Menu:WaitForChild("General")
local Utilities = Modules:WaitForChild("Utilities")

local GetDictionaryLength = require(Utilities:WaitForChild("GetDictionaryLength"))
local TeamClass = require(script:WaitForChild("Team"))
local BaseMenu = require(Menus:WaitForChild("Menu"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local UI = require(SettingsFolder:WaitForChild("UI"))
local Signal = require(Utilities:WaitForChild("Signal"))

local Camera = workspace.CurrentCamera

local TeamScoreFrame = MenuUtil:GetFrame("TeamScore")
local TeamContainerFrame = TeamScoreFrame:WaitForChild("TeamContainer")
local ButtonsFrame = MenuUtil:GetFrame("Buttons")

local TeamScore = setmetatable({}, BaseMenu)
TeamScore.__index = TeamScore

function TeamScore.new(Frame)
	local self = setmetatable(BaseMenu.new(Frame), TeamScore)
	
	RunService.RenderStepped:Connect(function()
		self:CheckBounds()
	end)
	
	self:CheckBounds()
	self.Teams = {}
	
	Teams.ChildAdded:Connect(function(Team)
		if Team:IsA("Team") then
			self:TeamAdded(Team)
		end
	end)
	
	Teams.ChildRemoved:Connect(function(Team)
		if Team:IsA("Team") then
			self:TeamRemoved(Team)
		end
	end)
	
	for _, v in pairs(Teams:GetTeams()) do
		self:TeamAdded(v)
	end
	
	local ShowingTween = TweenService:Create(
		TeamContainerFrame,
		UI.TeamScore.DownTweenInfo,
		{
			Position = UI.TeamScore.ShowingPosition
		}
	)
	
	local HiddenTween = TweenService:Create(
		TeamContainerFrame,
		UI.TeamScore.UpTweenInfo,
		{
			Position = UI.TeamScore.HiddenPosition
		}
	)
	
	ShowingTween.Completed:Connect(function(PlaybackState)
		if PlaybackState == Enum.PlaybackState.Completed then
			self.FullyOpened:Fire()
			self.Animated = false
		end
	end)
	
	HiddenTween.Completed:Connect(function(PlaybackState)
		if PlaybackState == Enum.PlaybackState.Completed then
			self.FullyClosed:Fire()
			BaseMenu.Hide(self)
			self.Animated = false
		end
	end)
	
	self.HiddenTween = HiddenTween
	self.ShowingTween = ShowingTween
	self.FullyOpened = Signal.new()
	self.FullyClosed = Signal.new()
	
	self:Show()
	
	return self
end

function TeamScore:WaitForTeams()
	local Team = Teams.ChildAdded:Wait()
	-- debug
	if Team:IsA("Team") then
		if not Team:GetAttribute("Score") then
			warn(string.format("Team %s was parented without score attribute", Team.Name))
		end
	end
	
	if Team:IsA("Team") and Team:GetAttribute("Score") then
		self:Show()
	else
		self:WaitForTeams()
	end
end

function TeamScore:Show()
	local ShowingTween = self.ShowingTween
	if ShowingTween then
		BaseMenu.Show(self)
		ShowingTween:Play()
	end
end

function TeamScore:Hide()
	local HiddenTween = self.HiddenTween
	if HiddenTween then
		HiddenTween:Play()
	end
end

function TeamScore:GetPointsToWin()
	return Teams:GetAttribute("PointsToWin")
end

local function NewTrack(Bar, Label, Number)
	local Track = TweenService:Create(
		Bar,
		UI.TeamScore.ScoreChanged,
		{
			Size = UDim2.fromScale(math.clamp(Number / UI.TeamScore.PointsToWin, 0, 1), 1)
		}
	)
	
	Label.Text = tostring(Number)
	
	return Track
end

function TeamScore:CheckBounds()
	if self.Visible then
		local CameraSizeX = Camera.ViewportSize.X
		if CameraSizeX <= UI.TeamScore.SquishSize then
			self:CalculateSquishSize()
			-- Squishes
			self.IsDown = false
		elseif CameraSizeX < UI.TeamScore.MediaSize and CameraSizeX > UI.TeamScore.SquishSize and not self.IsDown then
			self:Down()
			-- Moves with the main menu buttons
		elseif CameraSizeX >= UI.TeamScore.MediaSize then
			self:Up()
			-- Centered and not moving with anything
		end
	end
end

function TeamScore:Up()
	TeamScoreFrame.AnchorPoint = UI.TeamScore.UpAnchorPoint
	TeamScoreFrame.Position = UI.TeamScore.UpPosition
	TeamScoreFrame.Size = UI.TeamScore.UpSize
	self.IsDown = false
end

function TeamScore:Down()
	TeamScoreFrame.AnchorPoint = UI.TeamScore.DownAnchorPoint
	TeamScoreFrame.Position = UI.TeamScore.DownPosition
	TeamScoreFrame.Size = UI.TeamScore.DownSize
	self.IsDown = true
end

function TeamScore:CalculateSquishSize()
	local ButtonsPosition = ButtonsFrame.AbsolutePosition
	
	TeamScoreFrame.AnchorPoint = UI.TeamScore.SquishAnchorPoint
	TeamScoreFrame.Position = UI.TeamScore.SquishPosition
	
	local Size = ButtonsPosition.X - UI.TeamScore.SquishPosition.X.Offset
	local IntendedSize = Size - UI.TeamScore.SquishXPadding
	
	if Size <= 0 then
		TeamScoreFrame.Visible = false
	else
		TeamScoreFrame.Visible = true
	end
	
	if IntendedSize <= 0 then
		IntendedSize = Size
	end
	
	TeamScoreFrame.Size = UDim2.fromOffset(
		IntendedSize,
		UI.TeamScore.YSizeOffset
	)
end

function TeamScore:ClearTeams()
	for _, v in pairs(self.Teams) do
		v:Destroy()
	end
	
	table.clear(self.Teams)
end

local function SortByLayoutOrderAscending(a, b)
	return a:GetLayoutOrder() < b:GetLayoutOrder()
end

local function OrderedTeamTable(Teams)
	local Data = {}
	
	for _, v in pairs(Teams) do
		table.insert(Data, v)
	end
	
	table.sort(Data, SortByLayoutOrderAscending)
	
	return Data
end

function TeamScore:RescaleTeams()
	local TeamClasses = self.Teams
	if TeamClasses then
		local TeamTable = OrderedTeamTable(TeamClasses)
		local TeamCount = #TeamTable
		local XSize = (1 / TeamCount) - UI.TeamScore.SizeXPaddingPercent
		
		for i, v in pairs(TeamTable) do
			local Alignment = ((i % 2) == 0 and Enum.TextXAlignment.Left) or Enum.TextXAlignment.Right
			v:SetAlignment(Alignment)
			v:SetXSize(XSize)
		end
	end
end

function TeamScore:TeamAdded(Team)
	local CurrentTeams = Teams:GetTeams()
	local TeamCount = #CurrentTeams
	
	local Primary = Team:GetAttribute("Primary")
	local Secondary = Team:GetAttribute("Secondary")
	local Score = Team:GetAttribute("Score")
	local LayoutOrder = Team:GetAttribute("LayoutOrder")
	local ScoreOutline = Team:GetAttribute("ScoreOutline")
	if Primary and Secondary and Score then
		local NewTeamClass = TeamClass.new(self)
		NewTeamClass:SetColors(Primary, Secondary)
		NewTeamClass:SetScore(Score)
		
		if LayoutOrder then
			NewTeamClass:SetLayoutOrder(LayoutOrder)
		end
		
		if ScoreOutline then
			NewTeamClass:SetScoreOutlineVisible(true)
		end
		
		Team:GetAttributeChangedSignal("Score"):Connect(function()
			local Score = Team:GetAttribute("Score")
			if Score then
				NewTeamClass:SetScore(
					Score
				)
			end
		end)
		
		self.Teams[Team] = NewTeamClass
		self:RescaleTeams()
		
		NewTeamClass:SetParent(TeamContainerFrame)
	end
end

function TeamScore:TeamRemoved(Team)
	local TeamClass = self.Teams[Team]
	if TeamClass then
		TeamClass:Destroy()
	end
	
	self.Teams[Team] = nil
	
	self:RescaleTeams()
end

--function TeamScore:GetTeam(Name)
--	return self.Teams[Name]
--end

--function TeamScore:SetPointsToWin(PointsToWin)
--	self.PointsToWin = PointsToWin
--end

--function TeamScore:ClearTeams()
--	for _, v in pairs(self.Teams) do
--		v:Destroy()
--	end
	
--	table.clear(self.Teams)
--end

--function TeamScore:UpdateScore(TeamData)
--	for _, Data in pairs(TeamData) do
--		local Team = self:GetTeam(Data.Name)
--		if Team then
--			Team:SetScore(Data.Score)
--		end
--	end
--end

--function TeamScore:SetTeams(Teams)
--	self:ClearTeams()
	
--	local TeamCount = #Teams
--	local XSize = (1 / TeamCount) - UI.TeamScore.SizeXPaddingPercent
	
--	for i, TeamData in ipairs(Teams) do
--		local Alignment = ((i % 2) == 0 and Enum.TextXAlignment.Left) or Enum.TextXAlignment.Right
		
--		local NewTeamClass = TeamClass.new(self)
--		NewTeamClass:SetColors(TeamData.Primary, TeamData.Secondary)
--		NewTeamClass:SetScore(TeamData.Score)
--		NewTeamClass:SetXSize(XSize)
--		NewTeamClass:SetAlignment(Alignment)
--		NewTeamClass:SetParent(TeamScoreFrame)
		
--		self.Teams[TeamData.Name] = NewTeamClass
--	end
--end

local singleton

singleton = TeamScore.new(TeamScoreFrame)

return singleton