--[[
    Item (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → Shop
    Parent: Shop
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local MarketplaceService = game:GetService("MarketplaceService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local General = MenuFolder:WaitForChild("General")
local SettingsFolder = Modules:WaitForChild("Settings")
local ShopGeneral = General:WaitForChild("Shop")
local GamepassFolder = Modules:WaitForChild("Gamepass")

local GamepassController = require(GamepassFolder:WaitForChild("GamepassController"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local CanBuyXP = require(ShopGeneral:WaitForChild("CanBuyXP"))
local UI = require(SettingsFolder:WaitForChild("UI"))

local Player = Players.LocalPlayer
local ItemTemplate = MenuUtil:GetTemplate("ShopItem")

local Item = {}
Item.__index = Item

function Item.new(Name, Price, ImageId, Id, LayoutOrder, IsDevProduct)
	local self = setmetatable({}, Item)
	
	local ItemFrame = ItemTemplate:Clone()
	local Overlay = ItemFrame:WaitForChild("Overlay")
	local NameLabel = ItemFrame:WaitForChild("Name")
	local Icon = ItemFrame:WaitForChild("Icon")
	local PriceLabel = Icon:WaitForChild("Price")
	local WasPurchased = ItemFrame:WaitForChild("Purchased")
	
	PriceLabel.Text = Price
	NameLabel.Text = Name
	ItemFrame.Image = ImageId
	ItemFrame.LayoutOrder = LayoutOrder
	
	if GamepassController:IsGamepassOwned(Id) then
		WasPurchased.Visible = true
		Overlay.ImageTransparency = UI.Shop.OverlayTransparency
	else
		local OverlayOnTrack = TweenService:Create(
			Overlay,
			UI.Shop.OverlayOn,
			{
				ImageTransparency = UI.Shop.OverlayTransparency
			}
		)

		local OverlayOffTrack = TweenService:Create(
			Overlay,
			UI.Shop.OverlayOff,
			{
				ImageTransparency = 1
			}
		)
		
		ItemFrame.MouseEnter:Connect(function()
			OverlayOnTrack:Cancel()
			OverlayOnTrack:Play()
		end)
		
		ItemFrame.MouseLeave:Connect(function()
			OverlayOffTrack:Cancel()
			OverlayOffTrack:Play()
		end)
		
		ItemFrame.Activated:Connect(function()
			if IsDevProduct and CanBuyXP() then
				MarketplaceService:PromptProductPurchase(Player, Id)
			else
				MarketplaceService:PromptGamePassPurchase(Player, Id)
			end
		end)
	end
	
	self.Frame = ItemFrame
	
	return self
end

function Item:SetParent(Parent)
	self.Frame.Parent = Parent
end

return Item