--[[
    Button (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → Customization
    Parent: Customization
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Menu = Modules:WaitForChild("Menu")
local Utilities = Modules:WaitForChild("Utilities")
local General = Menu:WaitForChild("General")

local MenuUtil = require(General:WaitForChild("MenuUtil"))
local Signal = require(Utilities:WaitForChild("Signal"))

local Button = {}
Button.__index = Button
Button.MenuUtil = MenuUtil

function Button.new(Item)
	local self = setmetatable({}, Button)
	
	self.Item = Item
	self.Activated = Signal.new()
	
	return self
end

function Button:GetLayoutOrder()
	return 0
end

function Button:SetLayoutOrder(Order)
	local Template = self.Template
	if Template then
		Template.LayoutOrder = Order
	end
end

function Button:CreateRender()
	local Item = self.Item
	if Item then
		local Container = self.Texture
		if Container then
			Item:Render(Container)
		end
	end
end

function Button:SetEquipped(Equipped)
	
end

function Button:SetLocked(Locked)
	
end

function Button:SetVisible(Visible)
	local Template = self.Template
	if Template then
		Template.Visible = Visible
	end
end

function Button:SetParent(Parent)
	local Template = self.Template
	if Template then
		Template.Parent = Parent
	end
end

return Button