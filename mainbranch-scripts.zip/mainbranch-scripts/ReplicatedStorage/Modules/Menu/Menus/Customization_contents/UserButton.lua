--[[
    UserButton (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → Customization
    Parent: Customization
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local LockedButton = require("./LockedButton")

local UserButton = {}
UserButton.__index = setmetatable(UserButton, LockedButton)

local LayoutOrderOffset = 100

function UserButton.new(Item)
	local self = setmetatable(LockedButton.new(Item), UserButton)
	
	return self
end

function UserButton:GetLayoutOrder(ItemCount)
	local Item = self.Item
	if Item then
		return LayoutOrderOffset + ItemCount
	end
end

return UserButton