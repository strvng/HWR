--[[
    LockedButton (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → Customization
    Parent: Customization
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local BaseButton = require("./Button")

local Prefab = BaseButton.MenuUtil:GetTemplate("ButtonTemplate")

local LockedButton = {}
LockedButton.__index = setmetatable(LockedButton, BaseButton)

function LockedButton.new(Item)
	local self = setmetatable(BaseButton.new(Item), LockedButton)
	
	local Template = Prefab:Clone()
	local Texture = Template:WaitForChild("Texture")
	local Equipped = Texture:WaitForChild("Equipped")
	local LevelRequirement = Texture:WaitForChild("LevelRequirement")
	local Locked = Texture:WaitForChild("Locked")
	local NameLabel = Texture:WaitForChild("Name")
	local UIStroke = Texture:WaitForChild("UIStroke")
	
	self.Template = Template
	self.Texture = Texture
	self.EquippedLabel = Equipped
	self.Requirement = LevelRequirement
	self.LockedLabel = Locked
	self.NameLabel = NameLabel
	self.UIStroke = UIStroke
	
	Template.Activated:Connect(function()
		self.Activated:Fire()
	end)
	
	return self
end

function LockedButton:LoadItem()
	local Item = self.Item
	local NameLabel = self.NameLabel
	if Item and NameLabel then
		local Name = Item.Name
		
		assert(Name)
		
		NameLabel.Text = Item:GetName()
	end
end

function LockedButton:SetEquipped(Equipped)
	local EquippedLabel = self.EquippedLabel
	local UIStroke = self.UIStroke
	if EquippedLabel and UIStroke then
		if Equipped then
			EquippedLabel.Visible = true
			UIStroke.Color = Color3.fromRGB(255, 255, 255)
		else
			EquippedLabel.Visible = false
			UIStroke.Color = Color3.fromRGB(0, 0, 0)
		end
	end
end

function LockedButton:SetLocked(Locked)
	local Requirement = self.Requirement
	local LockedLabel = self.LockedLabel
	if Requirement and LockedLabel then
		LockedLabel.Visible = Locked
		Requirement.Visible = Locked
	end
end

return LockedButton