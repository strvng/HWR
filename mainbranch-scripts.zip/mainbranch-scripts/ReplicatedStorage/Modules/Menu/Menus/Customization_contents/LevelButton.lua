--[[
    LevelButton (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → Customization
    Parent: Customization
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local LockedButton = require("./LockedButton")

local LevelButton = {}
LevelButton.__index = setmetatable(LevelButton, LockedButton)

function LevelButton.new(Item)
	local self = setmetatable(LockedButton.new(Item), LevelButton)
	
	assert(Item.Level)
	
	self.Level = Item.Level
	
	return self
end

function LevelButton:GetLayoutOrder()
	return self.Level
end

function LevelButton:LoadItem()
	LockedButton.LoadItem(self)
	
	local Item = self.Item
	local Requirement = self.Requirement
	local Template = self.Template
	if Item and Requirement and Template then
		local Level = Item.Level
		
		assert(Level)
		
		Requirement.Text = string.format("Level %s", Level)
		Template.LayoutOrder = Item.Level
	end
end

return LevelButton