--[[
    Team (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus → TeamScore
    Parent: TeamScore
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Settings = Modules:WaitForChild("Settings")
local Menu = Modules:WaitForChild("Menu")
local Templates = Menu:WaitForChild("Templates")

local TeamTemplate = Templates:WaitForChild("TeamTemplate")

local UI = require(Settings:WaitForChild("UI"))

local Team = {}
Team.__index = Team

function Team.new(TeamScore)
	local self = setmetatable({}, Team)
	
	local NewTemplate = TeamTemplate:Clone()
	local ScoreText = NewTemplate:WaitForChild("Score")
	local ProgressBar = NewTemplate:WaitForChild("Bar")
	local UIStroke = NewTemplate:WaitForChild("UIStroke")
	local ScoreOutline = ScoreText:WaitForChild("UIStroke")
	
	self.Frame = NewTemplate
	self.ScoreText = ScoreText
	self.ProgressBar = ProgressBar
	self.UIStroke = UIStroke
	self.TeamScore = TeamScore
	self.ScoreOutline = ScoreOutline
	
	return self
end

--function Team.GetSecondaryColor(Color)
--	return Color3.new(
--		Color.R * UI.TeamScore.SecondaryColorPercentage.R,
--		Color.G * UI.TeamScore.SecondaryColorPercentage.G,
--		Color.B * UI.TeamScore.SecondaryColorPercentage.B
--	)
--end

function Team:SetScoreOutlineVisible(Visible)
	local ScoreOutline = self.ScoreOutline
	if ScoreOutline then
		ScoreOutline.Enabled = Visible
	end
end

function Team:SetAlignment(Alignment)
	local ScoreText = self.ScoreText
	if ScoreText then
		ScoreText.TextXAlignment = Alignment
	end
end

function Team:SetXSize(XSize)
	local Frame = self.Frame
	if Frame then
		Frame.Size = UDim2.new(XSize, 0, UI.TeamScore.YSize, 0)
	end
end

function Team:SetColors(Primary, Secondary)
	local Frame = self.Frame
	local ProgressBar = self.ProgressBar
	local UIStroke = self.UIStroke
	if Frame and ProgressBar and UIStroke then
		Frame.BackgroundColor3 = Primary
		ProgressBar.BackgroundColor3 = Secondary
		UIStroke.Color = Primary
	end
end

function Team:SetScore(Score)
	local ScoreText = self.ScoreText
	local TeamScore = self.TeamScore
	local ProgressBar = self.ProgressBar
	if ProgressBar and ScoreText and typeof(Score) == "number" and TeamScore then
		ScoreText.Text = tostring(Score)
		
		if self.SizeTween then
			self.SizeTween:Cancel()
			self.SizeTween = nil
		end
		
		local XSize = math.clamp(Score / TeamScore:GetPointsToWin(), 0, 1)
		
		local NewTween = TweenService:Create(
			ProgressBar,
			UI.TeamScore.ScoreChanged,
			{
				Size = UDim2.fromScale(XSize, 1)
			}
		)
		
		NewTween:Play()
		
		self.SizeTween = NewTween
	end
end

function Team:SetLayoutOrder(LayoutOrder)
	local Frame = self.Frame
	if Frame then
		Frame.LayoutOrder = LayoutOrder
	end
end

function Team:GetLayoutOrder(LayoutOrder)
	local Frame = self.Frame
	if Frame then
		return Frame.LayoutOrder
	end
end

function Team:SetParent(Parent)
	local Frame = self.Frame
	if Frame then
		Frame.Parent = Parent
	end
end

function Team:Destroy()
	local Frame = self.Frame
	if Frame then
		Frame:Destroy()
	end
end

return Team