--[[
    XPDifference (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local General = MenuFolder:WaitForChild("General")
local Settings = Modules:WaitForChild("Settings")
local Data = Modules:WaitForChild("Data")
local Customization = Modules:WaitForChild("Customization")

local LevelController = require(Customization:WaitForChild("LevelController"))
local DataController = require(Data:WaitForChild("DataController"))
local MenuUtil = require(General:WaitForChild("MenuUtil"))
local AnimatedMenu = require(Menus:WaitForChild("AnimatedMenu"))
local UI = require(Settings:WaitForChild("UI"))

local XPFrame = MenuUtil:GetFrame("XPDifference")
local DifferenceFrame = XPFrame:WaitForChild("Difference")
local XPBar = DifferenceFrame:WaitForChild("Bar")
local XPProgress = XPBar:WaitForChild("Progress")
local Percentage = DifferenceFrame:WaitForChild("Percentage")
local XPDifferenceLabel = DifferenceFrame:WaitForChild("XP")
local LevelLabel = DifferenceFrame:WaitForChild("Level")
local CloseButton = XPFrame:WaitForChild("Close")

local XPDifference = setmetatable({}, AnimatedMenu)
XPDifference.__index = XPDifference

function XPDifference.new()
	local self = setmetatable(AnimatedMenu.new(XPFrame), XPDifference)
	
	local XPChange = Instance.new("NumberValue")
	
	XPChange:GetPropertyChangedSignal("Value"):Connect(function()
		if self.XPLevelRender then
			local Percent = math.clamp(XPChange.Value / self.XPLevelRender, 0, 1)
			
			XPProgress.Size = UDim2.fromScale(Percent, 1)
			
			XPDifferenceLabel.Text = string.format(
				"%s/%s XP",
				tostring(
					math.floor(XPChange.Value)
				),
				tostring(self.XPLevelRender)
			)
			Percentage.Text = string.format(
				"%s%%",
				tostring(
					math.floor(Percent * 100)
				)
			)
		end
	end)
	
	self.XPChange = XPChange
	
	CloseButton.Activated:Connect(function()
		self:Hide()
	end)
	
	return self
end

function XPDifference:PlayLevelUp(Level)
	local XPToLevel = LevelController:GetXPToLevel(Level)
	if XPToLevel then
		self.XPLevelRender = XPToLevel
		
		local UpdateTween = TweenService:Create(
			self.XPChange,
			UI.XP.QuickLevel,
			{
				Value = XPToLevel
			}
		)
		
		UpdateTween:Play()
		UpdateTween.Completed:Wait()
	end
end

local function SetLevelLabel(Level)
	LevelLabel.Text = string.format("LVL %s", Level)
end

function XPDifference:PlayAnimation(StartXP, CurrentXP)
	
	-- start at current xp
	-- if leveled up, tween to max xp
	-- then play tween to current xp
	--
	local LevelDifference = CurrentXP.Level - StartXP.Level
	if LevelDifference >= 1 then
		-- for loop tween levels
		self.XPChange.Value = StartXP.XP
		SetLevelLabel(StartXP.Level)
		
		for i = StartXP.Level+1, CurrentXP.Level do
			self:PlayLevelUp(i)
			SetLevelLabel(i)
			self.XPChange.Value = 0
		end
		
		-- tween to current xp
	else
		-- tween to current xp
	end
	
	local CurrentLevel = CurrentXP.Level
	local XPToLevel = LevelController:GetXPToLevel(CurrentLevel)
	if XPToLevel then
		self.XPLevelRender = XPToLevel
		
		local UpdateTween = TweenService:Create(
			self.XPChange,
			UI.XP.LastLevel,
			{
				Value = CurrentXP.XP
			}
		)
		
		UpdateTween:Play()
	end
	
	--local LevelMaxXP = GetMaxXP(Level)
	
	--XPChange.Value = Start
	
	--if LevelMaxXP then
	--	self.MaxXP = LevelMaxXP
		
	--	local UpdateTween = TweenService:Create(
	--		XPChange,
	--		UI.XP.XPChange,
	--		{
	--			Value = DataController:GetXP()
	--		}
	--	)
		
	--	UpdateTween:Play()
	--end
end


return XPDifference.new()