--[[
    ActiveTouchGui (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu → Menus
    Parent: Menus
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Platform = Modules:WaitForChild("Platform")
local Vehicle = Modules:WaitForChild("Vehicle")
--local Input = Vehicle:WaitForChild("Input")
--local InputMaps = Input:WaitForChild("InputMaps")

local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

local TouchGuiContainer = PlayerGui:WaitForChild("ActiveTouchGui")
--local TouchControlFrame = TouchGui:WaitForChild("TouchControlFrame")

local TouchControls = require(Platform:WaitForChild("TouchControls"))

local singleton

local ActiveTouchGui = {}
ActiveTouchGui.__index = ActiveTouchGui

function ActiveTouchGui.new()
	local self = setmetatable({}, ActiveTouchGui)
	
	self.TouchGui = nil
	self.Enabled = false
	
	return self
end

function ActiveTouchGui:Display(TouchGui)
	self.TouchGui = TouchGui
	self.Enabled = true
	
	TouchGui.Parent = TouchGuiContainer
end

function ActiveTouchGui:Hide()
	local TouchGui = self.TouchGui
	if TouchGui then
		TouchGui.Parent = nil
	end
	
	self.TouchGui = nil
	self.Enabled = false
end

singleton = ActiveTouchGui.new()

return singleton