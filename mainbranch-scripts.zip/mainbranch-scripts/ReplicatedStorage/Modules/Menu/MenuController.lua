--[[
    MenuController (ModuleScript)
    Path: ReplicatedStorage → Modules → Menu
    Parent: Menu
    Exported: 2026-09-21 11:23:24
]]

--[[

MenuController
This singleton provides methods for keeping track of menus, making sure they don't overlap,
and opening menus when buttons are pressed

]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Menu = Modules:WaitForChild("Menu")
local Menus = Menu:WaitForChild("Menus")

local singleton

local MenuController = {}
MenuController.__index = MenuController

function MenuController.new()
	local self = setmetatable({}, MenuController)
	
	self.ActiveMenu = nil
	
	return self
end

function MenuController:ShowMenu(Menu)
	self:HideActiveMenu()
	self.ActiveMenu = Menu
	
	Menu:Show()
end

function MenuController:HideActiveMenu()
	if self.ActiveButton then
		self.ActiveButton:SetOpen(false)
	end
	
	local ActiveMenu = self.ActiveMenu
	if ActiveMenu then
		ActiveMenu:Hide()
		self.ActiveMenu = nil
	end
end

singleton = MenuController.new()
return singleton