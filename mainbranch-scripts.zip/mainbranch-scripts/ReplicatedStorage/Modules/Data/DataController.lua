--[[
    DataController (ModuleScript)
    Path: ReplicatedStorage → Modules → Data
    Parent: Data
    Exported: 2026-09-21 11:23:24
]]

--[[
DataController
a singleton for handling and recieving localplayer data
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Utilities = Modules:WaitForChild("Utilities")
local SettingsFolder = Modules:WaitForChild("Settings")

local DefaultSettings = require(SettingsFolder:WaitForChild("Player"))
local Signal = require(Utilities:WaitForChild("Signal"))

local UploadData = Remotes:WaitForChild("UploadData")
local RequestData = Remotes:WaitForChild("RequestData")
local Player = Players.LocalPlayer
local Data = Player:WaitForChild("Data")
local Level = Data:WaitForChild("Level")
local XP = Data:WaitForChild("XP")
local CustomizationFolder = Data:WaitForChild("Customization")

local singleton

local DataController = {}
DataController.__index = DataController

function DataController.new()
	local self = setmetatable({}, DataController)
	
	self.Settings = DefaultSettings
	self.XPChanged = Signal.new()
	self.LevelChanged = Signal.new()
	
	XP:GetPropertyChangedSignal("Value"):Connect(function(Value)
		self.XPChanged:Fire(Value)
	end)
	
	Level:GetPropertyChangedSignal("Value"):Connect(function(Value)
		self.LevelChanged:Fire(Value)
	end)
	
	return self
end

function DataController:LoadSettings()
	-- TODO timeout?
	local Result = RequestData:InvokeServer("GetSettings")
	
	local Settings = Result or DefaultSettings
	
	self.Settings = Settings
	
	return Settings
end

function DataController:SaveSettings()
	UploadData:FireServer("SetSettings", self.Settings)
end
-- to be used for getting the trails of other players for projectiles
function DataController:GetPlayerTrail(TargetPlayer)
	local Data = TargetPlayer:FindFirstChild("Data")
	if Data then
		local Customization = Data:FindFirstChild("Customization")
		if Customization then
			local Trail = Customization:FindFirstChild("Trail")
			if Trail then
				return Trail.Value
			end
		end
	end
end

function DataController:SetCustomization(Category, Item)
	UploadData:FireServer("SetCustomization", Category, Item)
end

function DataController:GetCustomization(Category)
	local Customization = CustomizationFolder:FindFirstChild(Category)
	if Customization then
		return Customization.Value
	end
end

--function DataController:SetTrail(Trail)
--	UploadData:FireServer("SetTrail", Trail)
--end

function DataController:GetXP()
	return XP.Value
end

function DataController:GetLevel()
	return Level.Value
end

--function DataController:GetTrail()
--	return Trail.Value
--end

singleton = DataController.new()
return singleton