--[[
    GetPlayerLevel (ModuleScript)
    Path: ReplicatedStorage → Modules → Data
    Parent: Data
    Exported: 2026-09-21 11:23:24
]]

return function(Player)
	-- this is done because datacontroller uses local player, and cannot be required from server
	local Data = Player:FindFirstChild("Data")
	if Data then
		local Level = Data:FindFirstChild("Level")
		if Level then
			return Level.Value
		end
	end
end