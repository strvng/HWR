--[[
    Layout (Script)
    Path: ReplicatedStorage → Modules → Projectiles
    Parent: Projectiles
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]


--[[

Main entry:
main entry is inconsistent,
we need a function to retrieve a class
from that is stored within one of the folders.

projectiles are classes
we use MainEntry:GetProjectile("projectile type")
then use .new on the result of that

+]]