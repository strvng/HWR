--[[
    BaseTrail (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles
    Parent: Projectiles
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Customization = Modules:WaitForChild("Customization")
local Explosions = Projectiles:WaitForChild("Explosions")
local Utilities = Modules:WaitForChild("Utilities")

--local BaseCustomization = require(Customization:WaitForChild("BaseCustomization"))
local ExplosionEffect = require(Explosions:WaitForChild("ExplosionEffect"))
local DebrisFolder = require(Utilities:WaitForChild("DebrisFolder"))
local TrailHelper = require(Projectiles:WaitForChild("TrailHelper"))

local BaseTrail = {}
BaseTrail.__index = BaseTrail
BaseTrail.TrailHelper = TrailHelper

function BaseTrail.new()
	local self = setmetatable({}, BaseTrail)
	
	self.ApplyCallback = {}
	self.HitCallback = {}
	
	return self
end

--function BaseTrail.GetTrailContentFolder(Name)
--	return BaseCustomization.GetContentFolder("Trails", Name)
--end

function BaseTrail:AddApplyCallback(Type, Callback)
	self.ApplyCallback[Type] = Callback
end

function BaseTrail:AddHitCallback(Type, Callback)
	self.HitCallback[Type] = Callback
end

function BaseTrail:Apply(Projectile)
	local Type = Projectile.Type
	if Type then
		self:SetCustomPhysicalProperties(Projectile)
		
		local ApplyCallback = self.ApplyCallback[Type]
		if ApplyCallback then
			ApplyCallback(Projectile)
		else
			local Default = self.ApplyCallback["Default"]
			if Default then
				Default(Projectile)
			end
		end
	end
end

function BaseTrail:Hit(Projectile)
	local Type = Projectile.Type
	if Type then
		local HitCallback = self.HitCallback[Type]
		if HitCallback then
			HitCallback(Projectile)
		else
			local Default = self.HitCallback["Default"]
			if Default then
				Default(Projectile)
			end
		end
	end
end

function BaseTrail.ExplodeEffect(Origin)
	local Effect = ExplosionEffect(Origin)
	Effect.Parent = DebrisFolder.Other
end

function BaseTrail:SetCustomPhysicalProperties(Projectile)
	local ProjectileModel = Projectile.Projectile
	if ProjectileModel then
		ProjectileModel.CustomPhysicalProperties = PhysicalProperties.new(Enum.Material.Plastic)
	end
end

return BaseTrail