--[[
    TrailHelper (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles
    Parent: Projectiles
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Debris = game:GetService("Debris")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Utilites = Modules:WaitForChild("Utilities")

local DebrisFolder = require(Utilites:WaitForChild("DebrisFolder"))

local Rand = Random.new()
local PartFaces = Enum.NormalId:GetEnumItems()

local TrailHelper = {}

function TrailHelper.ApplyHat(Projectile, Hat, Offset)
	local Weld = Instance.new("WeldConstraint")
	Weld.Part0 = Projectile
	Weld.Part1 = Hat
	
	Hat.CFrame = Projectile.CFrame * CFrame.new(0, (Projectile.Size.Y / 2) + Offset, 0)
	--Weld.C1 = CFrame.new(0, (Projectile.Size.Y / 2) + Offset, 0)
	
	Hat.Parent = Projectile
	Weld.Parent = Projectile
end

function TrailHelper.ApplyTexture(Projectile, Texture)
	for i, v in pairs(PartFaces) do
		local Texture = Texture:Clone()
		Texture.Face = v
		Texture.Parent = Projectile
	end
end

export type ParticleParameters = {
	SpawnCount: int,
	VelocityMultiplier: int,
	AngularVelocityMultiplier: int,
	DebrisTimer: int
}

local DefaultParticleParameters = {
	SpawnCount = 20,
	VelocityMultiplier = 25,
	AngularVelocityMultiplier = 100,
	DebrisTimer = 5
}

function TrailHelper.IsProjectileExplosive(Projectile)
	return Projectile.ExplosionRadius ~= nil
end

function TrailHelper.PaintballParticle(Prefab, Origin, Parameters: ParticleParameters)
	if Origin then
		if not Parameters then
			Parameters = {}
		end
		
		local SpawnCount = Parameters.SpawnCount or DefaultParticleParameters.SpawnCount
		local VelocityMultiplier = Parameters.VelocityMultiplier or DefaultParticleParameters.VelocityMultiplier
		local AngularVelocityMultiplier = Parameters.AngularVelocityMultiplier or DefaultParticleParameters.AngularVelocityMultiplier
		local DebrisTimer = Parameters.DebrisTimer or DefaultParticleParameters.DebrisTimer
		
		for i = 1, SpawnCount do
			local X = Rand:NextInteger(-1, 1)
			local Y = Rand:NextInteger(0, 1)
			local Z = Rand:NextInteger(-1, 1)
			
			local NewPrefab = Prefab:Clone()
			NewPrefab.Parent = DebrisFolder.Other
			NewPrefab.CFrame = Origin * CFrame.new(X, Y, Z)
			NewPrefab.AssemblyLinearVelocity = Vector3.new(X, Y, Z) * VelocityMultiplier
			NewPrefab.AssemblyAngularVelocity = Vector3.new(X, Y, Z) * AngularVelocityMultiplier
			
			Debris:AddItem(NewPrefab, DebrisTimer)
		end
	end
end

return TrailHelper