--[[
    Settings (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles
    Parent: Projectiles
    Exported: 2026-09-21 11:23:24
]]
return {
	FastRocket = {
		RocketDebris = 60,
		ExplosionForce = 160,
		ExplosionRadius = 5,
		Cooldown = 4,
		RocketSpeed = 400,
	},
	MultiRocket = {
		RocketDebris = 60,
		ExplosionForce = 160,
		ExplosionRadius = 5,
		Cooldown = 3,
		RocketSpeed = 200,
	},
	PlaneMissile = {
		MissileDebris = 60,
		MissileSpeed = 200,
		ExplosionForce = 160,
		ExplosionRadius = 5,
		Cooldown = 1,
	},
	JeepBullet = {
		BulletDebris = 60,
		BulletSpeed = 200,
		Cooldown = 0.2,
	},
	Pistol = {
		PistolDebris = 30,
		Cooldown = 0.25,
		BulletSpeed = 300,
	},
	Bomb = {
		BombDebris = 60,
		ExplosionRadius = 9,
		ExplosionForce = 160,
		Cooldown = 1.5,
	},
	VipMissile = {
		MissileDebris = 60,
		MissileSpeed = 200,
		ExplosionForce = 160,
		ExplosionRadius = 5,
		Cooldown = 1,
	},
	HomingMissile = {
		MissileDebris = 60,
		MissileSpeed = 200,
		ExplosionForce = 160,
		ExplosionRadius = 7,
		Cooldown = 15,
	},
	Dagger = {
		LungeTime = 0.75,
		MinimumLungeTime = 0.2,
		ForceDebris = 0.5,
		MaxForce = Vector3.new(0, 4000*0.75, 0),
		LungeDebounce = 0.75,
		LungeDamage = 30,
		SlashDamage = 10,
	},
	Helicopter = {
		ExplosionTotalVelocity = 70,
		ExplosionRadius = 10,
		ExplosionForce = 200,
	},
	DeathMissile = {
		Cooldown = 3,
		ExplosionRadius = 10,
		ExplosionForce = 200,
	},
	AK47 = {
		Cooldown = 4,
		PauseCooldown = 1,
		FireRate = 0.14,
		MagazineSize = 9,
		BulletSpeed = 300
	},
	M24 = {
		Cooldown = 7,
		BulletSpeed = 600
	},
	SAMTankMissile = {
		Cooldown = 6,
		ExplosionRadius = 10,
		ExplosionForce = 200,
		Velocity = 190,
	}
}