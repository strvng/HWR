--[[
    BreakJoints (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → Explosions
    Parent: Explosions
    Exported: 2026-09-21 11:23:24
]]

return function(Object)
	local Joints = Object:GetJoints()
	if Joints then
		for _, v in pairs(Joints) do
			v:Destroy()
		end
	end
end