--[[
    GetCharacter (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → Explosions
    Parent: Explosions
    Exported: 2026-09-21 11:23:24
]]
local Players = game:GetService("Players")

return function(Part)
	local Character = Part:FindFirstAncestorOfClass("Model")
	if Character then
		local ForceField = Character:FindFirstChildOfClass("ForceField")
		
		return Character, ForceField
	end
end