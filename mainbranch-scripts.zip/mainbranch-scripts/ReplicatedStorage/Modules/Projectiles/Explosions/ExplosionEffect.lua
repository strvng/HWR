--[[
    ExplosionEffect (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → Explosions
    Parent: Explosions
    Exported: 2026-09-21 11:23:24
]]
return function(Position)
	local Explosion = Instance.new("Explosion")
	Explosion.BlastRadius = 0
	Explosion.BlastPressure = 0
	Explosion.DestroyJointRadiusPercent = 0
	Explosion.Position = Position
	
	return Explosion
end