--[[
    CreateExplosion (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → Explosions
    Parent: Explosions
    Exported: 2026-09-21 11:23:24
]]
return function(Position, Radius, IgnoreCritera)
	local RegionParts = workspace:GetPartBoundsInRadius(Position, Radius)
	local HitParts = {}
	
	for i, v in pairs(RegionParts) do
		if not v.Anchored and ((not IgnoreCritera and true) or (IgnoreCritera and IgnoreCritera(v))) then
			table.insert(HitParts, v)
		end
	end
	
	return HitParts
end