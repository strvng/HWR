--[[
    HandleExplosion (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → Explosions
    Parent: Explosions
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")

local DebrisFolder = workspace:WaitForChild("Debris")
local Projectiles = DebrisFolder:WaitForChild("Projectiles")

local Modules = script.Parent
local Player = Players.LocalPlayer

local GetCharacter = require(Modules:WaitForChild("GetCharacter"))
local BreakJoints = require(Explosions:WaitForChild("BreakJoints"))

return function(Position, HitParts, Force)
	for i, v in pairs(HitParts) do
		local Mass = v.Mass
		if Mass < 500 and not v.Anchored and not v:IsDescendantOf(Projectiles) then
			local Character, Forcefield = GetCharacter(v)
			local Distance = v.Position - Position
			
			if Character then
				local HitPlayer = Players:GetPlayerFromCharacter(Character)
				if HitPlayer and HitPlayer ~= Player then
					if HitPlayer.TeamColor ~= Player.TeamColor and not Forcefield then
						BreakJoints(v)
					end
				else
					if not Forcefield then
						BreakJoints(v)
					end
				end
			else
				BreakJoints(v)
			end
			
			v.AssemblyLinearVelocity = Distance.Unit * Vector3.new(Force, Force, Force)
			v.AssemblyAngularVelocity = Distance.Unit * (Force * 0.5)
		end
	end
end


--local Welds = x:GetJoints()
--if Welds and x.Name ~= "Rocket" then
--	local Difference = (x.Position - Position)
--	if not x.Anchored then
--		local Character = Players:GetPlayerFromCharacter(x:FindFirstAncestorOfClass("Model"))
--		if Character then
--			local HitPlayer = Players:GetPlayerFromCharacter(Character)
--			if HitPlayer then
--				if not Character:FindFirstChildOfClass("ForceField") then
--					table.foreach(Welds, function(i, v)
--						v.Enabled = false
--					end)
--				end
--			end
--		else
--			table.foreach(Welds, function(i, v)
--				v.Enabled = false
--			end)
--		end
--		x.AssemblyLinearVelocity = Difference.Unit * Vector3.new(WeaponSettings.MultiRocket.ExplosionForce, WeaponSettings.MultiRocket.ExplosionForce, WeaponSettings.MultiRocket.ExplosionForce)
--		x.AssemblyAngularVelocity = Difference.Unit * (WeaponSettings.MultiRocket.ExplosionForce * 0.5)
--	end
--end