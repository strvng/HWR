--[[
    HandleExplosionByMass (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → Explosions
    Parent: Explosions
    Exported: 2026-09-21 11:23:24
]]
return function(Position, HitParts, Force)
	for i, v in pairs(HitParts) do
		local Mass = v.Mass
		if Mass < 500 and not v.Anchored then
			local Distance = v.Position - Position
			local NormalizedMass = Mass / 5
			local Velocity = Force / (Distance * NormalizedMass)
			
			v:BreakJoints()
			
			v.AssemblyLinearVelocity = Velocity
		end
	end
end