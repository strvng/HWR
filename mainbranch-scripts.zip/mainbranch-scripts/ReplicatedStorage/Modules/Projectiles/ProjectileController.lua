--[[
    ProjectileController (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles
    Parent: Projectiles
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local ProjectileController = {}
ProjectileController.__index = ProjectileController

local singleton

function ProjectileController.new()
	local self = setmetatable({}, ProjectileController)
	
	return self
end

function ProjectileController:GetProjectile(Name)
	local Module = ProjectileClasses:FindFirstChild(Name)
	if Module then
		return require(Module)
	end
end

singleton = ProjectileController.new()

return singleton