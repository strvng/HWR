--[[
    Bomb (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")
local Vehicle = Modules:WaitForChild("Vehicle")

local VehicleHelper = require(Vehicle:WaitForChild("VehicleHelper"))
local ExplosiveProjectile = require(ProjectileClasses:WaitForChild("ExplosiveProjectile"))

local Bomb = setmetatable({}, ExplosiveProjectile)
Bomb.__index = Bomb

function Bomb.new()
	local BombProjectile = Instance.new("Part")
	BombProjectile.Size = Vector3.new(2, 2, 2)
	BombProjectile.BrickColor = BrickColor.new("Bright red")
	BombProjectile.Reflectance = 0.2
	BombProjectile.Material = Enum.Material.Plastic
	BombProjectile.CanCollide = true
	BombProjectile.Anchored = false
	BombProjectile.Shape = Enum.PartType.Ball
	
	local Swoosh = Instance.new("Sound")
	Swoosh.Looped = true
	Swoosh.SoundId = "rbxassetid://12222095"
	Swoosh.Volume = 0.7
	Swoosh.Name = "Swoosh"
	Swoosh.Parent = BombProjectile
	
	local Explosion = Instance.new("Sound")
	Explosion.SoundId = "rbxassetid://12221984"
	Explosion.Volume = 0.7
	Explosion.Name = "Explosion"
	Explosion.PlayOnRemove = true
	Explosion.Parent = BombProjectile
	
	Swoosh:Play()
	
	local self = setmetatable(ExplosiveProjectile.new(BombProjectile), Bomb)
	
	self:SetForce(ExplosiveProjectile.Settings.Bomb.ExplosionForce)
	self:SetRadius(ExplosiveProjectile.Settings.Bomb.ExplosionRadius)
	
	self.Type = "Bomb"
	
	return self
end

function Bomb:Visualize(Origin)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	local Character = Shooter.Character
	if Projectile and Shooter then
		Projectile.CFrame = Origin * CFrame.new(0, -12, 0)
		
		if self:IsLocal() then
			self:AddRequest(Origin)
		end
		
		Projectile.Touched:Connect(function(Hit)
			local Vehicle = VehicleHelper.GetVehicle(Shooter)
			if ExplosiveProjectile.IsDescendantIfExists(Vehicle, Hit) then
				self:Hit(Hit)
			end
		end)
		
		Projectile.Parent = ExplosiveProjectile.DebrisFolders.Explosives
	end
end

function Bomb:Hit()
	local Projectile = self.Projectile
	if Projectile and not self.Exploded then
		local Position = Projectile.Position
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
			Trail.ExplodeEffect(Position)
		else
			ExplosiveProjectile.ExplodeEffect(Position)
		end
		
		if self:IsLocal() then
			local Parts = self:Explode()
			
			self:RemoveRequest(Position, Parts)
		end
		
		self:Destroy()
	end
end

return Bomb