--[[
    VipMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local BaseGroupProjectile = require(ProjectileClasses:WaitForChild("BaseGroupProjectile"))
local SingleVipMissile = require(script:WaitForChild("SingleVipMissile"))

local Player = Players.LocalPlayer

local GroupVipMissile = setmetatable({}, BaseGroupProjectile)
GroupVipMissile.__index = GroupVipMissile

function GroupVipMissile.new()
	local self = setmetatable(BaseGroupProjectile.new(), GroupVipMissile)
	
	for i = 1, 4 do
		self:AddProjectile(
			SingleVipMissile.new(self)
		)
	end
	
	self.Type = "VipMissile"
	
	return self
end

function GroupVipMissile.ParseGuns(Guns)
	local Origins = {}
	
	for _, v in pairs(Guns) do
		table.insert(Origins, v.CFrame)
	end
	
	return Origins
end

function GroupVipMissile:Visualize(Origins)
	if self:IsLocal() then
		self:AddRequest(Origins)
	end
	
	for i, v in pairs(self.Projectiles) do
		local Origin = Origins[i]
		if Origin then
			v:Visualize(Origin)
		end
	end
end

function GroupVipMissile:Hit(Projectile, Parts)
	BaseGroupProjectile.Hit(self, Projectile)
	
	if self:IsLocal() then
		local ProjectileModel = Projectile.Projectile
		if ProjectileModel then
			self:RemoveRequest(ProjectileModel.Position, Parts)
		end
	end
end

return GroupVipMissile