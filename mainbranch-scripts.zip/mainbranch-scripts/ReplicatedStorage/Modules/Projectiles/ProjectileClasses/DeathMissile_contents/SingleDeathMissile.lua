--[[
    SingleDeathMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses → DeathMissile
    Parent: DeathMissile
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local ExplosiveProjectile = require(ProjectileClasses:WaitForChild("ExplosiveProjectile"))

local Player = Players.LocalPlayer

local DeathMissile = setmetatable({}, ExplosiveProjectile)
DeathMissile.__index = DeathMissile

function DeathMissile.new(Group)
	local Rocket = Instance.new("Part")
	Rocket.Name = "Rocket"
	Rocket.CanCollide = true
	Rocket.Anchored = false
	Rocket.Transparency = 0
	Rocket.Reflectance = 0
	Rocket.Locked = true
	Rocket.TopSurface = Enum.SurfaceType.Studs
	Rocket.BottomSurface = Enum.SurfaceType.Studs
	Rocket.FrontSurface = Enum.SurfaceType.Studs
	Rocket.BackSurface = Enum.SurfaceType.Studs
	Rocket.RightSurface = Enum.SurfaceType.Studs
	Rocket.LeftSurface = Enum.SurfaceType.Studs
	Rocket.Material = Enum.Material.Plastic
	Rocket.Size = Vector3.new(1, 1, 4)
	Rocket.BrickColor = BrickColor.new("Really black")
	
	local Highlight = Instance.new("Highlight")
	Highlight.Parent = Rocket
	Highlight.Adornee = Rocket
	Highlight.FillColor = Color3.fromRGB(255, 0, 0)
	Highlight.OutlineColor = Color3.fromRGB(255, 0, 0)
	Highlight.FillTransparency = 0.25
	Highlight.OutlineTransparency = 0
	Highlight.DepthMode = Enum.HighlightDepthMode.Occluded
	
	local RocketPropulsion = Instance.new("RocketPropulsion")
	RocketPropulsion.TargetRadius = 4
	RocketPropulsion.MaxTorque = Vector3.new(100000, 100000, 100000)
	RocketPropulsion.TurnD = 500
	RocketPropulsion.TurnP = 5000
	RocketPropulsion.MaxThrust = 1e5
	RocketPropulsion.MaxSpeed = 225
	RocketPropulsion.CartoonFactor = 1
	RocketPropulsion.ThrustD = 0.001
	RocketPropulsion.ThrustP = 1000
	RocketPropulsion.Parent = Rocket
	
	local BodyVelocity = Instance.new("BodyVelocity")
	BodyVelocity.MaxForce = Vector3.new(100000, 100000, 100000)
	BodyVelocity.Parent = Rocket
	
	local BodyGyro = Instance.new("BodyGyro")
	BodyGyro.MaxTorque = Vector3.zero
	BodyGyro.D = 500
	BodyGyro.P = 10000
	BodyGyro.Parent = Rocket
	
	local Swoosh = Instance.new("Sound")
	Swoosh.Looped = true
	Swoosh.SoundId = "rbxassetid://12222095"
	Swoosh.Volume = 0.7
	Swoosh.Name = "Swoosh"
	Swoosh.Parent = Rocket

	local Explosion = Instance.new("Sound")
	Explosion.SoundId = "rbxassetid://12221984"
	Explosion.Volume = 0.7
	Explosion.Name = "Explosion"
	Explosion.PlayOnRemove = true
	Explosion.Parent = Rocket
	
	Swoosh:Play()
	
	local self = setmetatable(ExplosiveProjectile.new(Rocket), DeathMissile)
	
	self:SetForce(ExplosiveProjectile.Settings.DeathMissile.ExplosionForce)
	self:SetRadius(ExplosiveProjectile.Settings.DeathMissile.ExplosionRadius)
	
	self.Type = "DeathMissile"
	self.Group = Group
	
	return self
end

function DeathMissile:PlayFireAnimation(Target)
	local Projectile = self.Projectile
	if Projectile then
		local BodyVelocity = Projectile:FindFirstChild("BodyVelocity")
		local BodyGyro = Projectile:FindFirstChild("BodyGyro")
		if BodyVelocity and BodyGyro then
			BodyVelocity.Velocity = Projectile.CFrame.LookVector * 60
			
			task.wait(0.2)
			
			local Steps = 20
			local Goal = 90
			local IntendedTime = 0.4
			local RotationPerStep = Goal / Steps
			local TimePerStep = IntendedTime / Steps
			
			BodyGyro.MaxTorque = Vector3.new(100000, 100000, 100000)
			BodyGyro.CFrame = Projectile.CFrame
			
			for i = 1, Steps do
				local NewCFrame = BodyGyro.CFrame * CFrame.Angles(math.rad(RotationPerStep), 0, 0)
				BodyGyro.CFrame = NewCFrame
				BodyVelocity.Velocity = NewCFrame.LookVector * 60
				
				task.wait(TimePerStep)
			end
			
			task.wait(1)
			
			--for i = 1, Steps do
			--	if Projectile and Target then
			--		local Position = Projectile.Position
			--		local TargetPosition = Target.Position
			--		local IntendedCFrame = CFrame.new(Vector3.new(Position.X, 0, Position.Z), Vector3.new(TargetPosition.X, 0, TargetPosition.Z))
			--		local NewCFrame = BodyGyro.CFrame:Lerp(IntendedCFrame, i / Steps)
					
			--		BodyGyro.CFrame = NewCFrame
			--		BodyVelocity.Velocity = NewCFrame.LookVector * 60
					
			--		task.wait(TimePerStep)
			--	else
			--		break
			--	end
			--end
			
			BodyVelocity:Destroy()
			BodyGyro:Destroy()
		end
	end
end

function DeathMissile:Visualize(Handle, Target)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	if Projectile and Shooter then
		local Fire = Handle:FindFirstChild("Fire")
		local RocketPropulsion = Projectile:FindFirstChild("RocketPropulsion")
		if RocketPropulsion then
			Projectile.CFrame = Handle.CFrame * CFrame.Angles(0, math.rad(90), 0) * CFrame.new(0, 0, -7)
			
			if Fire then
				Fire:Play()
			end
			
			RocketPropulsion.Target = Target
			
			Projectile.Touched:Connect(function(Hit)
				self:Hit(Hit)
			end)
			
			Projectile.Parent = ExplosiveProjectile.DebrisFolders.Explosives
			
			task.defer(function()
				self:PlayFireAnimation(Target)
				RocketPropulsion:Fire()
				--RocketPropulsion.TargetOffset = Vector3.new(0, 125, 0)
				--RocketPropulsion.ReachedTarget:Wait()
				--RocketPropulsion.TargetOffset = Vector3.zero
			end)
		end
	end
end

function DeathMissile:Hit()
	local Projectile = self.Projectile
	if Projectile and not self.Exploded then
		local Position = Projectile.Position
		
		ExplosiveProjectile.ExplodeEffect(Position)
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
		end
		
		if self:IsLocal() then
			local Parts = self:Explode()
			local Group = self.Group
			
			if Group then
				Group:Hit(self, Parts)
			end
		end
		
		self:Destroy()
	end
end

return DeathMissile