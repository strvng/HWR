--[[
    FastRocket (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local ExplosiveProjectile = require(ProjectileClasses:WaitForChild("ExplosiveProjectile"))

local FastRocket = setmetatable({}, ExplosiveProjectile)
FastRocket.__index = FastRocket

function FastRocket.new()
	local Rocket = Instance.new("Part")
	Rocket.Name = "Rocket"
	Rocket.CanCollide = true
	Rocket.Anchored = false
	Rocket.Transparency = 0
	Rocket.Reflectance = 0
	Rocket.Locked = true
	Rocket.TopSurface = Enum.SurfaceType.Studs
	Rocket.BottomSurface = Enum.SurfaceType.Studs
	Rocket.FrontSurface = Enum.SurfaceType.Studs
	Rocket.BackSurface = Enum.SurfaceType.Studs
	Rocket.RightSurface = Enum.SurfaceType.Studs
	Rocket.LeftSurface = Enum.SurfaceType.Studs
	Rocket.Material = Enum.Material.Plastic
	Rocket.Size = Vector3.new(1, 1, 4)
	Rocket.BrickColor = BrickColor.new("Bright blue")
	
	local Swoosh = Instance.new("Sound")
	Swoosh.Looped = true
	Swoosh.SoundId = "rbxassetid://12222095"
	Swoosh.Volume = 0.7
	Swoosh.Name = "Swoosh"
	Swoosh.Parent = Rocket
	
	local Explosion = Instance.new("Sound")
	Explosion.SoundId = "rbxassetid://12221984"
	Explosion.Volume = 0.7
	Explosion.Name = "Explosion"
	Explosion.PlayOnRemove = true
	Explosion.Parent = Rocket
	
	Swoosh:Play()
	
	local BodyForce = Instance.new("BodyForce")
	BodyForce.Force = Vector3.new(0, Rocket.AssemblyMass * workspace.Gravity, 0)
	BodyForce.Parent = Rocket
	
	local self = setmetatable(ExplosiveProjectile.new(Rocket), FastRocket)
	
	self:SetForce(ExplosiveProjectile.Settings.FastRocket.ExplosionForce)
	self:SetRadius(ExplosiveProjectile.Settings.FastRocket.ExplosionRadius)
	
	self.Type = "FastRocket"
	
	return self
end

function FastRocket:SetShooter(Shooter)
	ExplosiveProjectile.SetShooter(self, Shooter)
	
	local Projectile = self.Projectile
	if Projectile then
		Projectile.BrickColor = Shooter.TeamColor
	end
end

function FastRocket:Visualize(Origin, Endpoint)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	local Character = Shooter.Character
	
	if Projectile and Shooter then
		local Direction = (Endpoint - Origin)
		Direction = Direction * (1 / Direction.Magnitude)
		local Position = Origin + (Direction * 6)
		
		Projectile.Velocity = Direction * 400
		Projectile.CFrame = CFrame.new(Position, Endpoint)
		
		Projectile.Touched:Connect(function(Hit)
			self:Hit(Hit)
		end)
		
		if self:IsLocal() then
			self:AddRequest(Origin, Endpoint)
		end
		
		Projectile.Parent = ExplosiveProjectile.DebrisFolders.Explosives
	end
end

function FastRocket:Hit()
	local Projectile = self.Projectile
	if Projectile and not self.Exploded then
		local Position = Projectile.Position
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
			Trail.ExplodeEffect(Position)
		else
			ExplosiveProjectile.ExplodeEffect(Position)
		end
		
		if self:IsLocal() then
			local Parts = self:Explode()
			
			self:RemoveRequest(Position, Parts)
		end
		
		self:Destroy()
	end
end

return FastRocket