--[[
    Pistol (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local BaseSingleProjectile = require(ProjectileClasses:WaitForChild("BaseSingleProjectile"))

local Pistol = setmetatable({}, BaseSingleProjectile)
Pistol.__index = Pistol

function Pistol.new()
	local Bullet = Instance.new("Part")
	Bullet.Transparency = 0
	Bullet.Reflectance = 0
	Bullet.CanCollide = true
	Bullet.Anchored = false
	Bullet.BrickColor = BrickColor.new("Black")
	Bullet.Locked = false
	Bullet.Material = Enum.Material.Plastic
	Bullet.Size = Vector3.new(1, 1, 1)
	Bullet.TopSurface = Enum.SurfaceType.Smooth
	Bullet.BottomSurface = Enum.SurfaceType.Smooth
	Bullet.Name = "Bullet"

	local Sound = Instance.new("Sound")
	Sound.SoundId = "rbxassetid://13510352"
	Sound.Volume = 0.85
	
	local BodyForce = Instance.new("BodyForce")
	BodyForce.Force = Vector3.new(0, Bullet.AssemblyMass * workspace.Gravity, 0)
	BodyForce.Parent = Bullet
	
	local self = setmetatable(BaseSingleProjectile.new(Bullet), Pistol)
	
	self.FireSound = Sound
	self.Type = "Pistol"
	
	return self
end

function Pistol:Visualize(Origin, Endpoint, Handle)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	local Character = Shooter.Character
	local FireSound = self.FireSound
	
	if Projectile and Shooter and FireSound then
		local Direction = (Endpoint - Origin) * (1 / (Endpoint - Origin).Magnitude)
		local RPosition = Origin + (Direction * 8)
		
		FireSound.Parent = Handle
		Projectile.AssemblyLinearVelocity = Direction * BaseSingleProjectile.Settings.Pistol.BulletSpeed
		Projectile.Position = RPosition
		
		Projectile.Touched:Connect(function(Hit)
			if BaseSingleProjectile.IsDescendantIfExists(Character, Hit) then
				self:Hit(Hit)
			end
		end)
		
		if self:IsLocal() then
			self:AddRequest(Origin, Endpoint)
		end
		
		FireSound.Ended:Once(function()
			FireSound:Destroy()
		end)
		
		FireSound:Play()
		
		Projectile.Parent = BaseSingleProjectile.DebrisFolders.Projectiles
	end
end

function Pistol:Hit(Hit)
	local Projectile = self.Projectile
	if Projectile then
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
		end
		
		if self:IsLocal() then
			self:RemoveRequest(Hit)
		end
		
		self:Destroy()
	end
end

return Pistol