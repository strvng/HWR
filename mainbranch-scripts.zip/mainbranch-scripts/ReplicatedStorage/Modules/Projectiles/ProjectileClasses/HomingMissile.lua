--[[
    HomingMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local BaseGroupProjectile = require(ProjectileClasses:WaitForChild("BaseGroupProjectile"))
local SingleHomingMissile = require(script:WaitForChild("SingleHomingMissile"))

local Player = Players.LocalPlayer

local GroupHomingMissile = setmetatable({}, BaseGroupProjectile)
GroupHomingMissile.__index = GroupHomingMissile

function GroupHomingMissile.new()
	local self = setmetatable(BaseGroupProjectile.new(), GroupHomingMissile)
	
	local Missile1 = SingleHomingMissile.new(self)
	local Missile2 = SingleHomingMissile.new(self)
	
	self:AddProjectile(Missile1)
	self:AddProjectile(Missile2)
	
	self.Type = "HomingMissile"
	
	return self
end

function GroupHomingMissile.ParseGuns(Guns)
	local Origins = {}
	
	for _, v in pairs(Guns) do
		table.insert(Origins, v.CFrame)
	end
	
	return Origins
end

function GroupHomingMissile:Visualize(Origins, Target)
	if self:IsLocal() then
		self:AddRequest(Origins, Target)
	end
	
	for i, v in pairs(self.Projectiles) do
		local Origin = Origins[i]
		if Origin then
			v:Visualize(Origin, Target)
		end
	end
end

function GroupHomingMissile:Hit(Projectile, Parts)
	BaseGroupProjectile.Hit(self, Projectile)
	
	if self:IsLocal() then
		local ProjectileModel = Projectile.Projectile
		if ProjectileModel then
			self:RemoveRequest(ProjectileModel.Position, Parts)
		end
	end
end

return GroupHomingMissile