--[[
    PlaneMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local BaseGroupProjectile = require(ProjectileClasses:WaitForChild("BaseGroupProjectile"))
local SinglePlaneMissile = require(script:WaitForChild("SinglePlaneMissile"))

local Player = Players.LocalPlayer

local GroupPlaneMissile = setmetatable({}, BaseGroupProjectile)
GroupPlaneMissile.__index = GroupPlaneMissile

function GroupPlaneMissile.new()
	local self = setmetatable(BaseGroupProjectile.new(), GroupPlaneMissile)
	
	local Missile1 = SinglePlaneMissile.new(self)
	local Missile2 = SinglePlaneMissile.new(self)
	
	self:AddProjectile(Missile1)
	self:AddProjectile(Missile2)
	
	self.Type = "PlaneMissile"
	
	return self
end

function GroupPlaneMissile.ParseGuns(Guns)
	local Origins = {}
	
	for _, v in pairs(Guns) do
		table.insert(Origins, v.CFrame)
	end
	
	return Origins
end

function GroupPlaneMissile:Visualize(Origins)
	--self:AddRequest(table.unpack(Guns))
	if self:IsLocal() then
		self:AddRequest(Origins)
	end
	
	for i, v in pairs(self.Projectiles) do
		local Origin = Origins[i]
		if Origin then
			v:Visualize(Origin)
		end
	end
end

function GroupPlaneMissile:Hit(Projectile, Parts)
	BaseGroupProjectile.Hit(self, Projectile)
	
	if self:IsLocal() then
		local ProjectileModel = Projectile.Projectile
		if ProjectileModel then
			self:RemoveRequest(ProjectileModel.Position, Parts)
		end
	end
end

return GroupPlaneMissile