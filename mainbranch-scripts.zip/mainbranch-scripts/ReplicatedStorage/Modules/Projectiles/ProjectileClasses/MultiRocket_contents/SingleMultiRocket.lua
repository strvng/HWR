--[[
    SingleMultiRocket (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses → MultiRocket
    Parent: MultiRocket
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local ExplosiveProjectile = require(ProjectileClasses:WaitForChild("ExplosiveProjectile"))

local MultiRocket = setmetatable({}, ExplosiveProjectile)
MultiRocket.__index = MultiRocket

local function ExplosionIgnoreCriteria(HitPart)
	if HitPart.Name ~= "Rocket" then
		return true
	end
end

function MultiRocket.new(Group)
	local Rocket = Instance.new("Part")
	Rocket.Name = "Rocket"
	Rocket.CanCollide = true
	Rocket.Anchored = false
	Rocket.Transparency = 0
	Rocket.Reflectance = 0
	Rocket.Locked = true
	Rocket.TopSurface = Enum.SurfaceType.Studs
	Rocket.BottomSurface = Enum.SurfaceType.Studs
	Rocket.FrontSurface = Enum.SurfaceType.Studs
	Rocket.BackSurface = Enum.SurfaceType.Studs
	Rocket.RightSurface = Enum.SurfaceType.Studs
	Rocket.LeftSurface = Enum.SurfaceType.Studs
	Rocket.Material = Enum.Material.Plastic
	Rocket.Size = Vector3.new(1, 1, 4)
	Rocket.BrickColor = BrickColor.new("Bright blue")
	
	local Swoosh = Instance.new("Sound")
	Swoosh.Looped = true
	Swoosh.SoundId = "rbxassetid://12222095"
	Swoosh.Volume = 0.7
	Swoosh.Name = "Swoosh"
	Swoosh.Parent = Rocket
	
	local Explosion = Instance.new("Sound")
	Explosion.SoundId = "rbxassetid://12221984"
	Explosion.Volume = 0.7
	Explosion.Name = "Explosion"
	Explosion.PlayOnRemove = true
	Explosion.Parent = Rocket
	
	Swoosh:Play()
	
	local BodyForce = Instance.new("BodyForce")
	BodyForce.Force = Vector3.new(0, Rocket.AssemblyMass * workspace.Gravity, 0)
	BodyForce.Parent = Rocket
	
	local self = setmetatable(ExplosiveProjectile.new(Rocket), MultiRocket)
	
	self:SetForce(ExplosiveProjectile.Settings.MultiRocket.ExplosionForce)
	self:SetRadius(ExplosiveProjectile.Settings.MultiRocket.ExplosionRadius)
	self:SetIgnoreCriteria(ExplosionIgnoreCriteria)
	
	self.Type = "MultiRocket"
	self.Offset = CFrame.new()
	self.Group = Group
	
	return self
end

function MultiRocket:SetOffset(Offset)
	self.Offset = Offset
end

function MultiRocket:SetShooter(Shooter)
	ExplosiveProjectile.SetShooter(self, Shooter)
	
	local Projectile = self.Projectile
	if Projectile then
		Projectile.BrickColor = Shooter.TeamColor
	end
end

function MultiRocket:Visualize(Origin, Endpoint)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	local Character = Shooter.Character
	local Offset = self.Offset
	
	if Projectile and Shooter and Offset then
		local Direction = (Endpoint - Origin)
		
		Direction = Direction * (1 / Direction.Magnitude)
		
		local Position = Origin + (Direction * 6)
		
		Projectile.Velocity = Direction * 200
		Projectile.CFrame = CFrame.new(Position, Endpoint) * Offset
		
		Projectile.Touched:Connect(function(Hit)
			self:Hit(Hit)
		end)
		
		Projectile.Parent = ExplosiveProjectile.DebrisFolders.Explosives
	end
end

function MultiRocket:Hit()
	local Projectile = self.Projectile
	local Group = self.Group
	if Projectile and not self.Exploded then
		local Position = Projectile.Position
		
		--TrailDestroyEffect(Missile, Type, Ignore)
		--ExplosiveProjectile.ExplodeEffect(Position)
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
			Trail.ExplodeEffect(Position)
		else
			ExplosiveProjectile.ExplodeEffect(Position)
		end
		
		if self:IsLocal() and Group then
			local Parts = self:Explode()
			
			Group:Hit(self, Parts)
		end
		
		self:Destroy()
	end
end

return MultiRocket