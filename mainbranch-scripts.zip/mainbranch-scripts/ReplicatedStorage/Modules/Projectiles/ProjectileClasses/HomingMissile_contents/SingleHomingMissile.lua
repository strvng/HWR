--[[
    SingleHomingMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses → HomingMissile
    Parent: HomingMissile
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")
local Vehicle = Modules:WaitForChild("Vehicle")

local VehicleHelper = require(Vehicle:WaitForChild("VehicleHelper"))
local ExplosiveProjectile = require(ProjectileClasses:WaitForChild("ExplosiveProjectile"))

local Player = Players.LocalPlayer

local HomingMissile = setmetatable({}, ExplosiveProjectile)
HomingMissile.__index = HomingMissile

function HomingMissile.new(Group)
	local Missile = Instance.new("Part")
	Missile.Anchored = false
	Missile.Transparency = 0
	Missile.Reflectance = 0
	Missile.BrickColor = BrickColor.new("Black")
	Missile.CanCollide = true
	Missile.TopSurface = Enum.SurfaceType.Smooth
	Missile.BottomSurface = Enum.SurfaceType.Smooth
	Missile.Size = Vector3.new(2, 2, 8)
	Missile.Locked = true
	Missile.Material = Enum.Material.Plastic
	Missile.Name = "Missile"

	local Smoke = Instance.new("Smoke")
	Smoke.RiseVelocity = 0.1
	Smoke.Size = 1
	Smoke.Opacity = 0.5
	Smoke.Parent = Missile

	local Mesh = Instance.new("SpecialMesh")
	Mesh.MeshType = Enum.MeshType.FileMesh
	Mesh.MeshId = "rbxassetid://2251534"
	Mesh.Scale = Vector3.new(0.8, 0.8, 0.5)
	Mesh.Parent = Missile

	local RocketPropulsion = Instance.new("RocketPropulsion")
	RocketPropulsion.TargetRadius = 4
	RocketPropulsion.MaxTorque = Vector3.new(100000, 100000, 100000)
	RocketPropulsion.TurnD = 500
	RocketPropulsion.TurnP = 5000
	RocketPropulsion.MaxThrust = 1e5
	RocketPropulsion.MaxSpeed = 100
	RocketPropulsion.ThrustD = 0.001
	RocketPropulsion.ThrustP = 1000
	RocketPropulsion.Parent = Missile
	
	local Swoosh = Instance.new("Sound")
	Swoosh.Looped = true
	Swoosh.SoundId = "rbxassetid://12222095"
	Swoosh.Volume = 0.7
	Swoosh.Name = "Swoosh"
	Swoosh.Parent = Missile

	local Explosion = Instance.new("Sound")
	Explosion.SoundId = "rbxassetid://12221984"
	Explosion.Volume = 0.7
	Explosion.Name = "Explosion"
	Explosion.PlayOnRemove = true
	Explosion.Parent = Missile
	
	Swoosh:Play()
	
	local self = setmetatable(ExplosiveProjectile.new(Missile), HomingMissile)
	
	self:SetForce(ExplosiveProjectile.Settings.HomingMissile.ExplosionForce)
	self:SetRadius(ExplosiveProjectile.Settings.HomingMissile.ExplosionRadius)
	
	self.Type = "HomingMissile"
	self.Group = Group
	
	return self
end

function HomingMissile:Visualize(Origin, Target)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	if Projectile and Shooter then
		local RocketPropulsion = Projectile:FindFirstChild("RocketPropulsion")
		local Character = Shooter.Character
		if RocketPropulsion then
			Projectile.CFrame = Origin * CFrame.new(0, 0, -30)
			
			RocketPropulsion.Target = Target
			
			Projectile.Touched:Connect(function(Hit)
				local Vehicle = VehicleHelper.GetVehicle(Shooter)
				if ExplosiveProjectile.IsDescendantIfExists(Character, Hit) and ExplosiveProjectile.IsDescendantIfExists(Vehicle, Hit) and Hit.Name ~= "Missile" then
					self:Hit(Hit)
				end
			end)
			
			Projectile.Parent = ExplosiveProjectile.DebrisFolders.Explosives
			RocketPropulsion:Fire()
		end
	end
end

function HomingMissile:Hit()
	local Projectile = self.Projectile
	if Projectile and not self.Exploded then
		local Position = Projectile.Position
		
		ExplosiveProjectile.ExplodeEffect(Position)
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
		end
		
		if self:IsLocal() then
			local Parts = self:Explode()
			local Group = self.Group
			if Group then
				Group:Hit(self, Parts)
			end
		end
		
		self:Destroy()
	end
end

return HomingMissile