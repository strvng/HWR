--[[
    ExplosiveProjectile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local BaseSingleProjectile = require(ProjectileClasses:WaitForChild("BaseSingleProjectile"))
local ExplosionEffect = require(Explosions:WaitForChild("ExplosionEffect"))
local CreateExplosion = require(Explosions:WaitForChild("CreateExplosion"))
local HandleExplosion = require(Explosions:WaitForChild("HandleExplosion"))

local ExplosiveProjectile = setmetatable({}, BaseSingleProjectile)
ExplosiveProjectile.__index = ExplosiveProjectile

function ExplosiveProjectile.new(Prefab)
	local self = setmetatable(BaseSingleProjectile.new(Prefab), ExplosiveProjectile)
	
	self.ExplosionRadius = 0
	self.ExplosionForce = 0
	self.Exploded = false
	
	return self
end

function ExplosiveProjectile:SetForce(Force)
	self.ExplosionForce = Force
end

function ExplosiveProjectile:SetRadius(Radius)
	self.ExplosionRadius = Radius
end

function ExplosiveProjectile:SetIgnoreCriteria(Callback)
	self.IgnoreCritera = Callback
end

function ExplosiveProjectile.ExplodeEffect(Origin)
	local Effect = ExplosionEffect(Origin)
	Effect.Parent = BaseSingleProjectile.DebrisFolders.Other
end

function ExplosiveProjectile:Explode()
	local Projectile = self.Projectile
	if Projectile and not self.Exploded then
		local ExplosionOrigin = Projectile.Position
		local Parts = CreateExplosion(ExplosionOrigin, self.ExplosionRadius, self.IgnoreCritera)
		if Parts then
			HandleExplosion(ExplosionOrigin, Parts, self.ExplosionForce)
			
			self.Exploded = true
			
			return Parts
		end
	end
end

function ExplosiveProjectile:Hit()
	
end

return ExplosiveProjectile