--[[
    BaseGroupProjectile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ProjectileClasses = script.Parent

local BaseProjectile = require(ProjectileClasses:WaitForChild("BaseProjectile"))

local BaseGroupProjectile = setmetatable({}, BaseProjectile)
BaseGroupProjectile.__index = BaseGroupProjectile

function BaseGroupProjectile.new()
	local self = setmetatable(BaseProjectile.new(), BaseGroupProjectile)
	
	self.Projectiles = {}
	
	return self
end

function BaseGroupProjectile:AddProjectile(Projectile)
	table.insert(self.Projectiles, Projectile)
end

function BaseGroupProjectile:RemoveProjectile(Projectile)
	for i, v in pairs(self.Projectiles) do
		if v == Projectile then
			table.remove(self.Projectiles, i)
			
			return
		end
	end
end

function BaseGroupProjectile:ApplyTrail(Trail)
	for _, v in pairs(self.Projectiles) do
		v:ApplyTrail(Trail)
	end
end

function BaseGroupProjectile:SetShooter(Shooter)
	for _, v in pairs(self.Projectiles) do
		v:SetShooter(Shooter)
	end
	
	self.Shooter = Shooter
end

function BaseGroupProjectile:Visualize()
	
end

function BaseGroupProjectile:Hit(Projectile)
	if table.find(self.Projectiles, Projectile) then
		self:RemoveProjectile(Projectile)
	end
end

function BaseGroupProjectile:Destroy()
	for _, v in pairs(self.Projectiles) do
		v:Destroy()
	end
	
	self.Destroyed = true
end

return BaseGroupProjectile