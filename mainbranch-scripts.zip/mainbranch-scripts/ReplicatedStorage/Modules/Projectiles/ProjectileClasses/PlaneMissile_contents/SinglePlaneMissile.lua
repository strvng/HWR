--[[
    SinglePlaneMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses → PlaneMissile
    Parent: PlaneMissile
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")
local Vehicle = Modules:WaitForChild("Vehicle")

local VehicleHelper = require(Vehicle:WaitForChild("VehicleHelper"))
local ExplosiveProjectile = require(ProjectileClasses:WaitForChild("ExplosiveProjectile"))

local Player = Players.LocalPlayer

local PlaneMissile = setmetatable({}, ExplosiveProjectile)
PlaneMissile.__index = PlaneMissile

function PlaneMissile.new(Group)
	local Missile = Instance.new("Part")
	Missile.Anchored = false
	Missile.Transparency = 0
	Missile.Reflectance = 0
	Missile.BrickColor = BrickColor.new("Black")
	Missile.CanCollide = true
	Missile.TopSurface = Enum.SurfaceType.Smooth
	Missile.BottomSurface = Enum.SurfaceType.Smooth
	Missile.Size = Vector3.new(1, 1, 1)
	Missile.Locked = true
	Missile.Material = Enum.Material.Plastic
	Missile.Name = "Missile"

	local BV = Instance.new("BodyVelocity")
	BV.MaxForce = Vector3.new(5000, 5000, 5000)
	BV.P = 12500
	BV.Parent = Missile

	local Swoosh = Instance.new("Sound")
	Swoosh.Looped = true
	Swoosh.SoundId = "rbxassetid://12222095"
	Swoosh.Volume = 0.7
	Swoosh.Name = "Swoosh"
	Swoosh.Parent = Missile

	local Explosion = Instance.new("Sound")
	Explosion.SoundId = "rbxassetid://12221984"
	Explosion.Volume = 0.7
	Explosion.Name = "Explosion"
	Explosion.PlayOnRemove = true
	Explosion.Parent = Missile
	
	Swoosh:Play()
	
	local self = setmetatable(ExplosiveProjectile.new(Missile), PlaneMissile)
	
	self:SetForce(ExplosiveProjectile.Settings.PlaneMissile.ExplosionForce)
	self:SetRadius(ExplosiveProjectile.Settings.PlaneMissile.ExplosionRadius)
	
	self.Type = "PlaneMissile"
	self.Group = Group
	
	return self
end

function PlaneMissile:Visualize(Origin)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	if Projectile and Shooter then
		local BV = Projectile:FindFirstChild("BodyVelocity")
		local Character = Shooter.Character
		if BV then
			Projectile.CFrame = Origin * CFrame.new(0, 0, -15)
			BV.Velocity = Projectile.CFrame.LookVector * ExplosiveProjectile.Settings.PlaneMissile.MissileSpeed
			
			Projectile.Touched:Connect(function(Hit)
				local Vehicle = VehicleHelper.GetVehicle(Shooter)
				if ExplosiveProjectile.IsDescendantIfExists(Character, Hit) and ExplosiveProjectile.IsDescendantIfExists(Vehicle, Hit) then
					self:Hit(Hit)
				end
			end)
			
			Projectile.Parent = ExplosiveProjectile.DebrisFolders.Explosives
		end
	end
end

function PlaneMissile:Hit()
	local Projectile = self.Projectile
	if Projectile and not self.Exploded then
		local Position = Projectile.Position
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
			Trail.ExplodeEffect(Position)
		else
			ExplosiveProjectile.ExplodeEffect(Position)
		end
		
		if self:IsLocal() then
			local Parts = self:Explode()
			local Group = self.Group
			
			if Group then
				Group:Hit(self, Parts)
			end
		end
		
		self:Destroy()
	end
end

return PlaneMissile