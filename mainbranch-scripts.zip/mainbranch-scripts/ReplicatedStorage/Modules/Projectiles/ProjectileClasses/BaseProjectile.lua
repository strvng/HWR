--[[
    BaseProjectile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local Debris = game:GetService("Debris")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Utilities = Modules:WaitForChild("Utilities")
local Customization = Modules:WaitForChild("Customization")

local CustomizationController = require(Customization:WaitForChild("CustomizationController"))
local DebrisFolder = require(Utilities:WaitForChild("DebrisFolder"))
local Settings = require(Projectiles:WaitForChild("Settings"))
local Signal = require(Utilities:WaitForChild("Signal"))

local Player = Players.LocalPlayer
local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local BaseProjectile = {}
BaseProjectile.__index = BaseProjectile
BaseProjectile.DebrisFolders = DebrisFolder
BaseProjectile.Settings = Settings

function BaseProjectile.GenerateId()
	return HttpService:GenerateGUID(false)
end

function BaseProjectile.new()
	local self = setmetatable({}, BaseProjectile)
	
	self.Id = BaseProjectile.GenerateId()
	self.Type = "Base"
	self.Trail = nil
	--self.Projectile = Prefab
	self.Destroyed = false
	self.Shooter = nil
	
	--Debris:AddItem(self.Projectile, 120)
	
	return self
end

function BaseProjectile.GetTrailController(Name)
	local TrailModule = CustomizationController.GetCustomization("Trail", Name)
	if TrailModule then
		return TrailModule.Application
	end
end

function BaseProjectile:ApplyTrail(Trail)
	local TrailController = BaseProjectile.GetTrailController(Trail)
	if TrailController then
		TrailController:Apply(self)
		
		self.Trail = TrailController
	end
end

function BaseProjectile:IsLocal()
	return self.Shooter == Player
end

function BaseProjectile:SetShooter(Shooter)
	self.Shooter = Shooter
end

function BaseProjectile:AddRequest(...)
	ReceiveIncoming:FireServer("AddRequest", self.Type, self.Id, ...)
end

function BaseProjectile:RemoveRequest(...)
	ReceiveIncoming:FireServer("RemoveRequest", self.Id, ...)
end

function BaseProjectile:Visualize(Parameters)
	
end

function BaseProjectile:Hit()
	
end

function BaseProjectile:Destroy()
	
end

return BaseProjectile