--[[
    SAMTankMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local ExplosiveProjectile = require(ProjectileClasses:WaitForChild("ExplosiveProjectile"))

local SAMTankMissile = setmetatable({}, ExplosiveProjectile)
SAMTankMissile.__index = SAMTankMissile

function SAMTankMissile.new()
	local Rocket = Instance.new("Part")
	Rocket.Name = "Missile"
	Rocket.CanCollide = true
	Rocket.Anchored = false
	Rocket.Transparency = 0
	Rocket.Reflectance = 0
	Rocket.Locked = true
	Rocket.Material = Enum.Material.Plastic
	Rocket.Size = Vector3.new(2, 2, 2)
	Rocket.BrickColor = BrickColor.new("Institutional white")
	
	local Mesh = Instance.new("SpecialMesh")
	Mesh.MeshId = "http://roblox.com/asset/?id=2251534"
	Mesh.Scale = Vector3.one
	Mesh.Parent = Rocket
	
	local Swoosh = Instance.new("Sound")
	Swoosh.Looped = true
	Swoosh.SoundId = "rbxassetid://12222095"
	Swoosh.Volume = 0.7
	Swoosh.Name = "Swoosh"
	Swoosh.Parent = Rocket
	
	local Explosion = Instance.new("Sound")
	Explosion.SoundId = "rbxassetid://12221984"
	Explosion.Volume = 0.7
	Explosion.Name = "Explosion"
	Explosion.PlayOnRemove = true
	Explosion.Parent = Rocket
	
	Swoosh:Play()
	
	--local BodyForce = Instance.new("BodyForce")
	--BodyForce.Force = Vector3.new(0, Rocket.AssemblyMass * workspace.Gravity, 0)
	--BodyForce.Parent = Rocket
	
	local self = setmetatable(ExplosiveProjectile.new(Rocket), SAMTankMissile)
	
	self:SetForce(ExplosiveProjectile.Settings.SAMTankMissile.ExplosionForce)
	self:SetRadius(ExplosiveProjectile.Settings.SAMTankMissile.ExplosionRadius)
	
	self.Type = "SAMTankMissile"
	
	return self
end

function computeLaunchAngle(dx,dy,grav, VELOCITY)
	local g = math.abs(grav)
	local inRoot = (VELOCITY*VELOCITY*VELOCITY*VELOCITY) - (g * ((g*dx*dx) + (2*dy*VELOCITY*VELOCITY)))
	if inRoot <= 0 then
		return .25 * math.pi
	end
	local root = math.sqrt(inRoot)
	local inATan1 = ((VELOCITY*VELOCITY) + root) / (g*dx)

	local inATan2 = ((VELOCITY*VELOCITY) - root) / (g*dx)
	local answer1 = math.atan(inATan1)
	local answer2 = math.atan(inATan2)
	if answer1 < answer2 then return answer1 end
	return answer2
end

function computeDirection(vec)
	local lenSquared = vec.magnitude * vec.magnitude
	local invSqrt = 1 / math.sqrt(lenSquared)
	return Vector3.new(vec.x * invSqrt, vec.y * invSqrt, vec.z * invSqrt)
end

function SAMTankMissile.GetLaunchAngle(EnginePosition, MousePosition, VELOCITY)
	
	EnginePosition = EnginePosition + Vector3.new(0, 12, 0)
	
	local Direction = computeDirection(MousePosition - EnginePosition)
	local Launch = EnginePosition + 20 * Direction
	local Delta = MousePosition - Launch
	
	local dy = Delta.Y
	
	local NewDelta = Vector3.new(Delta.X, 0, Delta.Z)
	Delta = NewDelta
	
	local dx = Delta.magnitude
	local UnitDelta = Delta.unit
	
	local gravity = (-9.81 * 18)
	
	local theta = computeLaunchAngle(dx, dy, gravity, VELOCITY)
	
	local vy = math.sin(theta)
	local xz = math.cos(theta)
	local vx = UnitDelta.X * xz
	local vz = UnitDelta.Z * xz
	
	return Vector3.new(vx, vy, vz), Launch
end

function SAMTankMissile:Visualize(Origin, Endpoint)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	local Character = Shooter.Character
	if Projectile and Shooter and Origin and Endpoint then
		local VELOCITY = ExplosiveProjectile.Settings.SAMTankMissile.Velocity
		local Angle, Launch = SAMTankMissile.GetLaunchAngle(Origin, Endpoint, VELOCITY)
		if Angle then
			Projectile.Position = Launch
			Projectile.Velocity = Angle * VELOCITY
			Projectile.CFrame = CFrame.new(Launch, Endpoint) * CFrame.Angles(math.rad(30), 0, 0)
		end
		
		Projectile.Touched:Connect(function(Hit)
			self:Hit(Hit)
		end)
		
		if self:IsLocal() then
			self:AddRequest(Origin, Endpoint)
		end
		
		Projectile.Parent = ExplosiveProjectile.DebrisFolders.Explosives
	end
end

function SAMTankMissile:Hit()
	local Projectile = self.Projectile
	if Projectile and not self.Exploded then
		local Position = Projectile.Position
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
			Trail.ExplodeEffect(Position)
		else
			ExplosiveProjectile.ExplodeEffect(Position)
		end
		
		if self:IsLocal() then
			local Parts = self:Explode()
			
			self:RemoveRequest(Position, Parts)
		end
		
		self:Destroy()
	end
end

return SAMTankMissile