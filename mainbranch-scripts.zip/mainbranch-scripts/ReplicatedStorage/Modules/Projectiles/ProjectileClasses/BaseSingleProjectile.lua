--[[
    BaseSingleProjectile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local Debris = game:GetService("Debris")

local ProjectileClasses = script.Parent

local BaseProjectile = require(ProjectileClasses:WaitForChild("BaseProjectile"))

local BaseSingleProjectile = setmetatable({}, BaseProjectile)
BaseSingleProjectile.__index = BaseSingleProjectile

function BaseSingleProjectile.new(Prefab)
	local self = setmetatable(BaseProjectile.new(), BaseSingleProjectile)
	
	self.Projectile = Prefab
	
	Debris:AddItem(self.Projectile, 120)
	
	return self
end

function BaseSingleProjectile.IsDescendantIfExists(Parent, Hit)
	return (not Parent and true) or (Parent and not Hit:IsDescendantOf(Parent))
end

function BaseSingleProjectile:ApplyTrail(Trail)
	local TrailController = BaseSingleProjectile.GetTrailController(Trail)
	if TrailController then
		TrailController:Apply(self)
		
		self.Trail = TrailController
	end
end

function BaseSingleProjectile:Destroy()
	local Projectile = self.Projectile
	if Projectile then
		Projectile:Destroy()
		self.Destroyed = true
	end
end

return BaseSingleProjectile