--[[
    MultiRocket (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local BaseGroupProjectile = require(ProjectileClasses:WaitForChild("BaseGroupProjectile"))
local SingleMultiRocket = require(script:WaitForChild("SingleMultiRocket"))

local Player = Players.LocalPlayer

local GroupMultiRocket = setmetatable({}, BaseGroupProjectile)
GroupMultiRocket.__index = GroupMultiRocket

function GroupMultiRocket.new()
	local self = setmetatable(BaseGroupProjectile.new(), GroupMultiRocket)
	
	for i = -15, 15, 5 do
		local NewRocket = SingleMultiRocket.new(self)
		NewRocket:SetOffset(CFrame.new(i, 0, -9))
		self:AddProjectile(NewRocket)
	end
	-- create 7 missiles with the offsets
	--local Missile1 = SinglePlaneMissile.new(self)
	--local Missile2 = SinglePlaneMissile.new(self)
	
	--self:AddProjectile(Missile1)
	--self:AddProjectile(Missile2)
	
	self.Type = "MultiRocket"
	
	return self
end

function GroupMultiRocket:Visualize(Origin, Endpoint)
	if self:IsLocal() then
		self:AddRequest(Origin, Endpoint)
	end
	
	for _, v in pairs(self.Projectiles) do
		v:Visualize(Origin, Endpoint)
	end
end

function GroupMultiRocket:Hit(Projectile, Parts)
	BaseGroupProjectile.Hit(self, Projectile)
	
	if self:IsLocal() then
		local ProjectileModel = Projectile.Projectile
		if ProjectileModel then
			self:RemoveRequest(ProjectileModel.Position, Parts)
		end
	end
end

return GroupMultiRocket