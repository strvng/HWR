--[[
    DeathMissile (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")

local BaseGroupProjectile = require(ProjectileClasses:WaitForChild("BaseGroupProjectile"))
local SingleDeathMissile = require(script:WaitForChild("SingleDeathMissile"))

local Player = Players.LocalPlayer

local GroupDeathMissile = setmetatable({}, BaseGroupProjectile)
GroupDeathMissile.__index = GroupDeathMissile

function GroupDeathMissile.new()
	local self = setmetatable(BaseGroupProjectile.new(), GroupDeathMissile)
	
	for i = 1, 5 do
		self:AddProjectile(SingleDeathMissile.new(self))
	end
	
	self.Type = "DeathMissile"
	
	return self
end

function GroupDeathMissile:Visualize(Handle, Target)
	if self:IsLocal() then
		self:AddRequest(Handle.Position, Target)
	end
	
	task.defer(function()
		for i = 5, 1, -1 do
			local v = self.Projectiles[i]
			v:Visualize(Handle, Target)
			task.wait(0.25)
		end
	end)
end

function GroupDeathMissile:Hit(Projectile, Parts)
	BaseGroupProjectile.Hit(self, Projectile)
	
	if self:IsLocal() then
		local ProjectileModel = Projectile.Projectile
		if ProjectileModel then
			self:RemoveRequest(ProjectileModel.Position, Parts)
		end
	end
end

return GroupDeathMissile