--[[
    JeepBullet (ModuleScript)
    Path: ReplicatedStorage → Modules → Projectiles → ProjectileClasses
    Parent: ProjectileClasses
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Explosions = Projectiles:WaitForChild("Explosions")
local ProjectileClasses = Projectiles:WaitForChild("ProjectileClasses")
local Vehicle = Modules:WaitForChild("Vehicle")

local VehicleHelper = require(Vehicle:WaitForChild("VehicleHelper"))
local BaseSingleProjectile = require(ProjectileClasses:WaitForChild("BaseSingleProjectile"))

local Player = Players.LocalPlayer

local JeepBullet = setmetatable({}, BaseSingleProjectile)
JeepBullet.__index = JeepBullet

function JeepBullet.new()
	local Bullet = Instance.new("Part")
	Bullet.Anchored = false
	Bullet.Transparency = 0
	Bullet.Reflectance = 0.5
	Bullet.BrickColor = BrickColor.new("Black")
	Bullet.CanCollide = true
	Bullet.TopSurface = Enum.SurfaceType.Smooth
	Bullet.BottomSurface = Enum.SurfaceType.Smooth
	Bullet.Size = Vector3.new(1, 1, 1)
	Bullet.Locked = true
	Bullet.Shape = Enum.PartType.Ball
	Bullet.Material = Enum.Material.Plastic
	Bullet.Name = "JeepBullet"
	--Bullet.CFrame = Gun.CFrame * CFrame.new(0, 0, -5)
	
	local BV = Instance.new("BodyVelocity")
	BV.P = 12500
	BV.MaxForce = Vector3.new(5000, 5000, 5000)
	--BV.Velocity = Bullet.CFrame.LookVector * WeaponSettings.JeepBullet.BulletSpeed
	BV.Parent = Bullet
	Bullet.Parent = Projectiles
	
	--Debris:AddItem(Bullet, WeaponSettings.JeepBullet.BulletDebris)
	
	--ApplyTrail(Bullet, Type, Ignore)
	
	local self = setmetatable(BaseSingleProjectile.new(Bullet), JeepBullet)
	
	self.Type = "JeepBullet"
	
	return self
end

function JeepBullet:Visualize(Origin)
	local Projectile = self.Projectile
	local Shooter = self.Shooter
	if Projectile and Shooter then
		local BV = Projectile:FindFirstChild("BodyVelocity")
		local Character = Shooter.Character
		if BV then
			Projectile.CFrame = Origin * CFrame.new(0, 0, -5)
			BV.Velocity = Projectile.CFrame.LookVector * BaseSingleProjectile.Settings.JeepBullet.BulletSpeed
			
			if self:IsLocal() then
				self:AddRequest(Origin)
			end
			
			Projectile.Touched:Connect(function(Hit)
				local Vehicle = VehicleHelper.GetVehicle(Shooter)
				if BaseSingleProjectile.IsDescendantIfExists(Character, Hit) and BaseSingleProjectile.IsDescendantIfExists(Vehicle, Hit) then
					self:Hit(Hit)
				end
			end)
			
			Projectile.Parent = BaseSingleProjectile.DebrisFolders.Projectiles
		end
	end
end

function JeepBullet:Hit(Hit)
	local Projectile = self.Projectile
	if Projectile then
		local Position = Projectile.Position
		
		--TrailDestroyEffect(Missile, Type, Ignore)
		--ExplosiveProjectile.ExplodeEffect(Position)
		
		local Trail = self.Trail
		if Trail then
			Trail:Hit(self)
		end
		
		if self:IsLocal() then
			self:RemoveRequest(Hit)
		end
		
		self:Destroy()
	end
end

return JeepBullet