--[[
    PlaySound (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming → Dagger
    Parent: Dagger
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")
local Dagger = Tools:WaitForChild("Dagger")

local DaggerHelper = require(Dagger:WaitForChild("DaggerHelper"))

return function(Player, Tool, Sound)
	DaggerHelper.PlaySound(Tool, Sound)
end