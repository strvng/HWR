--[[
    KillConfirmed (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")

local Spectate = require(Menus:WaitForChild("Spectate"))

return function(Killed, XP)
	if Killed and XP then
		Spectate:DisplayKill(Killed, XP)
	end
end