--[[
    StopControlling (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local VehicleModules = Modules:WaitForChild("Vehicle")

local VehicleController = require(VehicleModules:WaitForChild("VehicleController"))
--local Movement = VehicleModules:WaitForChild("Movement")
--local StopControllingFolder = Movement:WaitForChild("StopControlling")

--local FindVehicle = require(VehicleModules:WaitForChild("FindVehicle"))

local Player = Players.LocalPlayer

return function(Ignore, Vehicle)
	if Ignore ~= Player then
		local ActiveController = VehicleController:FindController(Vehicle)
		if ActiveController then
			ActiveController:Stop()
			ActiveController:Destroy()
		end
		--local GeneralVehicleType = FindVehicle:GetGeneralVehicleType(Vehicle)
		--if GeneralVehicleType then
		--	local StopControlling = StopControllingFolder:FindFirstChild(GeneralVehicleType)
		--	if StopControlling then
		--		StopControlling = require(StopControlling)
		--		StopControlling(Vehicle)
		--	end
		--end
	end
end