--[[
    SetVipFeatures (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local VIP = Modules:WaitForChild("VIP")

local VIPController = require(VIP:WaitForChild("VIP"))

return function(Doors, Teleporters)
	VIPController:SetDoors(Doors)
	VIPController:SetTeleporters(Teleporters)
end