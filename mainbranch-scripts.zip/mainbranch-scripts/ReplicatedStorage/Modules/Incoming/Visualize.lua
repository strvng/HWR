--[[
    Visualize (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Playes = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Data = Modules:WaitForChild("Data")

local ProjectileController = require(Projectiles:WaitForChild("ProjectileController"))
local DataController = require(Data:WaitForChild("DataController"))
--local Visualize = Modules:WaitForChild("Visualize")
--local VisualizeProjectile = require(Visualize:WaitForChild("VisualizeProjectile"))

local Player = Playes.LocalPlayer

return function(Shooter, Type, ...)
	-- how do we get the data acrossed
	if Shooter ~= Player then
		local ProjectileClass = ProjectileController:GetProjectile(Type)
		if ProjectileClass then
			local NewProjectile = ProjectileClass.new()
			local Trail = DataController:GetPlayerTrail(Shooter)
			NewProjectile:SetShooter(Shooter)
			NewProjectile:Visualize(...)
			NewProjectile:ApplyTrail(Trail)
		end
		-- get projectile type,
		-- set shooter
		-- apply trail
		-- visualize
		--VisualizeProjectile(Ignore, ...)
	end
end