--[[
    Endround (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Menu = Modules:WaitForChild("Menu")
local Menus = Menu:WaitForChild("Menus")
local General = Menu:WaitForChild("General")
local Settings = Modules:WaitForChild("Settings")
local Data = Modules:WaitForChild("Data")

local Player = Players.LocalPlayer

local DataController = require(Data:WaitForChild("DataController"))

local Results = require(Menus:WaitForChild("Results"))
local Blur = require(General:WaitForChild("Blur"))
local TeamScore = require(Menus:WaitForChild("TeamScore"))
local WinnerText = require(Menus:WaitForChild("WinnerText"))
local XPDifference = require(Menus:WaitForChild("XPDifference"))
local UI = require(Settings:WaitForChild("UI"))

local function Attempt(Function, Error)
	local Success, Result = pcall(Function)

	if not Success then
		warn(string.format("%s :: %s", Error, Result))
	end
end

return function(Data, TeamData, Experience, CurrentStats)
	Blur:Show()
	TeamScore:Hide()
	-- fix for blur not being disabled
	task.defer(function()
		task.wait(13)
		if Blur.BlurEffect.Enabled then
			warn('blur should not have been visible')
		end
		if not TeamScore.Visible then
			warn('team score should have already been visible')
		end
		Blur:Hide()
		TeamScore:Show()

		--if Blur.BlurEffect.Enabled then
		--	local function GetDictLength(Dict)
		--		local c = 0

		--		for _, _ in pairs(Dict) do
		--			c += 1
		--		end

		--		return c
		--	end
		--	local function Tostring(Table, Name, Indents)
		--		local out = ""
		--		out = string.format("%s (%i) Items\n", Name, GetDictLength(Table))

		--		if not Indents then
		--			Indents = 1
		--		end

		--		for k, v in pairs(Table) do
		--			if typeof(v) == "table" then
		--				Tostring(v, k, Indents+1)
		--			else
		--				out = out .. string.format("%s%s | %s\n", string.rep("  ", Indents), tostring(k), tostring(v))
		--			end
		--		end
		--		out = out .. "End of " .. Name
		--		return out
		--	end

		--warn('Blur should not have been visible.\nDebug output:')
		--warn(Tostring(Data, "Data"))
		--warn(Tostring(TeamData, "TeamData"))
		--warn(Tostring(Experience, "Experience"))
		--warn(Tostring(CurrentStats, "CurrentStats"))
		--end
	end)

	Attempt(function()
		task.defer(function()
			TeamScore:WaitForTeams()
		end)
	end, "Wait for teams failed")

	task.delay(UI.WinnerText.BlurDelay, function()
		TeamScore:ClearTeams()

		Attempt(function()
			if TeamData ~= nil then
				local TruncatedName = Results.TruncateTeam(TeamData.Name)

				WinnerText:SetTeam({
					Name = TruncatedName,
					TeamColor = TeamData.TeamColor.Color
				})

				WinnerText:FullShow()
			end
		end, "Team data display failed")

		--task.wait(UI.Results.WinnersTextDisplayTime)
		--WinnersText:SetEnabled(false)
		--task.wait(UI.Results.WinnersHiddenTime)

		Attempt(function()
			if Experience ~= nil then
				local StartXP = Experience[Player.Name]
				if StartXP then
					local CurrentXP = {
						XP = DataController:GetXP(),
						Level = DataController:GetLevel()
					}

					if CurrentXP.Level ~= StartXP.Level or CurrentXP.XP ~= StartXP.XP then
						XPDifference:Show()

						XPDifference:PlayAnimation(StartXP, CurrentXP)
						XPDifference.FullyClosed:Wait()
					end

					--XPDifference:Play(StartXP)
					--XPDifference.PlayOnShow = true
					--Results.ShowXPOnClose = true
				end
			end
		end, "Experience failed")

		--Results.ClearDataOnClose = true

		Attempt(function()
			if Data and TeamData and CurrentStats then
				Results:DisplayResults(Data, TeamData, CurrentStats)

				Results:Show()
			end

			task.wait(UI.WinnerText.BlurDelay)

			Blur:Hide()
		end, "Final section failed")
	end)
end

--local StartXP = Experience[Player.Name]
--if StartXP then
--	XPDifference:SetData(StartXP)
--	XPDifference.PlayOnShow = true
--	Results.ShowXPOnClose = true
--end

--Results.ClearDataOnClose = true
--Results:ShowData(Data, Experience)
--Results:Show()
-- ^ show the end screen