--[[
    SetGamepassOwned (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local GamepassFolder = Modules:WaitForChild("Gamepass")
local GamepassManager = require(GamepassFolder:WaitForChild("GamepassController"))

return function(Id)
	GamepassManager:SetGamepassOwned(Id)
end