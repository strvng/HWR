--[[
    Dagger (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

local Player = Players.LocalPlayer

return function(Action, SwordPlayer, ...)
	if SwordPlayer == Player then
		return
	end
	
	local Module = script:FindFirstChild(Action)
	if Module then
		require(Module)(SwordPlayer, ...)
	end
end