--[[
    SetVehicle (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local VehicleModules = Modules:WaitForChild("Vehicle")

local VehicleController = require(VehicleModules:WaitForChild("VehicleController"))

return function(Vehicle)
	VehicleController:SetVehicle(Vehicle)
end