--[[
    SendMessage (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]
return function(Type, Settings)
	local Module = script:FindFirstChild(Type)
	if Module then
		require(Module)(Settings)
	end
end