--[[
    Default (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming → SendMessage
    Parent: SendMessage
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local StarterGui = game:GetService("StarterGui")

return function(Settings)
	StarterGui:SetCore("SendNotification", Settings)
end