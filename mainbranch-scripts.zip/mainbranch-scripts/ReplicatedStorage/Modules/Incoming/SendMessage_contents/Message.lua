--[[
    Message (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming → SendMessage
    Parent: SendMessage
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local Players = game:GetService("Players")
local Debris = game:GetService("Debris")

local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

return function(Settings)
	local Display = Instance.new("ScreenGui")
	local Message = Instance.new("TextLabel")
	Display.Name = "Display"
	Display.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
	Message.AnchorPoint = Vector2.new(0.5, 0.5)
	Message.BackgroundColor3 = Color3.fromRGB(127, 127, 127)
	Message.BackgroundTransparency = 0.5
	Message.BorderColor3 = Color3.fromRGB(255, 255, 255)
	Message.BorderSizePixel = 0
	Message.Position = UDim2.new(0.5, 0, 0.5, 0)
	Message.Size = UDim2.new(1, 0, 1, 0)
	Message.Font = Enum.Font.Arial
	Message.Text = tostring(Settings.Text)
	Message.TextColor3 = Color3.fromRGB(255, 255, 255)
	Message.TextSize = 21.000
	Message.TextStrokeTransparency = 0
	Message.ZIndex = -10e10
	Message.Parent = Display
	Display.Parent = PlayerGui
	
	Debris:AddItem(Display, Settings.Time)
end