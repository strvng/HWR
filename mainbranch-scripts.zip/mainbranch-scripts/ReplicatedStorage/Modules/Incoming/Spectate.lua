--[[
    Spectate (ModuleScript)
    Path: ReplicatedStorage → Modules → Incoming
    Parent: Incoming
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local MenuFolder = Modules:WaitForChild("Menu")
local Menus = MenuFolder:WaitForChild("Menus")
local Data = Modules:WaitForChild("Data")

local DataController = require(Data:WaitForChild("DataController"))
local Spectate = require(Menus:WaitForChild("Spectate"))
--local Settings = Modules:WaitForChild("Settings")

--local PlayerSettings = require(Settings:WaitForChild("Player"))

return function(Attacker, Weapon)
	if DataController.Settings.Killcam and Attacker and Weapon then
		Spectate.SpectatePlayer(Attacker)
		Spectate:DisplayKiller(Attacker, Weapon)
		--SpectatePlayer(Attacker)
		--DisplayKiller(Attacker, Weapon)
	end
end