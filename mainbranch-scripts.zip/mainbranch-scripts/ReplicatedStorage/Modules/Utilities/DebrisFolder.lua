--[[
    DebrisFolder (ModuleScript)
    Path: ReplicatedStorage → Modules → Utilities
    Parent: Utilities
    Exported: 2026-09-21 11:23:24
]]

local DebrisFolder = workspace:WaitForChild("Debris")
local Explosives = DebrisFolder:WaitForChild("Explosives")
local Other = DebrisFolder:WaitForChild("Other")
local ProjectilesDebris = DebrisFolder:WaitForChild("Projectiles")
local ClearOnRegen = DebrisFolder:WaitForChild("ClearOnRegen")
local Vehicles = DebrisFolder:WaitForChild("Vehicles")

return {
	Explosives = Explosives,
	Other = Other,
	Projectiles = ProjectilesDebris,
	ClearOnRegen = ClearOnRegen,
	Vehicles = Vehicles
}