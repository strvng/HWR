--[[
    Destroyed (ModuleScript)
    Path: ReplicatedStorage → Modules → Utilities
    Parent: Utilities
    Exported: 2026-09-21 11:23:24
]]

return function(Object, Callback)
	local Connection;
	
	Connection = Object.AncestryChanged:Connect(function(Child, Parent)
		if not Parent then
			Callback()
			
			if Connection then
				Connection:Disconnect()
				Connection = nil
			end
		end
	end)
	
	return Connection
end