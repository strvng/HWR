--[[
    GetDictionaryLength (ModuleScript)
    Path: ReplicatedStorage → Modules → Utilities
    Parent: Utilities
    Exported: 2026-09-21 11:23:24
]]

return function(Dictionary)
	local Count = 0
	
	for _, _ in pairs(Dictionary) do
		Count += 1 
	end
	
	return Count
end