--[[
    Timer (ModuleScript)
    Path: ReplicatedStorage → Modules → Utilities
    Parent: Utilities
    Exported: 2026-09-21 11:23:24
]]

local RunService = game:GetService("RunService")

local Timer = {
	Listen = {
		
	}
}

RunService.Heartbeat:Connect(function(Delta)
	for i, v in pairs(Timer.Listen) do
		v.Time += Delta
		
		if v.Time >= v.Max then
			v.Time = 0
			
			v.Function()
		end
	end
end)

function Timer:Subscribe(Id, Function, Max)
	table.insert(
		self.Listen,
		{
			Max = Max,
			Time = 0,
			Function = Function,
			Id = Id,
		}
	)
end

function Timer:Unsubscribe(Id)
	for i, v in pairs(self.Listen) do
		if v.Id == Id then
			table.remove(self.Listen, i)
			break
		end
	end
end

return Timer