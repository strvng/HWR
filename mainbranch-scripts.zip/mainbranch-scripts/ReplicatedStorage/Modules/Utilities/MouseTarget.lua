--[[
    MouseTarget (ModuleScript)
    Path: ReplicatedStorage → Modules → Utilities
    Parent: Utilities
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

local Player = Players.LocalPlayer
local Mouse = Player:GetMouse()

local MouseTarget = {}

local RaycastParameters = RaycastParams.new()
RaycastParameters.FilterType = Enum.RaycastFilterType.Exclude

function MouseTarget.GetTargetWithIgnoreList(Ignore)
	local UnitRay = Mouse.UnitRay
	
	RaycastParameters.FilterDescendantsInstances = {Player.Character, table.unpack(Ignore)}
	
	local Result = workspace:Raycast(
		UnitRay.Origin,
		UnitRay.Direction * 10000,
		RaycastParameters
	)
	
	if Result then
		return Result.Instance
	end
end

function MouseTarget.GetPositionWithIgnoreList(Ignore)
	local UnitRay = Mouse.UnitRay
	
	RaycastParameters.FilterDescendantsInstances = {Player.Character, table.unpack(Ignore)}
	
	local Result = workspace:Raycast(
		UnitRay.Origin,
		UnitRay.Direction * 10000,
		RaycastParameters
	)
	
	if Result then
		return Result.Position
	else
		return UnitRay.Direction * 10000
	end
end

return MouseTarget