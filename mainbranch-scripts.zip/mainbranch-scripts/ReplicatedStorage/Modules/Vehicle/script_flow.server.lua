--[[
    script flow (Script)
    Path: ReplicatedStorage → Modules → Vehicle
    Parent: Vehicle
    Properties:
        Disabled: false
        RunContext: Enum.RunContext.Legacy
    Exported: 2026-09-21 11:23:24
]]

--[[
Vehicle
	Vehicle(class)
		Vehicle:Step()
		Vehicle:Destroy()
	VehicleController static
		:StartControlling
		:StopControlling
]]