--[[
    MovingVehicle (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local VehicleModules = Modules:WaitForChild("Vehicle")
local VehicleControllers = VehicleModules:WaitForChild("VehicleControllers")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")
local Player = Players.LocalPlayer

local BaseVehicleController = require(VehicleControllers:WaitForChild("BaseVehicleController"))

local MovingVehicle = setmetatable({}, BaseVehicleController)
MovingVehicle.__index = MovingVehicle
MovingVehicle.Settings = BaseVehicleController.Settings
MovingVehicle.Input = BaseVehicleController.Input

function MovingVehicle.new(Model)
	local self = setmetatable(BaseVehicleController.new(Model), MovingVehicle)
	
	self.Model = Model
	self.Speed = 0
	self.Moving = false
	self.Stunt = false
	self.StuntDebounce = false
	self.Steering = false
	self.BackgroundEnabled = true
	
	self.Engine = self:GetEngine()
	self.BodyGyro = self:GetBodyGyro()
	
	return self
end

function MovingVehicle:_SetFlyingServerState(Flying)
	ReceiveIncoming:FireServer("Vehicle", "SetFlying", Flying)
end

function MovingVehicle:Steer(DirectionCFrame)
	local BodyGyro = self.BodyGyro
	if BodyGyro and self:CanSteer() then
		BodyGyro.CFrame = DirectionCFrame
	end
end

function MovingVehicle.PilotIsSeated(Model)
	local Character = Player.Character
	if Model and Character then
		local Humanoid = Character:FindFirstChild("Humanoid")
		if Humanoid then
			local SeatPart = Humanoid.SeatPart
			
			return SeatPart and SeatPart:IsDescendantOf(Model) and SeatPart:HasTag("VehicleController")
		end
	end
end

function MovingVehicle:CanProcessInput()
	return self.PilotIsSeated(self.Model)
end

function MovingVehicle:CanSteer()
	return not self.Stunt and self.PilotIsSeated(self.Model) and self.Moving
end

function MovingVehicle:EnableBodyGyro(Enabled)
	local BodyGyro = self.BodyGyro
	local Engine = self.Engine
	if BodyGyro and Engine and self:CanSteer() then
		if Enabled then
			BodyGyro.MaxTorque = MovingVehicle.Settings.SteerForce
		else
			BodyGyro.MaxTorque = Vector3.zero
			Engine.RotVelocity = Vector3.zero
		end
	end
end

--function MovingVehicle:SetSteering(Steering)
--	local BodyGyro = self.BodyGyro
--	local Engine = self.Engine
--	if BodyGyro and Engine and self:CanSteer() then
--		if Steering then
--			BodyGyro.MaxTorque = MovingVehicle.Settings.SteerForce
--		else
--			BodyGyro.MaxTorque = Vector3.zero
--			Engine.RotVelocity = Vector3.zero
--		end
--	end
	
--	self.Steering = Steering
--end

function MovingVehicle:GetEngine()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("Engine")
	end
end

function MovingVehicle:GetBodyGyro()
	local Engine = self:GetEngine()
	if Engine then
		return Engine:FindFirstChild("BodyGyro")
	end
end

function MovingVehicle:GetClientFolder()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("Client")
	end
end

function MovingVehicle:Step(Delta)
	
end

function MovingVehicle:Flip()
	local Client = self:GetClientFolder()
	local Engine = self.Engine
	local BodyGyro = self.BodyGyro
	
	if Engine and Client and BodyGyro then
		local StuntDebounce = Client:FindFirstChild("Stunt")
		if StuntDebounce and not StuntDebounce.Value then
			local OldTorq = BodyGyro.MaxTorque
			local EngineCF = Engine.CFrame
			
			StuntDebounce.Value = true
			self.Stunt = true
			self.StuntDebounce = true
			
			BodyGyro.MaxTorque = BaseVehicleController.Settings.SteerForce
			
			for i = 1, 8 do
				BodyGyro.CFrame = EngineCF * CFrame.Angles(0, (i * 50), (i * 100))
				task.wait(0.1)
			end
			
			BodyGyro.CFrame = EngineCF * CFrame.Angles(0, 600, 0)
			
			task.wait(1)
			
			BodyGyro.MaxTorque = OldTorq
			Engine.AssemblyAngularVelocity = Vector3.zero
			
			self.Stunt = false
			
			task.wait(BaseVehicleController.Settings.FlipDebounce)
			
			self.StuntDebounce = false
			StuntDebounce.Value = false
		end
	end
end

function MovingVehicle:Roll()
	local Client = self:GetClientFolder()
	local Engine = self.Engine
	local BodyGyro = self.BodyGyro
	
	if Engine and Client and BodyGyro then
		local StuntDebounce = Client:FindFirstChild("Stunt")
		if StuntDebounce and not StuntDebounce.Value then
			local EngineCF = Engine.CFrame
			local OldTorq = BodyGyro.MaxTorque
			
			StuntDebounce.Value = true
			self.Stunt = true
			self.StuntDebounce = true
			BodyGyro.MaxTorque =  BaseVehicleController.Settings.SteerForce
			
			for i = 1, 12 do
				BodyGyro.CFrame = Engine.CFrame * CFrame.Angles(0, 0, 30)
				task.wait(0.1)
			end
			
			BodyGyro.CFrame = EngineCF
			
			task.wait(0.6)
			
			BodyGyro.MaxTorque = OldTorq
			self.Stunt = false
			--State.CanSteer = true
			Engine.AssemblyAngularVelocity = Vector3.new()
			
			task.wait(BaseVehicleController.Settings.RollDebounce)
			
			self.StuntDebounce = false
			StuntDebounce.Value = false
		end
	end
end

function MovingVehicle:Start()
	local Client = self:GetClientFolder()
	if Client then
		local IsMoving = Client:FindFirstChild("Moving")
		if IsMoving then
			IsMoving.Value = true
		end
	end
	
	self:_SetFlyingServerState(true)
	
	MovingVehicle._StartRender(self)
	self.Moving = true
end

function MovingVehicle:Stop()
	local Client = self:GetClientFolder()
	if Client then
		local IsMoving = Client:FindFirstChild("Moving")
		if IsMoving then
			IsMoving.Value = false
		end
	end
	
	self:_SetFlyingServerState(false)
	
	MovingVehicle._StopRender(self)
	self.Moving = false
end

return MovingVehicle