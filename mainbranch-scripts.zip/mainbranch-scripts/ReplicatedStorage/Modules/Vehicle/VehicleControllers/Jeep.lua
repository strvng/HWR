--[[
    Jeep (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local VehicleControllers = Vehicle:WaitForChild("VehicleControllers")
--local Visualize = Modules:WaitForChild("Visualize")
local Projectiles = Modules:WaitForChild("Projectiles")
local Data = Modules:WaitForChild("Data")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local VehicleDebounce = require(Vehicle:WaitForChild("VehicleDebounce"))
local DataController = require(Data:WaitForChild("DataController"))
local ProjectileController = require(Projectiles:WaitForChild("ProjectileController"))
local MovingVehicle = require(VehicleControllers:WaitForChild("MovingVehicle"))
local WeaponSettings = require(Projectiles:WaitForChild("Settings"))

local Player = Players.LocalPlayer

local ProjectileType = "JeepBullet"
local ProjectileSettings = WeaponSettings.JeepBullet

local Jeep = setmetatable({}, MovingVehicle)
Jeep.__index = Jeep

function Jeep.new(Model)
	local self = setmetatable(MovingVehicle.new(Model), Jeep)
	
	self.InputController = "Jeep"
	
	return self
end

function Jeep:GetGun()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("MachineGun")
	end
end

function Jeep:Fire()
	local JeepBullet = ProjectileController:GetProjectile(ProjectileType)
	if JeepBullet then
		local Model = self.Model
		local Gun = self:GetGun()
		if Gun and Model and VehicleDebounce:CanFire(Model, ProjectileType, ProjectileSettings.Cooldown) then
			local NewJeepBullet = JeepBullet.new()
			NewJeepBullet:SetShooter(Player)
			NewJeepBullet:Visualize(Gun.CFrame)
			NewJeepBullet:ApplyTrail(
				DataController:GetPlayerTrail(Player)
			)
		end
	end
end

function Jeep:GetWheels()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("Wheels")
	end
end

function Jeep:GetSpeed()
	local Model = self.Model
	if Model then
		local Speed = Model:GetAttribute("Speed")
		if Speed then
			return Speed
		end
	end
	
	return MovingVehicle.Settings.JeepSpeed
end

function Jeep:SetWheelSpeed(Speed)
	local Wheels = self:GetWheels()
	if Wheels and Speed then
		for i, v in pairs(Wheels:GetChildren()) do
			if v.Name == "Forward" then
				v.RightParamB = Speed
				v.RightParamA = Speed * -1
			elseif v.Name == "Backward" then
				v.RightParamB = Speed * -1
				v.RightParamA = Speed
			end
		end
	end
end

function Jeep:Start()
	local Client = self:GetClientFolder()
	if Client then
		local Speed = self:GetSpeed()
		if Speed then
			self:SetWheelSpeed(Speed)
		end
	end
	
	MovingVehicle.Start(self)
end

function Jeep:Stop()
	local BodyGyro = self.BodyGyro
	
	if BodyGyro then
		BodyGyro.MaxTorque = Vector3.zero
	end
	
	self:SetWheelSpeed(0)
	MovingVehicle.Stop(self)
end

function Jeep:Step(Delta)
	local Model = self.Model
	if Model and self.Moving then
		local Engine = self.Engine
		local BodyGyro = self.BodyGyro
		
		--if Engine and self.Steering and BodyGyro and self:CanSteer() then
		--	local Position = MovingVehicle.Input:GetMousePosition()
		--	if Position then
		--		BodyGyro.CFrame = Position
		--	end
		--end
	end
end

return Jeep