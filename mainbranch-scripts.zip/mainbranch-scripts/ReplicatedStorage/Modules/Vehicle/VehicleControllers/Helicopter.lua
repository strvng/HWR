--[[
    Helicopter (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local VehicleControllers = Vehicle:WaitForChild("VehicleControllers")
--local Visualize = Modules:WaitForChild("Visualize")
local Projectiles = Modules:WaitForChild("Projectiles")
local Data = Modules:WaitForChild("Data")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local ProjectileController = require(Projectiles:WaitForChild("ProjectileController"))
local DataController = require(Data:WaitForChild("DataController"))
--local VisualizeProjectile = require(Visualize:WaitForChild("VisualizeProjectile"))
--local WeaponSettings = require(Weapons:WaitForChild("WeaponSettings"))
local MovingVehicle = require(VehicleControllers:WaitForChild("MovingVehicle"))
local VehicleDebounce = require(Vehicle:WaitForChild("VehicleDebounce"))
local WeaponSettings = require(Projectiles:WaitForChild("Settings"))

local ProjectileType = "PlaneMissile"
local ProjectileSettings = WeaponSettings.PlaneMissile

local Player = Players.LocalPlayer

local Helicopter = setmetatable({}, MovingVehicle)
Helicopter.__index = Helicopter

function Helicopter.new(Model)
	local self = setmetatable(MovingVehicle.new(Model), Helicopter)
	
	self.BodyVelocity = self:GetBodyVelocity()
	self.InputController = "Helicopter"
	
	return self
end

function Helicopter:GetBodyVelocity()
	local Engine = self:GetEngine()
	if Engine then
		return Engine:FindFirstChild("BodyVelocity")
	end
end

function Helicopter:GetGuns()
	local Model = self.Model
	if Model then
		local Guns = Model:FindFirstChild("Guns")
		if Guns then
			return Guns:GetChildren()
		end
	end
end

function Helicopter:Fire()
	local GroupPlaneMissile = ProjectileController:GetProjectile(ProjectileType)
	if GroupPlaneMissile then
		local Model = self.Model
		local Guns = self:GetGuns()
		if Guns and Model and VehicleDebounce:CanFire(Model, ProjectileType, ProjectileSettings.Cooldown) then
			local NewGroupMissile = GroupPlaneMissile.new()
			local Origins = NewGroupMissile.ParseGuns(Guns)
			NewGroupMissile:SetShooter(Player)
			NewGroupMissile:Visualize(Origins)
			NewGroupMissile:ApplyTrail(
				DataController:GetPlayerTrail(Player)
			)
		end
	end
	-- collect all the guns and do the full visualize process
	-- check if the vehicle can fire
	--local BulletType = "PlaneMissile"
	--local Data = WeaponSettings[BulletType]
	--if Data then
	--	local Id = HttpService:GenerateGUID(false)
	--	local Guns = self:GetGuns()
		
	--	VisualizeProjectile(Player, BulletType, true, Id, Guns)
	--	ReceiveIncoming:FireServer("AddRequest", BulletType, Id, Guns)
		
	--	DebounceList:AddToList(Equipped, Data.Cooldown)
	--end
end

function Helicopter:Start()
	local Client = self:GetClientFolder()
	local BodyVelocity = self.BodyVelocity
	if Client and BodyVelocity then
		BodyVelocity.MaxForce = MovingVehicle.Settings.FlyingForce
	end
	
	MovingVehicle.Start(self)
end

function Helicopter:Stop()
	local BodyVelocity = self.BodyVelocity
	local BodyGyro = self.BodyGyro
	
	if BodyVelocity then
		BodyVelocity.MaxForce = Vector3.zero
		BodyVelocity.Velocity = Vector3.zero
	end
	
	if BodyGyro then
		BodyGyro.MaxTorque = Vector3.zero
	end
	
	MovingVehicle.Stop(self)
end

function Helicopter:Step(Delta)
	local Model = self.Model
	if Model and self.Moving then
		local Engine = self.Engine
		local BodyVelocity = self.BodyVelocity
		local BodyGyro = self.BodyGyro
		
		if Engine then
			if BodyVelocity then
				BodyVelocity.Velocity = Engine.CFrame.LookVector * MovingVehicle.Settings.HelicopterSpeed
			end
			
			--if self.Steering and BodyGyro and self:CanSteer() then
			--	local Position = MovingVehicle.Input:GetMousePosition()
			--	if Position then
			--		BodyGyro.CFrame = Position
			--	end
			--end
		end
	end
end

return Helicopter