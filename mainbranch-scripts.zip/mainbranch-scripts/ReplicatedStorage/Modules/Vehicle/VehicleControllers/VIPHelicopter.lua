--[[
    VIPHelicopter (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local VehicleControllers = Vehicle:WaitForChild("VehicleControllers")
local Projectiles = Modules:WaitForChild("Projectiles")
local Data = Modules:WaitForChild("Data")

local ProjectileController = require(Projectiles:WaitForChild("ProjectileController"))
local MovingVehicle = require(VehicleControllers:WaitForChild("MovingVehicle"))
local WeaponSettings = require(Projectiles:WaitForChild("Settings"))
local VehicleDebounce = require(Vehicle:WaitForChild("VehicleDebounce"))
local DataController = require(Data:WaitForChild("DataController"))

local Player = Players.LocalPlayer

local Projectiles = {
	VipMissile = {
		Type = "VipMissile",
		Settings = WeaponSettings.VipMissile
	},
	Bomb = {
		Type = "Bomb",
		Settings = WeaponSettings.Bomb
	},
	HomingMissile = {
		Type = "HomingMissile",
		Settings = WeaponSettings.HomingMissile
	}
}

local VIPHelicopter = setmetatable({}, MovingVehicle)
VIPHelicopter.__index = VIPHelicopter

function VIPHelicopter.new(Model)
	local self = setmetatable(MovingVehicle.new(Model), VIPHelicopter)
	
	self.BodyVelocity = self:GetBodyVelocity()
	self.InputController = "VIPHelicopter"
	
	return self
end

function VIPHelicopter:GetBodyVelocity()
	local Engine = self:GetEngine()
	if Engine then
		return Engine:FindFirstChild("BodyVelocity")
	end
end

function VIPHelicopter:GetGuns()
	local Model = self.Model
	if Model then
		local Guns = Model:FindFirstChild("Guns")
		if Guns then
			return Guns:GetChildren()
		end
	end
end

function VIPHelicopter:GetHomingGuns()
	local Model = self.Model
	if Model then
		local Guns = Model:FindFirstChild("HomingGuns")
		if Guns then
			return Guns:GetChildren()
		end
	end
end

function VIPHelicopter:Fire()
	local GroupVipMissile = ProjectileController:GetProjectile(Projectiles.VipMissile.Type)
	if GroupVipMissile then
		local Model = self.Model
		local Guns = self:GetGuns()
		if Guns and Model and VehicleDebounce:CanFire(Model, Projectiles.VipMissile.Type, Projectiles.VipMissile.Settings.Cooldown) then
			local NewGroupMissile = GroupVipMissile.new()
			local Origins = NewGroupMissile.ParseGuns(Guns)
			NewGroupMissile:SetShooter(Player)
			NewGroupMissile:Visualize(Origins)
			NewGroupMissile:ApplyTrail(
				DataController:GetPlayerTrail(Player)
			)
		end
	end
end

function VIPHelicopter:DropBomb()
	local BombProjectile = ProjectileController:GetProjectile(Projectiles.Bomb.Type)
	if BombProjectile then
		local Model = self.Model
		local Engine = self.Engine
		if Engine and Model and VehicleDebounce:CanFire(Model, Projectiles.Bomb.Type, Projectiles.Bomb.Settings.Cooldown) then
			local NewBomb = BombProjectile.new()
			NewBomb:SetShooter(Player)
			NewBomb:Visualize(Engine.CFrame)
			NewBomb:ApplyTrail(
				DataController:GetPlayerTrail(Player)
			)
		end
	end
end

function VIPHelicopter:FireHoming(Target)
	local GroupHomingMissile = ProjectileController:GetProjectile(Projectiles.HomingMissile.Type)
	if GroupHomingMissile then
		local Model = self.Model
		local Guns = self:GetHomingGuns()
		if Guns and Model and VehicleDebounce:CanFire(Model, Projectiles.HomingMissile.Type, Projectiles.HomingMissile.Settings.Cooldown) then
			local NewGroupMissile = GroupHomingMissile.new()
			local Origins = NewGroupMissile.ParseGuns(Guns)
			NewGroupMissile:SetShooter(Player)
			NewGroupMissile:Visualize(Origins, Target)
			NewGroupMissile:ApplyTrail(
				DataController:GetPlayerTrail(Player)
			)
		end
	end
end

function VIPHelicopter:Start()
	local Client = self:GetClientFolder()
	local BodyVelocity = self.BodyVelocity
	if Client and BodyVelocity then
		BodyVelocity.MaxForce = MovingVehicle.Settings.FlyingForce
	end
	
	MovingVehicle.Start(self)
end

function VIPHelicopter:Stop()
	local BodyVelocity = self.BodyVelocity
	local BodyGyro = self.BodyGyro
	
	if BodyVelocity then
		BodyVelocity.MaxForce = Vector3.zero
		BodyVelocity.Velocity = Vector3.zero
	end
	
	if BodyGyro then
		BodyGyro.MaxTorque = Vector3.zero
	end
	
	MovingVehicle.Stop(self)
end

function VIPHelicopter:Step(Delta)
	local Model = self.Model
	if Model and self.Moving then
		local Engine = self.Engine
		local BodyVelocity = self.BodyVelocity
		local BodyGyro = self.BodyGyro
		
		if Engine then
			if BodyVelocity then
				BodyVelocity.Velocity = Engine.CFrame.LookVector * MovingVehicle.Settings.HelicopterSpeed
			end
			
			--if self.Steering and BodyGyro and self:CanSteer() then
			--	local Position = MovingVehicle.Input:GetMousePosition()
			--	if Position then
			--		BodyGyro.CFrame = Position
			--	end
			--end
		end
	end
end

return VIPHelicopter