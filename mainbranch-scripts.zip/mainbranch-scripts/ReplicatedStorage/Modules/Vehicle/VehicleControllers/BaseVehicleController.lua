--[[
    BaseVehicleController (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")

local Settings = require(Vehicle:WaitForChild("Settings"))

local BaseVehicleController = {}
BaseVehicleController.__index = BaseVehicleController
BaseVehicleController.Settings = Settings

function BaseVehicleController.new(Model)
	local self = setmetatable({}, BaseVehicleController)
	
	self.Model = Model
	self.InputController = "Base"
	self.BackgroundEnabled = false
	
	return self
end

function BaseVehicleController._StartRender(self)
	BaseVehicleController._StopRender(self)

	self.SteppedConnection = RunService.Stepped:Connect(function(Time, Delta)
		self:Step(Delta)
	end)
end

function BaseVehicleController._StopRender(self)
	local SteppedConnection = self.SteppedConnection
	if SteppedConnection then
		SteppedConnection:Disconnect()
		self.SteppedConnection = nil
	end
end

function BaseVehicleController:Step()
	
end

function BaseVehicleController:Destroy()
	
end

return BaseVehicleController