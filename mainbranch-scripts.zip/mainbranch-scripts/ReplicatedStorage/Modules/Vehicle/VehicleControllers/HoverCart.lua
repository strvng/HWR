--[[
    HoverCart (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local VehicleControllers = Vehicle:WaitForChild("VehicleControllers")
local Projectiles = Modules:WaitForChild("Projectiles")
local Data = Modules:WaitForChild("Data")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local ProjectileController = require(Projectiles:WaitForChild("ProjectileController"))
local MovingVehicle = require(VehicleControllers:WaitForChild("MovingVehicle"))

local Player = Players.LocalPlayer

local HoverCart = setmetatable({}, MovingVehicle)
HoverCart.__index = HoverCart

function HoverCart.new(Model)
	local self = setmetatable(MovingVehicle.new(Model), HoverCart)
	
	self.BodyVelocity = self:GetBodyVelocity()
	self.InputController = "HoverCart"
	
	return self
end

function HoverCart:GetBodyVelocity()
	local Engine = self:GetEngine()
	if Engine then
		return Engine:FindFirstChild("BodyVelocity")
	end
end

function HoverCart:GetGuns()
	local Model = self.Model
	if Model then
		local Guns = Model:FindFirstChild("Guns")
		if Guns then
			return Guns:GetChildren()
		end
	end
end

function HoverCart:Start()
	local Client = self:GetClientFolder()
	local BodyVelocity = self.BodyVelocity
	if Client and BodyVelocity then
		BodyVelocity.MaxForce = MovingVehicle.Settings.FlyingForce
	end
	
	MovingVehicle.Start(self)
end

function HoverCart:Stop()
	local BodyVelocity = self.BodyVelocity
	local BodyGyro = self.BodyGyro
	
	if BodyVelocity then
		BodyVelocity.MaxForce = Vector3.zero
		BodyVelocity.Velocity = Vector3.zero
	end
	
	if BodyGyro then
		BodyGyro.MaxTorque = Vector3.zero
	end
	
	MovingVehicle.Stop(self)
end

function HoverCart:Step(Delta)
	local Model = self.Model
	if Model and self.Moving then
		local Engine = self.Engine
		local BodyVelocity = self.BodyVelocity
		local BodyGyro = self.BodyGyro
		
		if Engine then
			if BodyVelocity then
				BodyVelocity.Velocity = Engine.CFrame.LookVector * MovingVehicle.Settings.HelicopterSpeed * 1.5
			end
		end
	end
end

return HoverCart