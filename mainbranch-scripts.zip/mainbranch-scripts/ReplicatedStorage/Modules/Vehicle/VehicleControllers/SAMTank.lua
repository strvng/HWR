--[[
    SAMTank (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local VehicleControllers = Vehicle:WaitForChild("VehicleControllers")
--local Visualize = Modules:WaitForChild("Visualize")
local Projectiles = Modules:WaitForChild("Projectiles")
local Data = Modules:WaitForChild("Data")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local VehicleDebounce = require(Vehicle:WaitForChild("VehicleDebounce"))
local DataController = require(Data:WaitForChild("DataController"))
local ProjectileController = require(Projectiles:WaitForChild("ProjectileController"))
local MovingVehicle = require(VehicleControllers:WaitForChild("MovingVehicle"))
local WeaponSettings = require(Projectiles:WaitForChild("Settings"))

local Player = Players.LocalPlayer

local ProjectileType = "SAMTankMissile"
local ProjectileSettings = WeaponSettings.SAMTankMissile

local SAMTank = setmetatable({}, MovingVehicle)
SAMTank.__index = SAMTank

function SAMTank.new(Model)
	local self = setmetatable(MovingVehicle.new(Model), SAMTank)
	
	self.InputController = "SAMTank"
	
	return self
end

function SAMTank:GetGun()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("Missile")
	end
end

function SAMTank:Fire(Position)
	local SAMTankBullet = ProjectileController:GetProjectile(ProjectileType)
	if SAMTankBullet then
		local Model = self.Model
		local Engine = self.Engine
		local Gun = self:GetGun()
		if Gun and Model and Engine and VehicleDebounce:CanFire(Model, ProjectileType, ProjectileSettings.Cooldown) then
			local NewSAMTankBullet = SAMTankBullet.new()
			NewSAMTankBullet:SetShooter(Player)
			NewSAMTankBullet:Visualize(Engine.Position, Position)
			NewSAMTankBullet:ApplyTrail(
				DataController:GetPlayerTrail(Player)
			)
		end
	end
end

function SAMTank:GetWheels()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("Wheels")
	end
end

function SAMTank:GetSpeed()
	local Model = self.Model
	if Model then
		local Speed = Model:GetAttribute("Speed")
		if Speed then
			return Speed
		end
	end
	
	return MovingVehicle.Settings.SAMTankSpeed
end

function SAMTank:SetWheelSpeed(Speed)
	local Engine = self.Engine
	if Engine and Speed then
		for i, v in pairs(Engine:GetChildren()) do
			if v.Name == "Forward" then
				v.AngularVelocity = Speed
			elseif v.Name == "Backward" then
				v.AngularVelocity = Speed * -1
			end
		end
	end
end

function SAMTank:Start()
	local Client = self:GetClientFolder()
	if Client then
		local Speed = self:GetSpeed()
		if Speed then
			self:SetWheelSpeed(Speed)
		end
	end
	
	MovingVehicle.Start(self)
end

function SAMTank:Stop()
	local BodyGyro = self.BodyGyro
	
	if BodyGyro then
		BodyGyro.MaxTorque = Vector3.zero
	end
	
	self:SetWheelSpeed(0)
	MovingVehicle.Stop(self)
end

function SAMTank:Flip()
	
end

function SAMTank:Roll()
	
end

return SAMTank