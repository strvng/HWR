--[[
    Jeep(climb jeep) (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → VehicleControllers
    Parent: VehicleControllers
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local VehicleControllers = Vehicle:WaitForChild("VehicleControllers")
--local Visualize = Modules:WaitForChild("Visualize")
local Projectiles = Modules:WaitForChild("Projectiles")
local Data = Modules:WaitForChild("Data")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local VehicleDebounce = require(Vehicle:WaitForChild("VehicleDebounce"))
local DataController = require(Data:WaitForChild("DataController"))
local ProjectileController = require(Projectiles:WaitForChild("ProjectileController"))
local MovingVehicle = require(VehicleControllers:WaitForChild("MovingVehicle"))
local WeaponSettings = require(Projectiles:WaitForChild("Settings"))

local Player = Players.LocalPlayer

local ProjectileType = "JeepBullet"
local ProjectileSettings = WeaponSettings.JeepBullet

local Jeep = setmetatable({}, MovingVehicle)
Jeep.__index = Jeep

function Jeep.new(Model)
	local self = setmetatable(MovingVehicle.new(Model), Jeep)
	
	self.InputController = "Jeep"
	
	local Engine = self.Engine
	if Engine then
		local ClimbVelocity = Instance.new("BodyVelocity")
		ClimbVelocity.MaxForce = Vector3.zero
		ClimbVelocity.Velocity = Vector3.zero
		ClimbVelocity.Parent = Engine
		
		self.FlyTime = 0
		self.ClimbVelocity = ClimbVelocity
	end
	
	return self
end

function Jeep:GetGun()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("MachineGun")
	end
end

function Jeep:Fire()
	local JeepBullet = ProjectileController:GetProjectile(ProjectileType)
	if JeepBullet then
		local Model = self.Model
		local Gun = self:GetGun()
		if Gun and Model and VehicleDebounce:CanFire(Model, ProjectileType, ProjectileSettings.Cooldown) then
			local NewJeepBullet = JeepBullet.new()
			NewJeepBullet:SetShooter(Player)
			NewJeepBullet:Visualize(Gun.CFrame)
			NewJeepBullet:ApplyTrail(
				DataController:GetPlayerTrail(Player)
			)
		end
	end
end

function Jeep:GetWheels()
	local Model = self.Model
	if Model then
		return Model:FindFirstChild("Wheels")
	end
end

function Jeep:GetSpeed()
	local Model = self.Model
	if Model then
		local Speed = Model:GetAttribute("Speed")
		if Speed then
			return Speed
		end
	end
	
	return MovingVehicle.Settings.JeepSpeed
end

function Jeep:SetWheelSpeed(Speed)
	local Wheels = self:GetWheels()
	if Wheels and Speed then
		for i, v in pairs(Wheels:GetChildren()) do
			if v.Name == "Forward" then
				v.RightParamB = Speed
				v.RightParamA = Speed * -1
			elseif v.Name == "Backward" then
				v.RightParamB = Speed * -1
				v.RightParamA = Speed
			end
		end
	end
end

function Jeep:Start()
	local Client = self:GetClientFolder()
	if Client then
		local Speed = self:GetSpeed()
		if Speed then
			self:SetWheelSpeed(Speed)
		end
	end
	
	MovingVehicle.Start(self)
end

function Jeep:Stop()
	local BodyGyro = self.BodyGyro
	
	if BodyGyro then
		BodyGyro.MaxTorque = Vector3.zero
	end
	
	self:SetWheelSpeed(0)
	MovingVehicle.Stop(self)
end

local debugs = Instance.new("Part")
debugs.Size = Vector3.one * 4
debugs.Parent = workspace
debugs.Anchored = true
debugs.CanCollide = false
debugs.CanQuery = false
debugs.BrickColor = BrickColor.random()

local function debug_ray(orig, dir)
	local x = Instance.new("Part", workspace)
	x.Size = Vector3.one * 2
	x.Anchored = true
	x.CanCollide = false
	x.CanQuery = false
	x.Transparency = 0.6
	x.BrickColor = BrickColor.Red()
	
	local y = x:Clone()
	y.Parent = workspace
	y.BrickColor = BrickColor.Blue()
	
	x.Position = orig
	y.Position = dir
	
	game.Debris:AddItem(x, 0.1)
	game.Debris:AddItem(y, 0.1)
end

local function RaycastWithExclude(Origin, Direction, Params, Criteria)
	local Result = workspace:Raycast(
		Origin,
		Direction,
		Params
	)
	
	if Result and Criteria(Result) then
		return Result
	elseif Result and Result.Instance then
		local New = table.clone(Params.FilterDescendantsInstances)
		table.insert(New, Result.Instance)
		Params.FilterDescendantsInstances = New
		
		return RaycastWithExclude(Origin, Direction, Params, Criteria)
	end
end

function Jeep:Step(Delta)
	local Model = self.Model
	if Model and self.Moving then
		local Engine = self.Engine
		local BodyGyro = self.BodyGyro
		local ClimbVelocity = self.ClimbVelocity
		if Engine and BodyGyro and ClimbVelocity then
			local MiddleCFrame, Size = Model:GetBoundingBox()
			
			local EngineCFrame = Engine.CFrame
			local LookVector = EngineCFrame.LookVector
			local Look = Vector3.new(LookVector.X, 0, LookVector.Z).Unit
			
			local pos = Player.Character.Torso.Position
			debugs.CFrame = CFrame.lookAt(pos, pos + Look) 
			
			for i = 1, 5 do
				local YPercent = i / 5
				local YPos = Size.Y * YPercent
				
				local RayParams = RaycastParams.new()
				RayParams.FilterDescendantsInstances = {Model, Player.Character}
				RayParams.FilterType = Enum.RaycastFilterType.Exclude
				
				local Origin = MiddleCFrame.Position - (Vector3.yAxis*(Size.Y/2)) + (Vector3.yAxis*YPos)
				
				ClimbVelocity.Velocity = Engine.CFrame.LookVector * 150
				
				debug_ray(Origin, Origin + Look * 10)
				
				local Result = RaycastWithExclude(
					Origin,
					Origin + Look * 10,
					RayParams,
					function(Result)
						local Part = Result.Instance
						if Part then
							local Size = Part.Size
							return Part.Transparency < 1 and Part.CanCollide and Part:FindFirstAncestor("Terrain")
						end
					end
				)
				
				if self.Climbing and not Result then
					-- if result then continue climbing,
					-- if not result then stop
					self.FlyTime -= Delta
					
					if self.FlyTime <= 0 then
						ClimbVelocity.MaxForce = Vector3.zero
						print('stop climbing')
						self.Climbing = false
					end
					
				elseif Result then
					self.Climbing = true
					ClimbVelocity.MaxForce = Vector3.one * 100000
					print('start climbing')
					self.FlyTime = 1
					-- if result, start climbing
				end
				
				if Result then
					break
				end
			end
		end
		--if Engine and self.Steering and BodyGyro and self:CanSteer() then
		--	local Position = MovingVehicle.Input:GetMousePosition()
		--	if Position then
		--		BodyGyro.CFrame = Position
		--	end
		--end
	end
end

return Jeep