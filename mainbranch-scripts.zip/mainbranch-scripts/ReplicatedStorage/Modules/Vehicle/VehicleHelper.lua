--[[
    VehicleHelper (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

local VehicleHelper = {}

function VehicleHelper.GetVehicle(Player)
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChild("Humanoid")
		if Humanoid then
			local SeatPart = Humanoid.SeatPart
			if SeatPart then
				local Vehicle = SeatPart.Parent
				if Vehicle and SeatPart:HasTag("VehicleController") then
					return Vehicle
				end
			end
		end
	end
end

function VehicleHelper.GetPilot(Vehicle)
	local Seat = Vehicle:FindFirstChild("Seat")
	if Seat:HasTag("VehicleController") then
		local Humanoid = Seat.Occupant
		if Humanoid then
			return Players:GetPlayerFromCharacter(Humanoid.Parent)
		end
	end
end

function VehicleHelper.GetControllerType(Vehicle)
	return Vehicle:GetAttribute("ControllerType")
end

return VehicleHelper