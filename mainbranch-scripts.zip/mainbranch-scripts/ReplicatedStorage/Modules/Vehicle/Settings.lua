--[[
    Settings (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:24
]]
return {
	HelicopterSpeed = 80,
	JeepSpeed = 2,
	SteerForce = Vector3.new(9e3, 9e3, 9e3),
	FlyingForce = Vector3.new(1e6, 1e6, 1e6),
	FlipDebounce = 4,
	RollDebounce = 3,
	VehicleMouseIcon = "rbxasset://textures\\GunCursor.png",
	SAMTankSpeed = 40,
}