--[[
    BillboardController (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → MOBILE → VIPHelicopter
    Parent: VIPHelicopter
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local RunService = game:GetService("RunService")
local Players = game:GetService("Players")

local DebrisFolder = workspace:WaitForChild("Debris")
local Vehicles = DebrisFolder:WaitForChild("Vehicles")

local BillboardTemplate = script:WaitForChild("Billboard")
local Highlight = script:WaitForChild("Highlight")

local Player = Players.LocalPlayer
local Camera = workspace.CurrentCamera

local RaycastParameters = RaycastParams.new()
RaycastParameters.FilterType = Enum.RaycastFilterType.Blacklist

local Controller = {
	Connections = {},
	ActiveVehicles = {},
	Showing = false,
	RenderConnection = nil,
	ActiveVehicle = nil
}

local function GetPlayer(Seat)
	local Occupant = Seat.Occupant
	if Occupant then
		return Players:GetPlayerFromCharacter(Occupant.Parent)
	end
end

local function IsActive(Vehicle)
	local Seat = Vehicle:FindFirstChild("Seat")
	if Seat then
		local Player = GetPlayer(Seat)
		if Player then
			return Seat, Player
		end
	end
end

local function IsEnemy(Enemy)
	return Enemy.Team ~= Player.Team
end

local function NewBillboard(Seat)
	local New = BillboardTemplate:Clone()
	New.Adornee = Seat
	New.Text.Adornee = Seat
	New.Parent = Seat
end

local function GetVehicle(Vehicle)
	for i, v in pairs(Controller.ActiveVehicles) do
		if v.Vehicle == Vehicle then
			return i
		end
	end
end

local function GetCharacters()
	local Characters = {}
	
	for i, v in pairs(Players:GetPlayers()) do
		local Character = v.Character
		if Character then
			table.insert(Characters, Character)
		end
	end
	
	return Characters
end

local function Display(Vehicle, Seat)
	local Player = GetPlayer(Seat)
	local Billboard = Seat:FindFirstChild("Billboard")
	if Billboard then
		if Player and IsEnemy(Player) then
			if Controller.Showing then
				Billboard.Enabled = true
				Billboard.Text.Enabled = true
			end
			
			table.insert(Controller.ActiveVehicles, {Vehicle = Vehicle, Billboard = Billboard})
		else
			Billboard.Enabled = false
			Billboard.Text.Enabled = false
			
			local Position = GetVehicle(Vehicle)
			if Position then
				table.remove(Controller.ActiveVehicles, Position)
			end
		end
	end
end

local function Setup(Vehicle)
	local Seat = Vehicle:FindFirstChild("Seat")
	if Seat then
		NewBillboard(Seat)
		Display(Vehicle, Seat)
		
		Controller.Connections[Vehicle] = Seat:GetPropertyChangedSignal("Occupant"):Connect(function()
			Display(Vehicle, Seat)
		end)
		
		--Destroyed = Vehicle.Destroying:Connect(function()
			
		--end)
	end
end

Vehicles.ChildAdded:Connect(function(Vehicle)
	Setup(Vehicle)
end)

Vehicles.ChildRemoved:Connect(function(Vehicle)
	local Connection = Controller.Connections[Vehicle]
	if Connection then
		Connection:Disconnect()
		Controller.Connections[Vehicle] = nil
	end
end)

for i, v in pairs(Vehicles:GetChildren()) do
	Setup(v)
end

local function GetActiveBillboard()
	local Active = Controller.ActiveVehicles
	for i, v in pairs(Active) do
		local Vehicle = v.Vehicle
		local Billboard = v.Billboard
		local Seat = Vehicle:FindFirstChild("Seat")
		
		--local Frame = Billboard:WaitForChild("Frame")
		local Icon = Billboard:WaitForChild("Icon")
		local TextBillboard = Billboard:WaitForChild("Text")
		local StatusLabel = TextBillboard:WaitForChild("Status")
		--local UIStroke = Frame:WaitForChild("UIStroke")
		local Red = Color3.fromRGB(182, 30, 30)
		local White = Color3.new(1, 1, 1)
		
		if Seat then
			local _, OnScreen = Camera:WorldToViewportPoint(Seat.Position)
			if OnScreen then
				RaycastParameters.FilterDescendantsInstances = {Vehicles, v, GetCharacters()}
				
				local Direction = (Seat.Position - Camera.CFrame.Position)
				local Result = workspace:Raycast(Camera.CFrame.Position, Direction, RaycastParameters)
				
				if not Result or (Result and not Result.Instance) then
					--UIStroke.Color = Color3.fromRGB(255, 255, 255)
					Icon.ImageColor3 = Red
					StatusLabel.TextColor3 = Red
					Controller.ActiveVehicle = v
					StatusLabel.Text = "TARGET"
					Highlight.Adornee = Vehicle
					--Highlight.Parent = workspace
				else
					Icon.ImageColor3 = White
					StatusLabel.TextColor3 = White
					StatusLabel.Text = "HOMING"
					--UIStroke.Color = Color3.fromRGB(0, 0, 0)
				end
			end
		end
	end
end

function Controller:Hide()
	local Connection = Controller.RenderConnection
	for i, v in pairs(Controller.ActiveVehicles) do
		local Billboard = v.Billboard
		Billboard.Enabled = false
		Billboard.Text.Enabled = false
	end
	
	if Connection then
		Connection:Disconnect()
		Controller.RenderConnection = nil
	end
	
	Highlight.Parent = nil
	Controller.Showing = false
end

function Controller:Show()
	Controller.RenderConnection = RunService.Heartbeat:Connect(GetActiveBillboard)
	
	for i, v in pairs(Controller.ActiveVehicles) do
		local Billboard = v.Billboard
		Billboard.Enabled = true
		Billboard.Text.Enabled = true
	end
	
	Highlight.Parent = workspace
	Highlight.Adornee = game.Lighting
	Controller.Showing = true
end

return Controller