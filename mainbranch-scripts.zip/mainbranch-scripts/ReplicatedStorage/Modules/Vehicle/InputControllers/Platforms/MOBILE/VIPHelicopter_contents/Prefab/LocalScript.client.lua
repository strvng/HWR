--[[
    LocalScript (LocalScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → MOBILE → VIPHelicopter → Prefab
    Parent: Prefab
    ⚠️  NESTED SCRIPT: This script is inside another script
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")

local ControlModule = require(Vehicle:WaitForChild("ControlModule"))

local Frame = script.Parent

local ActiveInputController = ControlModule.ActiveInputController
if ActiveInputController and ActiveInputController.Callback then
	local Flip = Frame:WaitForChild("Flip")
	local Roll = Frame:WaitForChild("Roll")
	local HomingToggle = Frame:WaitForChild("Homing")
	local FireHoming = Frame:WaitForChild("FireHoming")
	
	ActiveInputController:RegisterStuntDebounce(Flip)
	ActiveInputController:RegisterStuntDebounce(Roll)
	
	local HomingVisible = false
	
	HomingToggle.Activated:Connect(function()
		HomingVisible = not HomingVisible
		
		FireHoming.Visible = HomingVisible
		ActiveInputController:SetBillboardsEnabled(HomingVisible)
		ActiveInputController:SetCrosshairEnabled(not HomingVisible)
	end)
	
	for _, v in pairs(Frame:GetChildren()) do
		if v:IsA("GuiButton") then
			v.Activated:Connect(function()
				ActiveInputController:Activated(v.Name, v)
			end)
		end
	end
end