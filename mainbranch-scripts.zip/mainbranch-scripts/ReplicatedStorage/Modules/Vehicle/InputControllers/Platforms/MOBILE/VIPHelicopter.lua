--[[
    VIPHelicopter (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → MOBILE
    Parent: MOBILE
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Projectiles = Modules:WaitForChild("Projectiles")

local CrosshairIndicatorVehicle = require(BaseControllers:WaitForChild("CrosshairIndicatorVehicle"))
local BillboardController = require(script:WaitForChild("BillboardController"))
local Settings = require(Projectiles:WaitForChild("Settings"))

local Prefab = script:WaitForChild("Prefab")

local VIPHelicopter = setmetatable({}, CrosshairIndicatorVehicle)
VIPHelicopter.__index = VIPHelicopter

function VIPHelicopter.new(VehicleController)
	local self = setmetatable(CrosshairIndicatorVehicle.new(VehicleController, Prefab), VIPHelicopter)
	
	self:AddCallback("Fire", function(Name, Button)
		local Cooldown = self.Cooldown
		if not Cooldown then
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, true)
			self.Cooldown = true
			self:Fire()
			task.wait(Settings.VipMissile.Cooldown)
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, false)
			self.Cooldown = false
		end
	end)
	
	self:AddCallback("Bomb", function(Name, Button)
		local Cooldown = self.BombCooldown
		if not Cooldown then
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, true)
			self.BombCooldown = true
			self:DropBomb()
			task.wait(Settings.Bomb.Cooldown)
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, false)
			self.BombCooldown = false
		end
	end)
	
	self:AddCallback("FireHoming", function(Name, Button)
		local Cooldown = self.HomingCooldown
		local HomingTarget = self:GetHomingTarget()
		if not Cooldown and HomingTarget then
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, true)
			self.HomingCooldown = true
			VehicleController:FireHoming(HomingTarget)
			task.wait(Settings.HomingMissile.Cooldown)
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, false)
			self.HomingCooldown = false
		end
	end)
	
	return self
end

function VIPHelicopter:GetHomingTarget()
	local Active = BillboardController.ActiveVehicle
	if Active then
		local Vehicle = Active.Vehicle
		if Vehicle then
			local Seat = Vehicle:FindFirstChild("Seat")
			if Seat then
				return Seat
			end
		end
	end
end

function VIPHelicopter:SetBillboardsEnabled(Enabled)
	if Enabled then
		BillboardController:Show()
	else
		BillboardController:Hide()
	end
end

function VIPHelicopter:Fire()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Fire()
	end
end

function VIPHelicopter:DropBomb()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:DropBomb()
	end
end

function VIPHelicopter:Destroy()
	self:SetBillboardsEnabled(false)
	
	CrosshairIndicatorVehicle.Destroy(self)
end

return VIPHelicopter