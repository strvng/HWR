--[[
    Jeep (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → MOBILE
    Parent: MOBILE
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Projectiles = Modules:WaitForChild("Projectiles")

local CrosshairIndicatorVehicle = require(BaseControllers:WaitForChild("CrosshairIndicatorVehicle"))
local Settings = require(Projectiles:WaitForChild("Settings"))

local Prefab = script:WaitForChild("Prefab")

local Jeep = setmetatable({}, CrosshairIndicatorVehicle)
Jeep.__index = Jeep

function Jeep.new(VehicleController)
	local self = setmetatable(CrosshairIndicatorVehicle.new(VehicleController, Prefab), Jeep)
	
	self.StartText = "Drive"
	self.StopText = "Stop"
	
	self:AddCallback("Fire", function(Name, Button)
		local Cooldown = self.Cooldown
		if not Cooldown then
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, true)
			self.Cooldown = true
			self:Fire()
			task.wait(Settings.JeepBullet.Cooldown)
			CrosshairIndicatorVehicle.SetButtonEnabled(Button, false)
			self.Cooldown = false
		end
	end)
	
	return self
end

function Jeep:Fire()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Fire()
	end
end

return Jeep