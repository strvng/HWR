--[[
    Helicopter (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → MOBILE
    Parent: MOBILE
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Projectiles = Modules:WaitForChild("Projectiles")

local CrosshairIndicatorVehicle = require(BaseControllers:WaitForChild("CrosshairIndicatorVehicle"))
local Settings = require(Projectiles:WaitForChild("Settings"))

local Prefab = script:WaitForChild("Prefab")

local Helicopter = setmetatable({}, CrosshairIndicatorVehicle)
Helicopter.__index = Helicopter

function Helicopter.new(VehicleController)
	local self = setmetatable(CrosshairIndicatorVehicle.new(VehicleController, Prefab), Helicopter)
	
	self:AddCallback("Fire", function()
		local Cooldown = self.Cooldown
		if not Cooldown then
			--BodyMoverTouchVehicle.SetButtonEnabled(Button, true)
			self.Cooldown = true
			self:Fire()
			task.wait(Settings.PlaneMissile.Cooldown)
			--BodyMoverTouchVehicle.SetButtonEnabled(Button, false)
			self.Cooldown = false
		end
	end)
	
	return self
end

function Helicopter:Fire()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Fire()
	end
end

return Helicopter