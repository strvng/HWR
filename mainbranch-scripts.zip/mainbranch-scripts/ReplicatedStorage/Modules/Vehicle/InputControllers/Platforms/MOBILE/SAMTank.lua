--[[
    SAMTank (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → MOBILE
    Parent: MOBILE
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Projectiles = Modules:WaitForChild("Projectiles")
local Utilities = Modules:WaitForChild("Utilities")

local MouseTarget = require(Utilities:WaitForChild("MouseTarget"))
local BodyMoverTouchVehicle = require(BaseControllers:WaitForChild("BodyMoverTouchVehicle"))
local Settings = require(Projectiles:WaitForChild("Settings"))

local CrosshairPrefab = script:WaitForChild("Crosshair")
local Prefab = script:WaitForChild("Prefab")

local SAMTank = setmetatable({}, BodyMoverTouchVehicle)
SAMTank.__index = SAMTank

function SAMTank.new(VehicleController)
	local self = setmetatable(BodyMoverTouchVehicle.new(VehicleController, Prefab), SAMTank)
	
	self.StartText = "Drive"
	self.StopText = "Stop"
	self.VehicleController = VehicleController
	
	self.Aiming = false
	self.TargetPosition = nil
	self.Crosshair = CrosshairPrefab:Clone()
	
	self:AddCallback("Fire", function(Name, Button)
		local Cooldown = self.Cooldown
		local TargetPosition = self.TargetPosition
		local TouchGui = self.TouchGui
		if not Cooldown and TargetPosition and TouchGui then
			local FireButton = TouchGui:FindFirstChild("Fire")
			if FireButton then
				self.Cooldown = true
				self:Fire(TargetPosition)
				BodyMoverTouchVehicle.SetButtonEnabled(FireButton, true)
				task.wait(Settings.SAMTankMissile.Cooldown)
				BodyMoverTouchVehicle.SetButtonEnabled(FireButton, false)
				self.Cooldown = false
			end
		end
	end)
	
	--BodyMoverTouchVehicle.SetButtonEnabled(Button, true)
	--self.Cooldown = true
	--self:Fire()
	--task.wait(Settings.SAMTankBullet.Cooldown)
	--BodyMoverTouchVehicle.SetButtonEnabled(Button, false)
	--self.Cooldown = false
	
	return self
end

function SAMTank:SetCrosshairPosition(Position)
	local Crosshair = self.Crosshair
	if Crosshair then
		Crosshair.Position = Position
	end
end

function SAMTank:GetCrosshairEnabled()
	local Crosshair = self.Crosshair
	if Crosshair then
		local Billboard = Crosshair:FindFirstChild("Crosshair")
		if Billboard then
			return Billboard.Enabled
		end
	end
end

function SAMTank:Destroy()
	self:SetCrosshairEnabled(false)
	
	BodyMoverTouchVehicle.Destroy(self)
end

function SAMTank:SetCrosshairEnabled(Enabled)
	local Crosshair = self.Crosshair
	if Crosshair then
		local Billboard = Crosshair:FindFirstChild("Crosshair")
		if Billboard then
			if Enabled then
				Crosshair.Parent = workspace
			else
				Crosshair.Parent = nil
			end
			
			Billboard.Enabled = Enabled
		end
	end
end

function SAMTank:TouchTap(InputObject, GameProcessed)
	if not GameProcessed then
		local VehicleController = self.VehicleController
		if VehicleController then
			local Position = MouseTarget.GetPositionWithIgnoreList({
				VehicleController.Model
			})
			
			if Position then
				self:SetCrosshairPosition(Position)
				
				self.TargetPosition = Position
				
				self:SetCrosshairEnabled(true)
			end
		end
	end
end


--function SAMTank:TouchTap(InputObject, GameProcessed)
--	if not GameProcessed then
--		local FireButton = self.FireButton
--		local VehicleController = self.VehicleController
--		if self.WaitingForTap and self.FireButton and VehicleController then
--			local Position = MouseTarget.GetPositionWithIgnoreList({VehicleController.Model})
--			self.Cooldown = true
--			self.WaitingForTap = false
--			self:Fire(Position)
--			task.wait(Settings.SAMTankMissile.Cooldown)
--			BodyMoverTouchVehicle.SetButtonEnabled(FireButton, false)
--			self.Cooldown = false
--		else
--			BodyMoverTouchVehicle.TouchTap(self)
--		end
--	end
--end

function SAMTank:Fire(Position)
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Fire(Position)
	end
end

return SAMTank