--[[
    Jeep (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → PC
    Parent: PC
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")

local BodyMoverVehicle = require(BaseControllers:WaitForChild("BodyMoverVehicle"))

local Jeep = setmetatable({}, BodyMoverVehicle)
Jeep.__index = Jeep

function Jeep.new(VehicleController)
	local self = setmetatable(BodyMoverVehicle.new(VehicleController), Jeep)
	
	self.Input.Began:AddCallback(Enum.KeyCode.E, function()
		self:Fire()
	end)
	
	return self
end

function Jeep:Fire()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Fire()
	end
end

return Jeep