--[[
    HoverCart (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → PC
    Parent: PC
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")

local BodyMoverVehicle = require(BaseControllers:WaitForChild("BodyMoverVehicle"))

local HoverCart = setmetatable({}, BodyMoverVehicle)
HoverCart.__index = HoverCart

function HoverCart.new(VehicleController)
	local self = setmetatable(BodyMoverVehicle.new(VehicleController), HoverCart)
	
	return self
end

return HoverCart