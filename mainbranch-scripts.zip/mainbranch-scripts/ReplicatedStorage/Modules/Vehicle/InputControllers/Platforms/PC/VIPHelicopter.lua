--[[
    VIPHelicopter (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → PC
    Parent: PC
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Utilities = Modules:WaitForChild("Utilities")

local BodyMoverVehicle = require(BaseControllers:WaitForChild("BodyMoverVehicle"))
local MouseTarget = require(Utilities:WaitForChild("MouseTarget"))

local VIPHelicopter = setmetatable({}, BodyMoverVehicle)
VIPHelicopter.__index = VIPHelicopter

function VIPHelicopter.new(VehicleController)
	local self = setmetatable(BodyMoverVehicle.new(VehicleController), VIPHelicopter)
	
	self.Input.Began:AddCallback(Enum.KeyCode.F, function()
		self:Fire()
	end)
	
	self.Input.Began:AddCallback(Enum.KeyCode.B, function()
		self:Bomb()
	end)
	
	self.Input.Began:AddCallback(Enum.KeyCode.M, function()
		self:Homing()
	end)

	return self
end

function VIPHelicopter:Fire()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Fire()
	end
end

function VIPHelicopter:Homing()
	local VehicleController = self.VehicleController
	if VehicleController then
		local Target = MouseTarget.GetTargetWithIgnoreList({
			VehicleController.Model
		})
		
		if Target then
			VehicleController:FireHoming(Target)
		end
	end
end

function VIPHelicopter:Bomb()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:DropBomb()
	end
end

return VIPHelicopter