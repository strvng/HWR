--[[
    SAMTank (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → Platforms → PC
    Parent: PC
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")

local BodyMoverVehicle = require(BaseControllers:WaitForChild("BodyMoverVehicle"))

local Player = Players.LocalPlayer
local Mouse = Player:GetMouse()

local SAMTank = setmetatable({}, BodyMoverVehicle)
SAMTank.__index = SAMTank

function SAMTank.new(VehicleController)
	local self = setmetatable(BodyMoverVehicle.new(VehicleController), SAMTank)
	
	self.Input.Began:AddCallback(Enum.KeyCode.F, function()
		self:Fire()
	end)
	
	return self
end

function SAMTank:Fire()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Fire(Mouse.Hit.Position)
	end
end

return SAMTank