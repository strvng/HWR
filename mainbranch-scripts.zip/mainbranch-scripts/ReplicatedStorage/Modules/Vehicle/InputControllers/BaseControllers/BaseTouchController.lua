--[[
    BaseTouchController (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → BaseControllers
    Parent: BaseControllers
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")

local BaseController = require(BaseControllers:WaitForChild("BaseController"))

local BaseTouchController = setmetatable({}, BaseController)
BaseTouchController.__index = BaseTouchController

function BaseTouchController.new(VehicleController)
	local self = setmetatable(BaseController.new(VehicleController), BaseTouchController)
	
	self.TapConnection = nil
	self.MovedConnection = nil
	
	return self
end

function BaseTouchController:_BindInput()
	self:_UnbindInput()
	
	self.TapConnection = UserInputService.TouchTapInWorld:Connect(function(InputObject, GameProcessed)
		if not GameProcessed then
			self:TouchTap(InputObject, GameProcessed)
		end
	end)
	
	self.MovedConnection = UserInputService.TouchMoved:Connect(function(InputObject, GameProcessed)
		if not GameProcessed then
			self:TouchMoved(InputObject, GameProcessed)
		end
	end)
end

function BaseTouchController:_UnbindInput()
	local TapConnection = self.TapConnection
	if TapConnection then
		TapConnection:Disconnect()
		self.TapConnection = nil
	end
	
	local MovedConnection = self.MovedConnection
	if MovedConnection then
		MovedConnection:Disconnect()
		self.MovedConnection = nil
	end
end

function BaseTouchController:TouchTap(InputObject)
	
end

function BaseTouchController:TouchMoved()
	
end

function BaseTouchController:Enable()
	self:_BindInput()
	BaseController.Enable(self)
end

function BaseTouchController:Disable()
	self:_UnbindInput()
	BaseController.Disable(self)
end

return BaseTouchController