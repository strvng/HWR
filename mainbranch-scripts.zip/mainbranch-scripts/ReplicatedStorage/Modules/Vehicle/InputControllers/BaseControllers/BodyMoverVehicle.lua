--[[
    BodyMoverVehicle (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → BaseControllers
    Parent: BaseControllers
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local DataFolder = Modules:WaitForChild("Data")
local Menu = Modules:WaitForChild("Menu")
local Menus = Menu:WaitForChild("Menus")

local DataController = require(DataFolder:WaitForChild("DataController"))
local BaseKeyboardController = require(BaseControllers:WaitForChild("BaseKeyboardController"))
local ControlsMenu = require(Menus:WaitForChild("Controls"))
local Settings = require(Vehicle:WaitForChild("Settings"))

local Player = Players.LocalPlayer
local Mouse = Player:GetMouse()

local BodyMoverVehicle = setmetatable({}, BaseKeyboardController)
BodyMoverVehicle.__index = BodyMoverVehicle

function BodyMoverVehicle.new(VehicleController)
	local self = setmetatable(BaseKeyboardController.new(VehicleController), BodyMoverVehicle)
	
	self.Input.Began:AddCallback(Enum.KeyCode.Y, function()
		self:Start()
	end)
	
	self.Input.Began:AddCallback(Enum.KeyCode.X, function()
		self:Stop()
	end)
	
	self.Input.Began:AddCallback(Enum.KeyCode.T, function()
		self:Flip()
	end)
	
	self.Input.Began:AddCallback(Enum.KeyCode.G, function()
		self:Roll()
	end)
	
	self.Input.Began:AddCallback(Enum.UserInputType.MouseButton1, function()
		self:StartSteering()
	end)
	
	self.Input.Ended:AddCallback(Enum.UserInputType.MouseButton1, function()
		self:StopSteering()
	end)
	
	return self
end

function BodyMoverVehicle:_BindInput()
	self:_UnbindInput()
	
	self.InputBeganConnection = UserInputService.InputBegan:Connect(function(InputObject, GameProcessedEvent)
		local VehicleController = self.VehicleController
		if VehicleController and VehicleController:CanProcessInput() and not GameProcessedEvent and self.Enabled then
			local Callback = self.Input.Began:GetCallback(InputObject)
			if Callback then
				Callback(self, InputObject, GameProcessedEvent)
			end
		end
	end)

	self.InputEndedConnection = UserInputService.InputEnded:Connect(function(InputObject, GameProcessedEvent)
		local VehicleController = self.VehicleController
		if VehicleController and VehicleController:CanProcessInput() and not GameProcessedEvent and self.Enabled then
			local Callback = self.Input.Ended:GetCallback(InputObject)
			if Callback then
				Callback(self, InputObject, GameProcessedEvent)
			end
		end
	end)
end

function BodyMoverVehicle:_StartRenderThread()
	self:_StopRenderThread()
	
	self.RenderThread = RunService.Heartbeat:Connect(function(Delta)
		self:Step(Delta)
	end)
end

function BodyMoverVehicle:_StopRenderThread()
	local RenderThread = self.RenderThread
	if RenderThread then
		RenderThread:Disconnect()
		self.RenderThread = nil
	end
end

function BodyMoverVehicle:Step()
	local VehicleController = self.VehicleController
	if self.Steering and VehicleController then
		VehicleController:Steer(Mouse.Hit)
	end
end

function BodyMoverVehicle:Enable()
	local VehicleController = self.VehicleController
	if VehicleController then
		local ControllerType = VehicleController.InputController
		if ControllerType and DataController.Settings.ShowControls then
			ControlsMenu:Display(ControllerType)
		end
	end
	
	Mouse.Icon = Settings.VehicleMouseIcon
	
	self:_StartRenderThread()
	
	-- display pc controls
	-- enable keybinds
	BaseKeyboardController.Enable(self)
end

function BodyMoverVehicle:Disable()
	self:_StopRenderThread()
	
	ControlsMenu:Hide()
	Mouse.Icon = ""
	
	BaseKeyboardController.Disable(self)
end

function BodyMoverVehicle:Start()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Start()
	end
end

function BodyMoverVehicle:Stop()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Stop()
	end
end

function BodyMoverVehicle:Flip()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Flip()
	end
end

function BodyMoverVehicle:Roll()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Roll()
	end
end

function BodyMoverVehicle:StartSteering()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:EnableBodyGyro(true)
		self.Steering = true
	end
end

function BodyMoverVehicle:StopSteering()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:EnableBodyGyro(false)
		self.Steering = false
	end
end

return BodyMoverVehicle