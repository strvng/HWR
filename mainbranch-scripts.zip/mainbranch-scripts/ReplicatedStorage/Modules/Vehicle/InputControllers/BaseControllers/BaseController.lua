--[[
    BaseController (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → BaseControllers
    Parent: BaseControllers
    Exported: 2026-09-21 11:23:24
]]

local BaseController = {}
BaseController.__index = BaseController

function BaseController.new(VehicleController)
	local self = setmetatable({}, BaseController)
	
	self.VehicleController = VehicleController
	
	return self
end

function BaseController:Enable()
	self.Enabled = true
end

function BaseController:Disable()
	self.Enabled = false
end

function BaseController:Destroy()
	self:Disable()
	self.VehicleController = nil
end

return BaseController