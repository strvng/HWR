--[[
    BodyMoverTouchVehicle (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → BaseControllers
    Parent: BaseControllers
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Settings = Modules:WaitForChild("Settings")
local Data = Modules:WaitForChild("Data")

local DataController = require(Data:WaitForChild("DataController"))
local TouchGuiController = require(BaseControllers:WaitForChild("TouchGuiController"))
local UI = require(Settings:WaitForChild("UI"))

local Player = Players.LocalPlayer
local Mouse = Player:GetMouse()
local Camera = workspace.Camera

local BodyMoverTouchVehicle = setmetatable({}, TouchGuiController)
BodyMoverTouchVehicle.__index = BodyMoverTouchVehicle

function BodyMoverTouchVehicle.new(VehicleController, TouchGui)
	local self = setmetatable(TouchGuiController.new(VehicleController, TouchGui), BodyMoverTouchVehicle)
	
	self.Callback = {}
	self.StuntDebounceButtons = {}
	
	self.StartText = "Fly"
	self.StopText = "Land"
	
	self:AddCallback("Start", function(Name, Button)
		if VehicleController.Moving then
			Button.Text = self.StartText
			self:Stop()
		else
			Button.Text = self.StopText
			self:Start()
		end
	end)
	
	self:AddCallback("Flip", function(Name, Button)
		if not VehicleController.StuntDebounce then
			self:StuntDebounceChanged(true)
			self:Flip()
			self:StuntDebounceChanged(false)
		end
	end)
	
	self:AddCallback("Roll", function(Name, Button)
		if not VehicleController.StuntDebounce then
			self:StuntDebounceChanged(true)
			self:Roll()
			self:StuntDebounceChanged(false)
		end
	end)
	
	self:AddCallback("Eject", function(Name, Button)
		self:Eject()
	end)
	
	return self
end

function BodyMoverTouchVehicle:SetGlassVisible(Visible)
	local VehicleController = self.VehicleController
	if VehicleController then
		local Model = VehicleController.Model
		if Model then
			local Transparency = Visible and 0.5 or 0.95
			for _, v in pairs(Model:GetDescendants()) do
				if v:IsA("BasePart") and v:HasTag("Glass") then
					v.Transparency = Transparency
				end
			end
		end
	end
end

function BodyMoverTouchVehicle.SetButtonEnabled(Button, Enabled)
	if Button then
		local Label = Button:FindFirstChild("Text") or Button
		if Label and Label:IsA("TextLabel") or Label:IsA("TextButton") then
			Label.TextColor3 = Enabled and UI.TouchControls.StuntDebounceDisabledColor or UI.TouchControls.DefaultTextColor
		end
	end
end

function BodyMoverTouchVehicle:RegisterStuntDebounce(Button)
	table.insert(self.StuntDebounceButtons, Button)
end

function BodyMoverTouchVehicle:StuntDebounceChanged(Enabled)
	for _, v in pairs(self.StuntDebounceButtons) do
		BodyMoverTouchVehicle.SetButtonEnabled(v, Enabled)
	end
end

function BodyMoverTouchVehicle:AddCallback(Name, Callback)
	self.Callback[Name] = Callback
end

function BodyMoverTouchVehicle:GetCallback(Name)
	return self.Callback[Name]
end

function BodyMoverTouchVehicle:Activated(Name, Button)
	local Callback = self:GetCallback(Name)
	if Callback then
		Callback(Name, Button)
	end
end

function BodyMoverTouchVehicle:TouchTap()
	
end

function BodyMoverTouchVehicle:TouchMoved()
	--if not DataController.Settings.TapToSteer then
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Steer(Camera.CFrame)
	end
	--end
end

function BodyMoverTouchVehicle:Start()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Start()
		VehicleController:EnableBodyGyro(true)
		
		local Engine = VehicleController.Engine
		local BodyGyro = VehicleController.BodyGyro
		if Engine and BodyGyro then
			BodyGyro.CFrame = Engine.CFrame
		end
	end
end

function BodyMoverTouchVehicle:Stop()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Stop()
		VehicleController:EnableBodyGyro(false)
	end
end

function BodyMoverTouchVehicle:Flip()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Flip()
	end
end

function BodyMoverTouchVehicle:Roll()
	local VehicleController = self.VehicleController
	if VehicleController then
		VehicleController:Roll()
	end
end

function BodyMoverTouchVehicle:Eject()
	local VehicleController = self.VehicleController
	if VehicleController then
		local Character = Player.Character
		if Character then
			local Humanoid = Character:FindFirstChildOfClass("Humanoid")
			if Humanoid then
				Humanoid.Sit = false
			end
		end
	end
end

function BodyMoverTouchVehicle:Enable()
	--if not DataController.Settings.TapToSteer then
	--	Player.CameraMode = Enum.CameraMode.LockFirstPerson
	--end
	
	self:SetGlassVisible(false)
	
	TouchGuiController.Enable(self)
end

function BodyMoverTouchVehicle:Disable()
	--Player.CameraMode = Enum.CameraMode.Classic
	
	self:SetGlassVisible(true)
	
	TouchGuiController.Disable(self)
end

function BodyMoverTouchVehicle:Destroy()
	table.clear(self.StuntDebounceButtons)
	TouchGuiController.Destroy(self)
end

return BodyMoverTouchVehicle