--[[
    BaseKeyboardController (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → BaseControllers
    Parent: BaseControllers
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")

local BaseController = require(BaseControllers:WaitForChild("BaseController"))

local InputContainer = {}
InputContainer.__index = InputContainer

function InputContainer.new()
	local self = setmetatable({}, InputContainer)
	
	self.Input = {}
	
	return self
end

function InputContainer:AddCallback(InputType, Callback)
	self.Input[InputType] = Callback
end

function InputContainer:GetCallback(InputObject)
	return self.Input[InputObject.KeyCode] or self.Input[InputObject.UserInputType]
end

local BaseKeyboardController = setmetatable({}, BaseController)
BaseKeyboardController.__index = BaseKeyboardController

function BaseKeyboardController.new(VehicleController)
	local self = setmetatable(BaseController.new(VehicleController), BaseKeyboardController)
	
	self.Input = {
		Began = InputContainer.new(),
		Ended = InputContainer.new()
	}
	
	self.InputBeganConnection = nil
	self.InputEndedConnection = nil
	
	return self
end

function BaseKeyboardController:_BindInput()
	self.InputBeganConnection = UserInputService.InputBegan:Connect(function(InputObject, GameProcessedEvent)
		local Callback = self.Input.Began:GetCallback(InputObject)
		if Callback and not GameProcessedEvent and self.Enabled then
			Callback(self, InputObject, GameProcessedEvent)
		end
	end)
	
	self.InputEndedConnection = UserInputService.InputEnded:Connect(function(InputObject, GameProcessedEvent)
		local Callback = self.Input.Ended:GetCallback(InputObject)
		if Callback and not GameProcessedEvent and self.Enabled then
			Callback(self, InputObject, GameProcessedEvent)
		end
	end)
end

function BaseKeyboardController:_UnbindInput()
	local InputBeganConnection = self.InputBeganConnection
	if InputBeganConnection then
		InputBeganConnection:Disconnect()
		self.InputBeganConnection = nil
	end
	
	local InputEndedConnection = self.InputEndedConnection
	if InputEndedConnection then
		InputEndedConnection:Disconnect()
		self.InputEndedConnection = nil
	end
end

function BaseKeyboardController:Enable()
	self:_UnbindInput()
	self:_BindInput()
	
	BaseController.Enable(self)
end

function BaseKeyboardController:Disable()
	BaseController.Disable(self)
	self:_UnbindInput()
end

return BaseKeyboardController