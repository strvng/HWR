--[[
    TouchGuiController (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → BaseControllers
    Parent: BaseControllers
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Menu = Modules:WaitForChild("Menu")
local Menus = Menu:WaitForChild("Menus")
local Platform = Modules:WaitForChild("Platform")
local DataFolder = Modules:WaitForChild("Data")

local BaseTouchController = require(BaseControllers:WaitForChild("BaseTouchController"))
local DataController = require(DataFolder:WaitForChild("DataController"))
local ActiveTouchGui = require(Menus:WaitForChild("ActiveTouchGui"))
local TouchControls = require(Platform:WaitForChild("TouchControls"))

local Player = Players.LocalPlayer

local TouchGuiController = setmetatable({}, BaseTouchController)
TouchGuiController.__index = TouchGuiController

function TouchGuiController.new(VehicleController, TouchGui)
	local self = setmetatable(BaseTouchController.new(VehicleController), TouchGuiController)
	
	self.TouchGuiPrefab = TouchGui
	self.ButtonCallback = {}
	self.TouchGui = self:NewTouchGui()
	
	return self
end

function TouchGuiController:AddCallback(Name, Callback)
	self.ButtonCallback[Name] = Callback
end

--function TouchGuiController.ConnectTouchGui(TouchGui, CallbackController)
--	for _, v in pairs(TouchGui:GetChildren()) do
--		if v:IsA("ImageButton") then
--			v.Activated:Connect(function()
--				local Callback = CallbackController.ButtonCallback[v.Name]
--				if Callback then
--					Callback(v, TouchGui)
--				end
--			end)
--		end
--	end
--end

function TouchGuiController:NewTouchGui()
	local Prefab = self.TouchGuiPrefab
	if Prefab then
		local New = Prefab:Clone()
		--self.ConnectTouchGui(New, self)
		return New
	end
end

function TouchGuiController:Enable()
	local TouchGui = self.TouchGui
	if TouchGui then
		ActiveTouchGui:Display(TouchGui)
	end
	
	if DataController.Settings.ForceFirstPerson then
		Player.CameraMode = Enum.CameraMode.LockFirstPerson
	end
	
	TouchControls:Disable()
	
	BaseTouchController.Enable(self)
end

function TouchGuiController:Disable()
	ActiveTouchGui:Hide()
	TouchControls:Enable()
	BaseTouchController.Disable(self)
	
	Player.CameraMode = Enum.CameraMode.Classic
end

function TouchGuiController:Destroy()
	self:Disable()
	
	local TouchGui = self.TouchGui
	if TouchGui then
		TouchGui:Destroy()
		self.TouchGui = nil
	end
end

return TouchGuiController