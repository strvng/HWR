--[[
    CrosshairIndicatorVehicle (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle → InputControllers → BaseControllers
    Parent: BaseControllers
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local InputControllers = Vehicle:WaitForChild("InputControllers")
local BaseControllers = InputControllers:WaitForChild("BaseControllers")
local Settings = Modules:WaitForChild("Settings")
local Data = Modules:WaitForChild("Data")

local DataController = require(Data:WaitForChild("DataController"))
local BodyMoverTouchVehicle = require(BaseControllers:WaitForChild("BodyMoverTouchVehicle"))
local UI = require(Settings:WaitForChild("UI"))

local Player = Players.LocalPlayer
local Mouse = Player:GetMouse()
local Camera = workspace.Camera

local CrosshairIndicatorVehicle = setmetatable({}, BodyMoverTouchVehicle)
CrosshairIndicatorVehicle.__index = CrosshairIndicatorVehicle

local Prefab = script:WaitForChild("Laser")

function CrosshairIndicatorVehicle:GetEndPosition(LaserAttachment)
	local VehicleController = self.VehicleController
	if VehicleController then
		local Model = VehicleController.Model
		
		local Params = RaycastParams.new()
		Params.FilterDescendantsInstances = {Model, LaserAttachment}
		Params.FilterType = Enum.RaycastFilterType.Exclude
		
		local Direction = LaserAttachment.WorldCFrame.LookVector * self.MaxRange
		
		local RaycastResult = workspace:Raycast(
			LaserAttachment.WorldPosition,
			Direction,
			Params
		)
		
		if RaycastResult then
			return RaycastResult.Position
		else
			return (LaserAttachment.WorldCFrame * CFrame.new(0, 0, -self.MaxRange)).Position
		end
	end
end

function CrosshairIndicatorVehicle:Step()
	local EndAttachment = self.LaserEndAttachment
	local StartAttachment = self.LaserStartAttachment
	if EndAttachment and StartAttachment then
		local EndPosition = self:GetEndPosition(StartAttachment)
		if EndPosition then
			EndAttachment.WorldPosition = EndPosition
		end
	end
end

function CrosshairIndicatorVehicle:GetLaserAttachment()
	local VehicleController = self.VehicleController
	if VehicleController then
		local Engine = VehicleController.Engine
		if Engine then
			local LaserStartAttachment = Engine:FindFirstChild("Laser")
			if LaserStartAttachment then
				return LaserStartAttachment, Engine
			end
		end
	end
end

function CrosshairIndicatorVehicle.new(VehicleController, TouchGui)
	local self = setmetatable(BodyMoverTouchVehicle.new(VehicleController, TouchGui), CrosshairIndicatorVehicle)
	
	self.MaxRange = 100 * 1000
	
	-- Make laser
	
	local LaserAttachment, Engine = self:GetLaserAttachment()
	if LaserAttachment and Engine then
		local NewLaserPrefab = Prefab:Clone()
		local EndAttachment = NewLaserPrefab:WaitForChild("End")
		local Beam = NewLaserPrefab:WaitForChild("Laser")
		local Crosshair = EndAttachment:WaitForChild("Crosshair")
		Beam.Attachment0 = LaserAttachment
		NewLaserPrefab.Parent = Engine
		
		self.LaserPrefab = NewLaserPrefab
		self.LaserEndAttachment = EndAttachment
		self.LaserStartAttachment = LaserAttachment
		self.Crosshair = Crosshair
		self.LaserBeam = Beam
	end
	
	return self
end

-- Temporarily changed to TouchTap in world because GameProcessed is not accurate for whatever reason
function CrosshairIndicatorVehicle:TouchTap(InputObject, GameProcessed)
	local TouchGui = self.TouchGui
	if TouchGui then
		local FireButton = TouchGui:WaitForChild("Fire")
		if FireButton then
			-- this will probably be changed (not)
			self:Activated("Fire", FireButton)
		end
	end
end

function CrosshairIndicatorVehicle:_StartRender()
	self:_StopRender()
	
	self.RenderThread = RunService.RenderStepped:Connect(function(Delta)
		self:Step(Delta)
	end)
end

function CrosshairIndicatorVehicle:_StopRender()
	if self.RenderThread then
		self.RenderThread:Disconnect()
		self.RenderThread = nil
	end
end

function CrosshairIndicatorVehicle:SetCrosshairEnabled(Enabled)
	local Crosshair = self.Crosshair
	local LaserBeam = self.LaserBeam
	if Crosshair and LaserBeam then
		Crosshair.Enabled = Enabled
		LaserBeam.Enabled = Enabled
	end
	
	if Enabled then
		self:_StartRender()
	else
		self:_StopRender()
	end
end

function CrosshairIndicatorVehicle:Enable()
	self:SetCrosshairEnabled(true)
	
	BodyMoverTouchVehicle.Enable(self)
end

function CrosshairIndicatorVehicle:Disable()
	self:SetCrosshairEnabled(false)
	
	BodyMoverTouchVehicle.Disable(self)
end

function CrosshairIndicatorVehicle:Destroy()
	local Prefab = self.LaserPrefab
	if Prefab then
		Prefab:Destroy()
	end
	
	BodyMoverTouchVehicle.Destroy(self)
end

return CrosshairIndicatorVehicle