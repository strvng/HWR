--[[
    ControlModule (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local PlatformFolder = Modules:WaitForChild("Platform")
local VehicleFolder = Modules:WaitForChild("Vehicle")
local InputControllers = VehicleFolder:WaitForChild("InputControllers")
local ControllerPlatforms = InputControllers:WaitForChild("Platforms")

local Platform = require(PlatformFolder:WaitForChild("Platform"))

local ControlModule = {
	Enabled = false,
	ActiveInputController = nil
}

local function GetInputController(PlatformType, InputControllerType)
	local ControllerFolder = ControllerPlatforms:FindFirstChild(PlatformType)
	if ControllerFolder then
		local ControllerModule = ControllerFolder:FindFirstChild(InputControllerType)
		if ControllerModule then
			return require(ControllerModule)
		end
	end
end

function ControlModule:Enable(Controller)
	self.Enabled = true
	
	local ControllerType = Controller.InputController
	if ControllerType then
		local InputControllerClass = GetInputController(
			Platform.GetPlatformEnum(),
			ControllerType
		)
		
		if InputControllerClass then
			local NewController = InputControllerClass.new(Controller)
			
			self.ActiveInputController = NewController
			
			NewController:Enable()
		end
	end
end

function ControlModule:Disable()
	local ActiveInputController = self.ActiveInputController
	if ActiveInputController then
		ActiveInputController:Destroy()
	end
	
	self.ActiveController = nil
	self.Enabled = false
end

return ControlModule