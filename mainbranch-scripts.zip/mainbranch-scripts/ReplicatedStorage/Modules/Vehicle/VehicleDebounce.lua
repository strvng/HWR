--[[
    VehicleDebounce (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Projectiles = Modules:WaitForChild("Projectiles")
local Utilities = Modules:WaitForChild("Utilities")

local GetDictionaryLength = require(Utilities:WaitForChild("GetDictionaryLength"))

local VehicleDebounce = {
	Debounce = {}
}

--[[
to be honest, this module sucks but just :CanFire.
If you need to change something just delete it and start over
]]

function VehicleDebounce:CanFire(Vehicle, ProjectileType, DebounceTime)
	if VehicleDebounce:Get(Vehicle, ProjectileType) then
		return false
	end
	
	VehicleDebounce:Add(Vehicle, ProjectileType)
	task.delay(DebounceTime, function()
		VehicleDebounce:Remove(Vehicle, ProjectileType)
	end)
	
	return true
end

function VehicleDebounce:Get(Vehicle, ProjectileType)
	local ExistingData = self.Debounce[Vehicle]
	if ExistingData then
		return ExistingData[ProjectileType]
	end
end

function VehicleDebounce:Add(Vehicle, ProjectileType)
	local ExistingData = self.Debounce[Vehicle]
	if ExistingData then
		ExistingData[ProjectileType] = true
	else
		self.Debounce[Vehicle] = {
			[ProjectileType] = true
		}
	end
end

function VehicleDebounce:Remove(Vehicle, ProjectileType)
	local ExistingData = self.Debounce[Vehicle]
	if ExistingData then
		ExistingData[ProjectileType] = nil
		
		local Length = GetDictionaryLength(ExistingData)
		if Length < 1 then
			self.Debounce[Vehicle] = nil
		end
	end
end

return VehicleDebounce