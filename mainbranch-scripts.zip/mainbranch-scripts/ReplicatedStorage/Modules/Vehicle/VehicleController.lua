--[[
    VehicleController (ModuleScript)
    Path: ReplicatedStorage → Modules → Vehicle
    Parent: Vehicle
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Vehicle = Modules:WaitForChild("Vehicle")
local VehicleControllers = Vehicle:WaitForChild("VehicleControllers")
--local Menu = Modules:WaitForChild("Menu")
--local Menus = Menu:WaitForChild("Menus")
--local Data = Modules:WaitForChild("Data")
--local PlatformFolder = Modules:WaitForChild("Platform")
--local Tools = Modules:WaitForChild("Tools")

--local Platform = require(PlatformFolder:WaitForChild("Platform"))
--local Controls = require(Menus:WaitForChild("Controls"))
--local DataController = require(Data:WaitForChild("DataController"))
local ControlModule = require(Vehicle:WaitForChild("ControlModule"))
local Settings = require(Vehicle:WaitForChild("Settings"))
--local BackpackController = require(Tools:WaitForChild("BackpackController"))
local VehicleHelper = require(Vehicle:WaitForChild("VehicleHelper"))

local Controller = {
	ActiveController = nil,
	BackgroundControllers = {}
}

-- this is the main entry for the vehicle system
--[[
	Controller:SetVehicle(Type?) this is all that is needed from the servers' perspective.
	this function will handle connecting input, displaying guis and creating the controller
]]

function Controller.GetControllerModule(Type)
	local Module = VehicleControllers:FindFirstChild(Type)
	if Module then
		return require(Module)
	end
end

function Controller:FindController(Vehicle)
	local Field = {table.unpack(self.BackgroundControllers), self.ActiveController}
	for _, v in pairs(Field) do
		if v.Model == Vehicle then
			return v
		end
	end
end

function Controller:SetVehicle(Model)
	local ActiveController = self.ActiveController
	if ActiveController then
		ControlModule:Disable()
		
		if ActiveController.Moving and ActiveController.BackgroundEnabled then
			table.insert(self.BackgroundControllers, ActiveController)
		else
			ActiveController:Destroy()
		end
	end
	
	if Model then
		local ControllerType = VehicleHelper.GetControllerType(Model)
		if ControllerType then
			local VehicleController = self.GetControllerModule(ControllerType)
			if VehicleController then
				local NewController = VehicleController.new(Model)
				
				ControlModule:Enable(NewController)
				
				--if DataController.Settings.ShowControls and Platform.IsPC() then
				--	Controls:Display(ControllerType)
				--end
				
				--BackpackController:UnequipTools()
				--BackpackController:Disable()
				-- ^ this is only re-enabled on the server, which if the player is lagging can cause delay, or if packet corrupts never gets re-enabled. make this work on the client
				
				--if Platform.IsPC() then
				--	Mouse.Icon = Settings.VehicleMouseIcon
				--end
				
				--local ClientFolder = NewController:GetClientFolder()
				--if ClientFolder then
				--	local Moving = ClientFolder:FindFirstChild("Moving")
				--	if Moving and Moving.Value then
				--		NewController:Start()
				--	end
				--end
				
				self.ActiveController = NewController
			end
		end
	end
end

return Controller