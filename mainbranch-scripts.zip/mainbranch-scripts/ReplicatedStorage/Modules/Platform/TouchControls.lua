--[[
    TouchControls (ModuleScript)
    Path: ReplicatedStorage → Modules → Platform
    Parent: Platform
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

local Player = Players.LocalPlayer

local TouchControls = {}
TouchControls.__index = TouchControls

function TouchControls.GetControls()
	local PlayerScripts = Player:WaitForChild("PlayerScripts", 5)
	if PlayerScripts then
		local PlayerModule = PlayerScripts:WaitForChild("PlayerModule", 5)
		if PlayerModule then
			PlayerModule = require(PlayerModule)
			
			return PlayerModule:GetControls()
		end
	end
end

function TouchControls.new()
	local self = setmetatable({}, TouchControls)
	
	self.Enabled = true
	
	return self
end

function TouchControls:SetEnabled(Enabled)
	local Controls = self.GetControls()
	if Controls then
		local JumpController = Controls.touchJumpController
		if JumpController then
			Controls:Enable(Enabled)
			JumpController:EnableButton(Enabled)
			self.Enabled = Enabled
			--print(Controls)
			--Controls:SetInputInEnabled(Enabled)
		end
	end
end

function TouchControls:Enable()
	self:SetEnabled(true)
end

function TouchControls:Disable()
	self:SetEnabled(false)
end

return TouchControls.new()