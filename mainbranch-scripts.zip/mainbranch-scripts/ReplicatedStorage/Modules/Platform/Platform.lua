--[[
    Platform (ModuleScript)
    Path: ReplicatedStorage → Modules → Platform
    Parent: Platform
    Exported: 2026-09-21 11:23:24
]]

local UserInputService = game:GetService("UserInputService")

local Platform = {
	Enums = {
		Mobile = "MOBILE",
		PC = "PC",
	}
}

function Platform.IsMobile()
	return UserInputService.TouchEnabled and not UserInputService.KeyboardEnabled
end

function Platform.IsPC()
	return UserInputService.KeyboardEnabled
end

function Platform.GetPlatformEnum()
	if Platform.IsPC() then
		return Platform.Enums.PC
	elseif Platform.IsMobile() then
		return Platform.Enums.Mobile
	end
end

return Platform