--[[
    KillEffect (ModuleScript)
    Path: ReplicatedStorage → Modules → Sound → PlaySound
    Parent: PlaySound
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local SoundService = game:GetService("SoundService")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Sound = Modules:WaitForChild("Sound")
local Sounds = Sound:WaitForChild("Sounds")

local KillEffect = Sounds:WaitForChild("Kill")

return function()
	SoundService:PlayLocalSound(KillEffect)
end