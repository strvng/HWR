--[[
    PlaySound (ModuleScript)
    Path: ReplicatedStorage → Modules → Sound
    Parent: Sound
    Exported: 2026-09-21 11:23:24
]]

return function(Name, ...)
	local Module = script:FindFirstChild(Name)
	if Module then
		require(Module)(...)
	end
end