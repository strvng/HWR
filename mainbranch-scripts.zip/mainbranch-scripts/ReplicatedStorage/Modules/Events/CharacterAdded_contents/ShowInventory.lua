--[[
    ShowInventory (ModuleScript)
    Path: ReplicatedStorage → Modules → Events → CharacterAdded
    Parent: CharacterAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")

local BackpackController = require(Tools:WaitForChild("BackpackController"))

return function()
	BackpackController:Enable()
end