--[[
    EnableThumbstick (ModuleScript)
    Path: ReplicatedStorage → Modules → Events → CharacterAdded
    Parent: CharacterAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
--local MobileFolder = Modules:WaitForChild("Mobile")
--local VehicleModules = Modules:WaitForChild("Vehicle")
--local Mobile = VehicleModules:WaitForChild("Mobile")

--local SetThumbstickEnabled = require(Mobile:WaitForChild("SetThumbstickEnabled"))
--local IsMobile = require(MobileFolder:WaitForChild("IsMobile"))

return function()
	--if IsMobile then
	--	SetThumbstickEnabled(true)
	--end
end