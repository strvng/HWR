--[[
    VehicleListener (ModuleScript)
    Path: ReplicatedStorage → Modules → Events → CharacterAdded
    Parent: CharacterAdded
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Tools = Modules:WaitForChild("Tools")

local BackpackController = require(Tools:WaitForChild("BackpackController"))

local LastSeat

return function(Character)
	local Humanoid = Character:WaitForChild("Humanoid")
	if Humanoid then
		Humanoid:GetPropertyChangedSignal("SeatPart"):Connect(function()
			local SeatPart = Humanoid.SeatPart
			if SeatPart and SeatPart:HasTag("DisableBackpack") then
				BackpackController:UnequipTools()
				BackpackController:Disable()
				LastSeat = SeatPart
			elseif LastSeat then
				BackpackController:Enable()
			end
		end)
	end
end