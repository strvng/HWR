--[[
    DisconnectWeapons (ModuleScript)
    Path: ReplicatedStorage → Modules → Events → Died
    Parent: Died
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local Players = game:GetService("Players")

local Player = Players.LocalPlayer
local Mouse = Player:GetMouse()

local DEFAULT_ICON = ""

return function()
	local Backpack = Player:FindFirstChild("Backpack")
	
	Mouse.Icon = DEFAULT_ICON
	
	if Backpack then
		task.defer(function()
			local Character = Player.Character
			if Character then
				Player.CharacterRemoving:Wait()
			end
			
			Backpack:ClearAllChildren()
		end)
	end
end