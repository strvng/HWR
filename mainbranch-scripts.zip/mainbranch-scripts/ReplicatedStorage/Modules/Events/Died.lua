--[[
    Died (ModuleScript)
    Path: ReplicatedStorage → Modules → Events
    Parent: Events
    Exported: 2026-09-21 11:23:24
]]

local Modules = {}

for i, v in pairs(script:GetChildren()) do
	table.insert(Modules, require(v))
end

return function(Humanoid)
	for i, v in pairs(Modules) do
		v(Humanoid)
	end
end