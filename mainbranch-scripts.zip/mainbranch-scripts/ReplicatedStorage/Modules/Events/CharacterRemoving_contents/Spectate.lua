--[[
    Spectate (ModuleScript)
    Path: ReplicatedStorage → Modules → Events → CharacterRemoving
    Parent: CharacterRemoving
    ⚠️  NESTED SCRIPT: This script is inside another script
    Exported: 2026-09-21 11:23:24
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local SettingsFolder = Modules:WaitForChild("Settings")

local UI = require(SettingsFolder:WaitForChild("UI"))

local Player = Players.LocalPlayer
local PlayerGui = Player:WaitForChild("PlayerGui")

local Spectate = PlayerGui:WaitForChild("Spectate")
local Menu = PlayerGui:WaitForChild("KillList")
local Frame = Menu:WaitForChild("Frame")

return function()
	Spectate.Enabled = false
	Frame:TweenPosition(UI.Spectate.StartingPosition, table.unpack(UI.Spectate.DownTweenInfo))
end