--[[
    Parachutes (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]

return {
	["Parachute 1"] = {
		Level = 1
	},
	["Parachute 2"] = {
		Level = 2,
	},
	None = {
		Level = 0
	}
}