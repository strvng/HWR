--[[
    Vip (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]
return {
	VIPGamepassID = 16210289,
	SortGamepassId = 25272794,
	TrailGamepassId = 1,
	OriginalGamepassID = 2546452,
	TeleportDebounceTime = 5,
	PromptDebounceTime = 5,
}