--[[
    UI (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]
return {
	ActiveUIScale = 1,
	Default = {
		Open = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		Closed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
	},
	Controls = {
		ControlsOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		ControlsClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		OpenPosition = UDim2.fromScale(0.997, 0.991),
		ClosedPosition = UDim2.fromScale(1.149, 0.991)
	},
	Inventory = {
		InventoryOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		InventoryClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		SaveButtonOffColor = Color3.fromRGB(117, 0, 1),
		VipSize = UDim2.fromScale(0.099, 0.629),
		DefaultSize = UDim2.fromScale(0.13, 0, 0.819),
		SaveCooldownTime = 10
	},
	Sort = {
		CloseUDim = UDim2.new(0.5, 0, -1.5, 0),
		OpenUDim = UDim2.new(0.5, 0, 0.5, 0)
	},
	Shop = {
		ShopOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		ShopClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		OverlayOn = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0),
		OverlayOff = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.Out, 0, false, 0),
		OverlayTransparency = 0.6
	},
	Customization = {
		CustomizationOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		CustomizationClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		CategorySelected = Color3.fromRGB(46, 46, 46),
		CategoryUnselected = Color3.fromRGB(64, 64, 64),
		DefaultCategory = "Trail",
	},
	Settings = {
		SettingsOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		SettingsClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		SwitchOff = UDim2.new(0.062, 0, 0.5, 0),
		SwitchOn = UDim2.new(0.562, 0, 0.5, 0),
		MenuInactive = Color3.fromRGB(38, 38, 38),
		MenuActive = Color3.fromRGB(53, 53, 53),
		SwitchOffColor = Color3.fromRGB(136, 0, 0),
		SwitchOnColor = Color3.fromRGB(31, 90, 60),
	},
	Spectate = {
		MessageDisplayTime = 5,
		TransparencyTweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		PositionTweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		StrokeTweenInfo = TweenInfo.new(0.35, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		DownTweenInfo = table.pack(Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 0.5, true),
		HiddenPosition = UDim2.new(0.5, 0, 1.169, 0),
		StartingPosition = UDim2.new(0.5, 0, 1, 0),
		KillTextColor = Color3.fromRGB(150, 29, 21),
		WeaponMap = {
			FastRocket = "Fast Rocket",
			MultiRocket = "Multi-rocket",
			JeepBullet = "Jeep bullet",
			PlaneMissile = "Plane missile",
			HomingMissile = "Homing missile",
			VipMissile = "Vip missile"
		}
	},
	Zoom = {
		ZoomKey = Enum.KeyCode.C
	},
	TouchControls = {
		DefaultTextColor = Color3.fromRGB(255, 255, 255),
		StuntDebounceDisabledColor = Color3.fromRGB(162, 29, 29)
	},
	--Votekick = {
	--	VotekickOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
	--	VotekickClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
	--},
	Feedback = {
		FeedbackOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		FeedbackClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		SuccessMessage = "Message sent successfully",
		FailedMessage = "Message failed to send",
		LimitMessage = "You can only post once per server",
		MessageDisplayTime = 5,
		SuccessCode = "Success",
		FailedCode = "Failed",
		LimitCode = "Limit"
	},
	TeamChange = {
		StatusCodes = {
			Full = "Full",
			Unbalanced = "Unbalanced",
			Success = "Success"
		}
	},
	--VoteNotification = {
	--	VoteOpenPosition = UDim2.new(1.005, 0, 1.015, 0),
	--	VoteClosedPosition = UDim2.new(1.157, 0, 1.015, 0),
	--	VoteOpenInfo = table.pack(Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 1, true),
	--	VoteClosedInfo = table.pack(Enum.EasingDirection.Out, Enum.EasingStyle.Quad, 1, true),
	--},
	--Tutorial = {
	--	NewOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
	--	NewClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
	--	TutorialOpen = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
	--	TutorialClosed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
	--},
	Results = {
		ResultsShowing = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		ResultsHidden = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		EvenColor = Color3.fromRGB(50, 52, 54),
		OddColor = Color3.fromRGB(37, 37, 37),
		TeamXPadding = 0.1,
	},
	XP = {
		Open = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		Closed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		XPChange = TweenInfo.new(3, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		QuickLevel = TweenInfo.new(0.8, Enum.EasingStyle.Quad, Enum.EasingDirection.In, 0, false, 0),
		LastLevel = TweenInfo.new(1.3, Enum.EasingStyle.Sine, Enum.EasingDirection.Out, 0, false, 0),
	},
	WinnerText = {
		BlurTime = 5,
		BlurDelay = 1,
		DisplayTime = 3,
		WinnersHiddenTime = 0.5,
		Showing = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		Hidden = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		BlurShowing = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		BlurHidden = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		--TeamToText = {
			--["Desert Team"] = {
			--	Name = "Desert",
			--	Color = Color3.fromRGB(245, 205, 48)
			--},
			--["Green Team"] = {
			--	Name = "Green",
			--	Color = Color3.fromRGB(40, 127, 71)
			--},
		--},
	},
	VoiceChat = {
		UserDisplayTime = 0.75,
		VolumeThreshold = 0.02,
		ActiveColor = Color3.fromRGB(13, 172, 37),
		InactiveColor = Color3.fromRGB(99, 99, 99),
	},
	TeamScore = {
		--TopbarShowing = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		--TopbarHidden = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		SquishRegular = {
			SquishPosition = UDim2.fromOffset(170, 16),
			SquishSize = 804,
		},
		SquishVoiceChat = {
			SquishPosition = UDim2.fromOffset(210, 16),
			SquishSize = 868,
		},
		ScoreChanged = TweenInfo.new(0.35, Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, 0, false, 0),
		UpTweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
		UpPosition = UDim2.new(0.5, 0, 0, 16),
		DownTweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quint, Enum.EasingDirection.Out),
		DownPosition = UDim2.new(1, -265, 0, 16),
		MediaSize = 975,
		SquishSize = 804, -- Voice chat update, regular by default
		SquishXPadding = 0,
		SizeXPaddingPercent = 0.056,
		YSizeOffset = 36,
		YSize = 0.694,
		SquishAnchorPoint = Vector2.new(0, 0),
		SquishPosition = UDim2.fromOffset(170, 16), -- voice chat update
		UpAnchorPoint = Vector2.new(0.5, 0),
		DownAnchorPoint = Vector2.new(1, 0),
		DownSize = UDim2.new(0.459, 0, 0, 36),
		UpSize = UDim2.fromOffset(450, 36),
		SecondaryColorPercentage = Color3.new(
			0.8244897959183673, 0.8146341463414634, 0.8125
		),
		ShowingPosition = UDim2.fromScale(0.5, 0.5),
		HiddenPosition = UDim2.fromScale(0.5, -1.5)
		
	},
	Voting = {
		MapsPerVote = 3,
		VotingTime = 30,
		Open = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		Closed = TweenInfo.new(0.5, Enum.EasingStyle.Quad, Enum.EasingDirection.InOut, 0, false, 0),
		GrowTweenInfo = TweenInfo.new(
			0.15,
			Enum.EasingStyle.Quad,
			Enum.EasingDirection.InOut
		),
		ShrinkTweenInfo = TweenInfo.new(
			0.15,
			Enum.EasingStyle.Quad,
			Enum.EasingDirection.InOut
		),
		Maps = {
			Desert = {
				Name = "Desert",
				Image = "rbxassetid://696003043"
			},
			Winter = {
				Name = "Winter",
				Image = "rbxassetid://697010949"
			},
			Forest = {
				Name = "Forest",
				Image = "rbxassetid://696003043"
			}
		},
		OriginalButtonSize = UDim2.fromScale(0.31, 0.678),
		GrowButtonSize = UDim2.fromScale(0.329, 0.719),
		VoteFormat = "Votes: %s"
	}
}