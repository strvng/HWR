--[[
    TeamColor (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]

return {
	["Desert Team"] = {
		Primary = Color3.fromRGB(245, 205, 48),
		Secondary = Color3.fromRGB(202, 167, 39),
		VehicleColor = Color3.fromRGB(215, 197, 154),
		TeamColor = BrickColor.new("Bright yellow")
	},
	["Green Team"] = {
		Primary = Color3.fromRGB(39, 70, 45),
		Secondary = Color3.fromRGB(62, 113, 70),
		VehicleColor = Color3.fromRGB(39, 70, 45),
		TeamColor = BrickColor.new("Bright green"),
	},
	["Snow Team"] = {
		Primary = Color3.fromRGB(248, 248, 248),
		Secondary = Color3.fromRGB(214, 214, 214),
		VehicleColor = Color3.fromRGB(248, 248, 248),
		TeamColor = BrickColor.new("Institutional white")
	},
	["Cave Team"] = {
		Primary = Color3.fromRGB(86, 66, 54),
		Secondary = Color3.fromRGB(63, 48, 39),
		VehicleColor = Color3.fromRGB(86, 66, 54),
		TeamColor = BrickColor.new("Medium brown")
	},
	["Jungle Team"] = {
		Primary = Color3.fromRGB(126, 104, 63),
		Secondary = Color3.fromRGB(91, 75, 45),
		VehicleColor = Color3.fromRGB(126, 104, 63),
		TeamColor = BrickColor.new("Bronze")
	},
	["Sky Team"] = {
		Primary = Color3.fromRGB(128, 187, 219),
		Secondary = Color3.fromRGB(86, 126, 148),
		VehicleColor = Color3.fromRGB(128, 187, 219),
		TeamColor = BrickColor.new("Pastel Blue")
	}
}