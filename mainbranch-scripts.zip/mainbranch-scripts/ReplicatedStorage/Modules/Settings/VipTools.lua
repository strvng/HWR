--[[
    VipTools (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]

return {
	["MultiRocket"] = true,
}