--[[
    Player (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]
return {
	Shadows = true,
	Killcam = true,
	Zoom = true,
	Lighting = true,
	TapToSteer = false,
	--AutoEquip = true,
	ForceFirstPerson = true,
	ShowControls = true,
	VoiceChatVisible = true,
}