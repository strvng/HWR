--[[
    DefaultTools (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]
return {
	{
		Name = "FastRocket",
		Slot = 1,
	},
	{
		Name = "Parachute",
		Slot = 2,
	},
	{
		Name = "Dagger",
		Slot = 3,
	},
	{
		Name = "Pistol",
		Slot = 4,
	},
}