--[[
    Badges (ModuleScript)
    Path: ReplicatedStorage → Modules → Settings
    Parent: Settings
    Exported: 2026-09-21 11:23:24
]]

return {
	Caves = 364372745713157
}