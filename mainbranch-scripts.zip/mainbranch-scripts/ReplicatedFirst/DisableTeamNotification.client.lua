--[[
    DisableTeamNotification (LocalScript)
    Path: ReplicatedFirst
    Parent: ReplicatedFirst
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:28
]]

local TextChatService = game:GetService("TextChatService")

TextChatService.OnIncomingMessage = function(Message)
	if Message.Metadata == "Roblox.Team.Success.NowInTeam" then
		local Override = Instance.new("TextChatMessageProperties")
		Override.Text = " "
		
		return Override
	end
end