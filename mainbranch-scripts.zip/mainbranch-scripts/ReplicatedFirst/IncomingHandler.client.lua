--[[
    IncomingHandler (LocalScript)
    Path: ReplicatedFirst
    Parent: ReplicatedFirst
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local Modules = ReplicatedStorage:WaitForChild("Modules")
local Incoming = Modules:WaitForChild("Incoming")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

ReceiveIncoming.OnClientEvent:Connect(function(Action, ...)
	local ActionModule = Incoming:FindFirstChild(Action)
	if ActionModule then
		require(ActionModule)(...)
	end
end)