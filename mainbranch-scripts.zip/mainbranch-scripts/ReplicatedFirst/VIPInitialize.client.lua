--[[
    VIPInitialize (LocalScript)
    Path: ReplicatedFirst
    Parent: ReplicatedFirst
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Modules = ReplicatedStorage:WaitForChild("Modules")

local VIPFolder = Modules:WaitForChild("VIP")

require(VIPFolder:WaitForChild("Main"))