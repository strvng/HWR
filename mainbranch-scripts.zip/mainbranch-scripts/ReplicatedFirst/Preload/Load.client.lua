--[[
    Load (LocalScript)
    Path: ReplicatedFirst → Preload
    Parent: Preload
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:28
]]

local ContentProvider = game:GetService("ContentProvider")

local Folder = script.Parent

local Preload = {}

local function AddToList(Id)
	table.insert(Preload, Id)
end

for i, v in pairs(Folder:GetDescendants()) do
	if v:IsA("Decal") or v:IsA("Texture") then
		AddToList(v.Texture)
	elseif v:IsA("Sound") then
		AddToList(v.SoundId)
	elseif v:IsA("SpecialMesh") then
		AddToList(v.MeshId)
		AddToList(v.TextureId)
	end
end


local Countdown = #Preload

ContentProvider:PreloadAsync(Preload, function()
	Countdown -= 1
	if Countdown <= 0 then
		print("Done loading")
	end
end)