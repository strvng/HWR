--[[
    Events (LocalScript)
    Path: ReplicatedFirst
    Parent: ReplicatedFirst
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:28
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Modules = ReplicatedStorage:WaitForChild("Modules")
local Events = Modules:WaitForChild("Events")

local CharacterAdded = require(Events:WaitForChild("CharacterAdded"))
local CharacterRemoving = require(Events:WaitForChild("CharacterRemoving"))
local Died = require(Events:WaitForChild("Died"))

local Player = Players.LocalPlayer

local function SetupCharacter(Character)
	local Humanoid = Character:WaitForChild("Humanoid")
	if Humanoid then
		local DiedConnection;
		DiedConnection = Humanoid.Died:Connect(function()
			Died(Humanoid)
			DiedConnection:Disconnect()
			DiedConnection = nil
		end)
	end
	
	CharacterAdded(Character)
end

Player.CharacterAdded:Connect(SetupCharacter)
Player.CharacterRemoving:Connect(CharacterRemoving)

local CurrentCharacter = Player.Character
if CurrentCharacter then
	SetupCharacter(CurrentCharacter)
else
	SetupCharacter(Player.CharacterAdded:Wait())
end