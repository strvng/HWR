--[[
    DedicatedAntiFly (LocalScript)
    Path: ReplicatedFirst
    Parent: ReplicatedFirst
    Properties:
        Disabled: false
    Exported: 2026-09-21 11:23:28
]]

-- This is a very dedicated script to prevent arceus fly v2 (very common fly script)
-- beanandsoupguy 2025

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")

local ReceiveIncoming = Remotes:WaitForChild("ReceiveIncoming")

local Player = Players.LocalPlayer

local Connections = {}

local function DisconnectOnRespawn(Connection)
	table.insert(Connections, Connection)
end

local function Disconnect(Reason)
	ReceiveIncoming:FireServer("Disconnect", Reason)
end

local function IsPlayerAlive()
	local Character = Player.Character
	if Character then
		local Humanoid = Character:FindFirstChild("Humanoid")
		if Humanoid then
			return Humanoid.Health > 0
		end
	end
end

local function SetupAnimationCheck(Character)
	local Animate = Character:WaitForChild("Animate", 15)
	if Animate then
		local DisabledConnection
		--local AncestryConnection
		
		DisabledConnection = Animate:GetPropertyChangedSignal("Disabled"):Connect(function()
			if not Animate.Enabled then
				Disconnect("Animate script disabled")
			end
		end)
		
		--AncestryConnection = Animate.AncestryChanged:Connect(function()
		--	if Animate.Parent ~= Character and Player.Character == Character and IsPlayerAlive() then
		--		Disconnect("Animate script moved or deleted")
		--	end
		--end)
		
		DisconnectOnRespawn(DisabledConnection)
		--DisconnectOnRespawn(AncestryConnection)
	else
		warn('animation failed')
	end
end

local function SetupPlayerGuiCheck(Player)
	local PlayerGui = Player:WaitForChild("PlayerGui", 15)
	if PlayerGui then
		local function ContainsKeyword(Gui, Keyword)
			for _, v in pairs(Gui:GetDescendants()) do
				if v:IsA("TextButton") or v:IsA("TextLabel") then
					if string.find(v.Text:lower(), Keyword:lower()) then
						return true
					end
				end
			end
		end
		
		PlayerGui.ChildAdded:Connect(function(Object)
			if Object.Name == "main" then
				local Frame = Object:FindFirstChildOfClass("Frame")
				if Frame then
					if Frame:FindFirstChild("onof") then
						Disconnect("Found fly gui component 'onof'")
						return
					end
					
					if Frame:FindFirstChild("up") then
						Disconnect("Found fly gui component 'up'")
						return
					end
				end
			end
		end)
	end
end

--local function SetupBodyMoverCheck(Character)
--	local Torso = Character:WaitForChild("Torso", 15)
--	if Torso then
--		local ChildAddedConnection
		
--		ChildAddedConnection = Torso.ChildAdded:Connect(function(Object)
--			if Object:IsA("BodyGyro") then
--				Disconnect("BodyGyro found in user torso")
--			end
--		end)
		
--		DisconnectOnRespawn(ChildAddedConnection)
--	end
--end

local function SetupBodyMoverCheck(Part)
	if Part then
		local ChildAddedConnection
		
		ChildAddedConnection = Part.ChildAdded:Connect(function(Object)
			if Object:IsA("BodyGyro") then
				Disconnect("BodyGyro found in user torso")
			end
		end)
		
		DisconnectOnRespawn(ChildAddedConnection)
	end
end

local function SetupBasicHumanoidChecks(Character)
	local Humanoid = Character:WaitForChild("Humanoid", 15)
	if Humanoid then
		local HumanoidChanged
		
		HumanoidChanged = Humanoid.Changed:Connect(function()
			if Humanoid.WalkSpeed > 20 then
				Disconnect("Walkspeed > 20")
			end
			
			if Humanoid.JumpPower > 65 then
				Disconnect("JumpPower > 65")
			end
		end)
		
		DisconnectOnRespawn(HumanoidChanged)
	end
end

local function CharacterAdded(Character)
	for _, v in pairs(Connections) do
		v:Disconnect()
	end
	
	table.clear(Connections)
	
	SetupAnimationCheck(Character)
	
	local Torso = Character:WaitForChild("Torso", 15)
	if Torso then
		SetupBodyMoverCheck(Torso)
	end
	
	local HumanoidRootPart = Character:WaitForChild("HumanoidRootPart", 15)
	if HumanoidRootPart then
		SetupBodyMoverCheck(HumanoidRootPart)
	end
	
	SetupBasicHumanoidChecks(Character)
end

local function PlayerAdded(Player)
	SetupPlayerGuiCheck(Player)
end

local function Main()
	Player.CharacterAdded:Connect(CharacterAdded)
	
	PlayerAdded(Player)
	
	local Character = Player.Character
	if Character then
		CharacterAdded(Character)
	end
end

Main()